function EliminarEmpleado(legajo:number){
    alert("Empleado Eliminado: " + legajo);
}