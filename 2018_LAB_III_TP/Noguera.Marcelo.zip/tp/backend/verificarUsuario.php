<?php
include_once '../clases/persona.php';
include_once '../clases/empleado.php';
include_once '../clases/fabrica.php';

$dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;
$apellido = isset($_POST["apellido"]) ? $_POST["apellido"] : NULL;

//$e = new Empleado($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno);
$f = new Fabrica("Ninguna", 7);

//echo "((" .$dni . ") -- (" .$apellido . "))</br>";

if ($f->BuscarEmpleado($dni, $apellido, "../archivos/empleados.txt") != FALSE)
{
	session_start();
	$_SESSION["DNIEmpleado"] = $dni;
	header("Location: ./mostrar.php");
}
else
{
	echo "Error: El empleado no está en el archivo.</br>";
	echo "<a href='../login.html'>Login</a>";
}
?>