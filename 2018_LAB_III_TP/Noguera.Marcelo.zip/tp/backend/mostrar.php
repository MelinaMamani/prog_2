
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>HTML 5 - Listado de Empleados</title>
    <script src="../javascript/funciones.js"></script>
</head>
<body>
    <h2>Listado de Empleados</h2>
        <table align="center">
        	<tr>
                <td>
                	<h4>Info</h4>
                	<hr>
                </td>
            </tr>

<?php
include_once '../clases/persona.php';
include_once '../clases/empleado.php';
include_once '../clases/fabrica.php';
include_once './validarSesion.php';

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);

$htmlOutput = "";

$contenido = array();
try
{	
	$a = fopen("../archivos/empleados.txt","r");
	while (!feof($a))
	{
		array_push($contenido, explode("-", fgets($a)));
	}
	foreach ($contenido as $r)
	{
		if (count($r) == 8)
		{
			$e = new Empleado($r[0], $r[1], $r[2], $r[3], $r[4], $r[5], $r[6], $r[7]);
			$htmlOutput .= "<tr><td>" . $e->ToString() . "<img src='../" . $e->GetPathFoto() . "' width='90' height='90'> <a href='../eliminar.php?legajo=" . $e->GetLegajo() . "'> Eliminar</a> <input type=" . "'button' id='btnModificar' value='Modificar' onclick='Main.AdministrarModificar(" . $e->GetDni() .")'></td></tr>";
		}
	}
	fclose($a);
}
catch (Exception $e)
{
	echo "Error al intentar abrir el archivo.</br>";
}

$htmlOutput .= "</table>
    <form action='../index.php' id='hdnForm' method='POST'><input type='hidden' id='hdnModificar' name='dni'></form>";

echo $htmlOutput;
?>
</body>
</html>

<a href="../index.php">Alta de Empleados</a></br>
<a href="./cerrarSesion.php">Log out</a>