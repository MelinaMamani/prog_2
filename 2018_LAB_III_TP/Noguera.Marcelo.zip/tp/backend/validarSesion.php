<?php
/*Agregar la página validarSesion.php que verifique si la variable de sesión DNIEmpleado existe o no.
En el caso de no existir, redireccionar hacia login.html.*/
	session_start();
	if ($_SESSION["DNIEmpleado"] == NULL)
	{
		if (file_exists("./login.html"))
		{
	 		header("Location: ./login.html");
		}
	}
?>