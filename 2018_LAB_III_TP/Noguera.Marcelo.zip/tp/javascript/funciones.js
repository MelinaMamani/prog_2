var Main = /** @class */ (function () {
    function Main() {
    }
    Main.ValidarCamposVacios = function (id) {
        var v = document.getElementById(id).value;
        if (v.length == 0) {
            return false;
        }
        return true;
    };
    Main.ValidarRangoNumerico = function (valor, minimo, maximo) {
        if ((valor >= minimo) && (valor <= maximo)) {
            return true;
        }
        return false;
    };
    Main.ObtenerTurnoSeleccionado = function () {
        if (document.getElementById("rdoTurno").checked) {
            return document.getElementById("rdoTurno").value;
        }
        return "";
    };
    Main.ObtenerSueldoMaximo = function (turno) {
        if (turno === void 0) { turno = Main.ObtenerTurnoSeleccionado(); }
        var r = 20000;
        if (turno == "t") {
            r = 18500;
        }
        else {
            if (turno == "n") {
                r = 25000;
            }
        }
        return r;
    };
    Main.ValidarCombo = function (id, erroneo) {
        if (document.getElementById(id).value != erroneo) {
            return true;
        }
        return false;
    };
    Main.AdministrarValidaciones = function () {
        var isCorrect = true;
        var ids = new Array(["txtApellido", "spTxtApellido"], ["txtNombre", "spTxtNombre"], ["txtLegajo", "spTxtLegajo"], ["txtSueldo", "spTxtSueldo"], ["txtDni", "spTxtDni"], ["fileFoto", "spFileFoto"]);
        ids.forEach(function (element) {
            if (Main.ValidarCamposVacios(element[0]) == false) {
                Main.AdministrarSpanError(element[1], false);
                isCorrect = false;
                //alert("El elemento " + element + " está vacío.");
            }
            var v = Number(document.getElementById(element[0]).value);
            var r = Array(100, 550);
            if (element[0] == "txtDni") {
                r[0] = 1000000;
                r[1] = 55000000;
            }
            else {
                if (element[0] == "txtSueldo") {
                    r[0] = 8000;
                    r[1] = Main.ObtenerSueldoMaximo();
                }
            }
            if ((element[0] == "txtDni") || (element[0] == "txtSueldo") || (element[0] == "txtLegajo")) {
                if (!Main.ValidarRangoNumerico(v, r[0], r[1])) {
                    Main.AdministrarSpanError(element[1], false);
                    isCorrect = false;
                    //alert("El elemento " + element + " está fuera de rango.");
                }
            }
        });
        if (!Main.ValidarCombo("cboSexo", "---")) {
            Main.AdministrarSpanError("spCboSexo", false);
            isCorrect = false;
            //alert("El elemento cboSexo no está seteado.");
        }
        if (isCorrect) {
            document.getElementById("formIndex").submit();
        }
    };
    Main.AdministrarSpanError = function (elemento, ocultar) {
        if (ocultar) {
            document.getElementById(elemento).style.display = "none";
        }
        else {
            document.getElementById(elemento).style.display = "block";
        }
    };
    Main.VerificarValidacionesLogin = function () {
        var retorno = true;
        if (!Main.ValidarCamposVacios("txtApellido")) {
            Main.AdministrarSpanError("spTxtApellido", false);
            retorno = false;
        }
        if (!Main.ValidarCamposVacios("txtDni")) {
            Main.AdministrarSpanError("spTxtDni", false);
            retorno = false;
        }
        else {
            var v = Number(document.getElementById("txtDni").value);
            if (!Main.ValidarRangoNumerico(v, 1000000, 55000000)) {
                Main.AdministrarSpanError("spTxtDni", false);
                retorno = false;
            }
        }
        return retorno;
    };
    Main.AdministrarValidacionesLogin = function () {
        if (Main.VerificarValidacionesLogin()) {
            Main.AdministrarSpanError("spTxtApellido", true);
            Main.AdministrarSpanError("spTxtDni", true);
            document.getElementById("formLogin").submit();
            //alert("Todo en orden.");
        }
        else {
            //alert("Error.");
        }
    };
    Main.AdministrarModificar = function (dni) {
        alert("...");
        document.getElementById('hdnModificar').setAttribute('value', dni.toString());
        document.getElementById('hdnForm').submit();
    };
    return Main;
}());
