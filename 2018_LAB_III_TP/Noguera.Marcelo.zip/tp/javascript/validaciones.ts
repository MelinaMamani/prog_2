class Main
{
    public static ValidarCamposVacios(id : string) : boolean
    {
        let v : string = (<HTMLInputElement> document.getElementById(id)).value;
        if (v.length == 0)
        {
            return false;
        }
        return true;
    }

    public static ValidarRangoNumerico(valor : number, minimo : number, maximo : number) : boolean
    {
        if ((valor >= minimo) && (valor <= maximo))
        {
            return true;
        }
        return false;
    }

    public static ObtenerTurnoSeleccionado() : string
    {
        if ((<HTMLInputElement> document.getElementById("rdoTurno")).checked)
        {
            return (<HTMLInputElement> document.getElementById("rdoTurno")).value;
        }
        return "";
    }

    public static ObtenerSueldoMaximo(turno : string = Main.ObtenerTurnoSeleccionado())
    {
        let r : number = 20000;
        if (turno == "t")
        {
            r = 18500;
        }
        else
        {
            if (turno == "n")
            {
                r = 25000;
            }
        }
        return r;
    }

    public static ValidarCombo(id : string, erroneo : string) : boolean
    {
        if ((<HTMLInputElement> document.getElementById(id)).value != erroneo)
        {
            return true;
        }
        return false;
    }

    public static AdministrarValidaciones()
    {
        let isCorrect : boolean = true;
        let ids = new Array(["txtApellido","spTxtApellido"], ["txtNombre","spTxtNombre"], ["txtLegajo","spTxtLegajo"], ["txtSueldo","spTxtSueldo"], ["txtDni","spTxtDni"], ["fileFoto","spFileFoto"]);
        ids.forEach(element => {
            if (Main.ValidarCamposVacios(element[0]) == false)
            {
                Main.AdministrarSpanError(element[1], false);
                isCorrect = false;
                //alert("El elemento " + element + " está vacío.");
            }
            
            let v = Number((<HTMLInputElement> document.getElementById(element[0])).value);
            let r = Array(100, 550);
            
            if (element[0] == "txtDni")
            {
                r[0] = 1000000;
                r[1] = 55000000;
            }
            else
            {
                if (element[0] == "txtSueldo")
                {
                    r[0] = 8000;
                    r[1] = Main.ObtenerSueldoMaximo();
                }
            }

            if ((element[0] == "txtDni") || (element[0] == "txtSueldo") || (element[0] == "txtLegajo"))
            {
                if (!Main.ValidarRangoNumerico(v, r[0], r[1]))
                {
                    Main.AdministrarSpanError(element[1], false);
                    isCorrect = false;
                    //alert("El elemento " + element + " está fuera de rango.");
                }
            }
        });
        if (!Main.ValidarCombo("cboSexo", "---"))
        {
            Main.AdministrarSpanError("spCboSexo", false);
            isCorrect = false;
            //alert("El elemento cboSexo no está seteado.");
        }

        if (isCorrect)
        {
            (<HTMLFormElement> document.getElementById("formIndex")).submit();
        }
    }

    public static AdministrarSpanError(elemento : string, ocultar : boolean)
    {
        if (ocultar)
        {
            (<HTMLInputElement> document.getElementById(elemento)).style.display = "none";
        }
        else
        {
            (<HTMLInputElement> document.getElementById(elemento)).style.display = "block";
        }
    }

    public static VerificarValidacionesLogin() : boolean
    {
        let retorno : boolean = true;

        if (!Main.ValidarCamposVacios("txtApellido"))
        {
            Main.AdministrarSpanError("spTxtApellido", false);
            retorno = false;
        }
        if (!Main.ValidarCamposVacios("txtDni"))
        {
            Main.AdministrarSpanError("spTxtDni", false);
            retorno = false;
        }
        else
        {
            let v = Number((<HTMLInputElement> document.getElementById("txtDni")).value);
            if (!Main.ValidarRangoNumerico(v, 1000000, 55000000))
            {
                Main.AdministrarSpanError("spTxtDni", false);
                retorno = false;
            }
        }

        return retorno;
    }

    public static AdministrarValidacionesLogin()
    {
        if (Main.VerificarValidacionesLogin())
        {
            Main.AdministrarSpanError("spTxtApellido", true);
            Main.AdministrarSpanError("spTxtDni", true);
            (<HTMLFormElement> document.getElementById("formLogin")).submit();
        }
    }

    public static AdministrarModificar(dni : Number)
    {
        (<HTMLInputElement>document.getElementById('hdnModificar')).setAttribute('value', dni.toString());
        (<HTMLFormElement>document.getElementById('hdnForm')).submit();
    }
}