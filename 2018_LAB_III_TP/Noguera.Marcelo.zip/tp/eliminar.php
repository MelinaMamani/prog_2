<?php
require_once "./clases/fabrica.php";


$legajo = $_GET['legajo'];

$fabrica = new Fabrica("Nada", 7);
$eL = $fabrica->BuscarEmpleadoPorLegajo($legajo, "./archivos/empleados.txt");

if($eL != FALSE)
{
	if ($fabrica->EliminarEmpleado($eL))
	{
	    echo "El empleado con el legajo " . $legajo . " fue eliminado.";
	    $fabrica->GuardarEnArchivo("./archivos/empleados.txt");
	}
	else
	{
	    echo "Error: El empleado con el legajo " . $legajo . " no fue eliminado.";
	}
}
else
{
	echo "Error: No se encontró el empleado con ese legajo.";
}

echo "</br><a href='./backend/mostrar.php'>Mostrar</a></br>";
echo "<a href='./index.html'>Index</a></br>";
?>