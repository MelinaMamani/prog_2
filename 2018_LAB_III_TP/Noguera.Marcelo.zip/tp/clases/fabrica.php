<?php
include_once "persona.php";
include_once "empleado.php";
include_once "interfaces.php";
class Fabrica implements IArchivo
{
	private $_cantidadMaxima;
	private $_empleados;
	private $_razonSocial;

	function __construct($razonSocial, $cantidadMaxima = 5)
	{
		$this->_cantidadMaxima = $cantidadMaxima;
        $this->_empleados = array();
        $this->_razonSocial = $razonSocial;
	}

	public function AgregarEmpleado(Empleado $e)
	{
		if(count($this->_empleados) < $this->_cantidadMaxima)
        {
            foreach($this->_empleados as $value)
            {
                if(($value->GetLegajo() == $e->GetLegajo()) || ($value->GetDni() == $e->GetDni()))
                {
                    return FALSE;
                }
            }
            array_push($this->_empleados, $e);
            $this->_empleados = $this->EliminarEmpleadosRepetidos();
            //echo "Empleado agregado: " . $e->ToString() . "</br>";
            return TRUE;
        }
        else
        {
            echo "Error: Cantidad maxima alcanzada. No se pudo agregar el empleado.</br>";
        }
        return FALSE;
	}

	public function CalcularSueldos()
	{
		$sueldo = 0;
        foreach($this->_empleados as &$valor)
        {
            $sueldo += $valor->_sueldo;
        }
        return $sueldo;
	}

	public function EliminarEmpleado(Empleado $e)
	{
		for ($i = 0; $i < count($this->_empleados); $i++)
        {
            if ($this->_empleados[$i]->GetDni() == $e->GetDni())
            {
                unset($this->_empleados[$i]);
                $this->_cantidadMaxima = $this->_cantidadMaxima + 1;
                // Falta la eliminación de la imagen del empleado.
                return TRUE;
            }
        }
        echo "Error no se pudo eliminar el empleado. El DNI no se encontro.</br>";
        return FALSE;
	}

	private function EliminarEmpleadosRepetidos()
    {
        return array_unique($this->_empleados, SORT_REGULAR);
    }
    
    public function ToString()
    {
        $empleados = $this->_razonSocial . " - Empleados:<br>";
        foreach($this->_empleados as &$valor)
        {
            $empleados = $empleados . $valor->ToString() . "<br>";
        }
        return $empleados;
    }

    public function GuardarEnArchivo($nombreArchivo)
    {
        $a = fopen($nombreArchivo,"w");
        foreach($this->_empleados as $e)
        {
            try
            {
                fwrite($a, $e->ToString() . "\n");
            }
            catch (Exception $e)
            {
                return FALSE;
            }
        }
        fclose($a);

        return TRUE;
    }

    public function TraerDeArchivo($nombreArchivo)
    {
        $contenido = array();
        $empleados = array();
        $retorno = TRUE;
        $msg = "";

        try
        {
            $a = fopen($nombreArchivo,"r");
            while (!feof($a))
            {
                $l = fgets($a);
                if (!array_push($contenido, explode("-", $l)))
                {
                    $msg .= "Error al leer desde archivo, lo leído fue:</br>     " . $l . "</br>";
                    $retorno = FALSE;
                }
            }
            foreach ($contenido as $r)
            {
                //echo "Antes del count...</br>";
                if (count($r) == 8)
                {
                    //echo "Luego del count...</br>";
                    $e = new Empleado($r[0], $r[1], $r[2], $r[3], $r[4], $r[5], $r[6], $r[7]);
                    //echo "Empleado antes: " . $e->ToString() . "</br>";
                    if (!$this->AgregarEmpleado($e))
                    {
                        //echo "Empleado agregado: " . $e->ToString() . "</br>";
                        $retorno = FALSE;
                    }
                }
            }
            fclose($a);
        }
        catch (Exception $e)
        {
            echo "Error al intentar abrir el archivo.";
            return FALSE;
        }
        

        echo $msg;

        return $retorno;
    }

    public function BuscarEmpleado($dni, $apellido, $nombreArchivo)
    {
        if ($this->TraerDeArchivo($nombreArchivo))
        {
            //echo "En TraerDeArchivo...</br>";
            foreach($this->_empleados as &$e)
            {
                //echo "((" . $e->GetDni() . " == " . $dni . ") -- (" . $e->GetApellido() . " == " . $apellido . "))</br>";
                if (($e->GetDni() == $dni) && ($e->GetApellido() == $apellido))
                {
                    return TRUE;
                }
            }
        }
        return FALSE;
    }

    public function BuscarEmpleadoPorLegajo($legajo, $nombreArchivo)
    {
        if ($this->TraerDeArchivo($nombreArchivo))
        {
            foreach($this->_empleados as $e)
            {
                //echo "(" . $e->GetLegajo() . " == " . $legajo . ")</br>";
                if ($e->GetLegajo() == $legajo)
                {
                    return $e;
                }
            }
        }
        return FALSE;
    }

    public function BuscarEmpleadoPorDni($dni, $nombreArchivo)
    {
        if ($this->TraerDeArchivo($nombreArchivo))
        {
            //echo "Traidos desde archivo.</br>";
            foreach($this->_empleados as $e)
            {
                if ($e->GetDni() == $dni)
                {
                    return $e;
                }
            }
        }
        return FALSE;
    }

    public function GetEmpleados()
    {
        return $this->_empleados;
    }
}
?>