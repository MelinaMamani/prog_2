<?php
include_once 'clases/persona.php';
include_once 'clases/empleado.php';
include_once 'clases/fabrica.php';

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);

$dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;
$apellido = isset($_POST["apellido"]) ? $_POST["apellido"] : NULL;
$nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : NULL;
$sexo = isset($_POST["sexo"]) ? $_POST["sexo"] : NULL;
$legajo = isset($_POST["legajo"]) ? $_POST["legajo"] : NULL;
$sueldo = isset($_POST["sueldo"]) ? $_POST["sueldo"] : NULL;
$turno = isset($_POST["turno"]) ? $_POST["turno"] : NULL;
$foto = isset($_FILES["foto"]) ? $_FILES["foto"] : NULL;

$dniModificar = isset($_POST["hdnModificar"]) ? $_POST["hdnModificar"] : NULL;
//$foto = $_FILES["foto"];

/*array(1) { ["foto"]=> array(5) { ["name"]=> string(10) "Conejo.jpg" ["type"]=> string(10) "image/jpeg" ["tmp_name"]=> string(25) "/opt/lampp/temp/phpA2bCHG" ["error"]=> int(0) ["size"]=> int(58385) } }
Conejo.jpg*/

//echo var_dump($_FILES);
//echo "</br>" . var_dump($foto);
//$algo = "algo";
//echo "</br>" . var_dump($foto["name"]);
//echo "</br>" . "</br>" . $foto["name"];
//$nombre = "" . $foto["name"];
//1.486.117
//echo "</br>" . "</br>" . var_dump($foto["size"]);

$imagenDeExtensionValida = FALSE;
$extension = "";
$extensiones = array("JPG", "BMP", "GIF", "PNG", "JPEG", "jpg", "bmp", "gif", "png", "jpeg");
foreach ($extensiones as $x)
{
	$i = 0;
	while (TRUE)
	{
		if ($foto["type"][$i] != NULL)
		{
			if ($foto["type"][$i] == "/")
			{
				$exAux = "";
				for ($j=1; $j < 5; $j++)
				{
					if ($foto["type"][$i + $j] != NULL)
					{
						$exAux .= $foto["type"][$i + $j];
					}
				}

				if ($x == $exAux)
				{
					$extension = $exAux;
					$imagenDeExtensionValida = TRUE;
					break;
				}

			}
			$i++;
		}
		else
		{
			break;
		}
	}
}

$tamanioValido = FALSE;
if ($foto["size"] <= 1000000)
{
	$tamanioValido = TRUE;
}

$noExisteElArchivo = FALSE;
if (!file_exists("./fotos/" . $dni . "-" . $apellido . "." . $extension))
{
	//echo "</br></br>./fotos/" . $dni . "-" . $apellido . "." . $extension . "No existe.";
	$noExisteElArchivo = TRUE;
}

if ($imagenDeExtensionValida && $tamanioValido && $noExisteElArchivo)
{
	$link = "<a href='backend/mostrar.php'>Mostrar</a>";

	$e = new Empleado($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno, "./fotos/" . $dni . "_" . $apellido . "." . $extension);
	$f = new Fabrica("Ninguna", 7);
	$traidos = $f->TraerDeArchivo("./archivos/empleados.txt");
	if ($dniModificar)
	{
		//echo "Line 98.</br>";
		if ($traidos)
		{
			//echo "Line 101.</br>";
			$eSM = $f->BuscarEmpleadoPorDni($dniModificar, "./archivos/empleados.txt");
			//echo $eSM->ToString() . "</br>";
			if ($eSM)
			{
				if (!(($f->EliminarEmpleado($eSM)) && ($f->AgregarEmpleado($e)) && ($f->GuardarEnArchivo("./archivos/empleados.txt"))))
				{
					$link = "<a href='./index.php'>Index</a>";
				}
			}
		}
	}
	else
	{
		if (!(($traidos) && ($f->AgregarEmpleado($e)) && ($f->GuardarEnArchivo("./archivos/empleados.txt"))))
		{
			$link = "<a href='./index.php'>Index</a>";
		}
	}
	echo $link;

	// Cuando estoy usando otro equipo.
	//move_uploaded_file($foto["tmp_name"], "./fotos/" . $dni . "_" . $apellido . "." . $extension);
	// Cuando estoy usando mi propio equipo.
	system("cp /home/leonel/bk_sin_uso/Images,videos,etc/". $foto["name"] . " fotos/" . $dni . "_" . $apellido . "." . $extension);
}

?>