<?php
include_once 'clases/persona.php';
include_once 'clases/empleado.php';
include_once 'clases/fabrica.php';
include_once './backend/validarSesion.php';

$dniValue = isset($_POST["dni"]) ? ("value=" . $_POST["dni"] . " readonly") : NULL;
$dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;

$apellido = NULL;
$nombre = NULL;
$legajo = NULL;
$legajoValue = NULL;
$sueldo = NULL;

$cboM = NULL;
$cboF = NULL;

$rdoM = NULL;
$rdoT = NULL;
$rdoN = NULL;

$tituloH2 = "Alta de Empleados";
$titulo = "HTML 5 - Formulario Alta Empleado";
$btnEnviar = "Enviar";
$hdnModificar = NULL;

//asd         asd    1000000  M      100      8000      m    fotos/1000000_asd.jpg
//$nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno, $pathFoto
if ($dni != NULL)
{
    $f = new Fabrica("Ninguna", 7);
    if ($f->TraerDeArchivo("./archivos/empleados.txt"))
    {
        foreach ($f->GetEmpleados() as $e)
        {
            if ($e->GetDni() == $dni)
            {
                //echo "Se encontro...</br>";
                $tituloH2 = "Modificar Empleado";
                $titulo = "HTML 5 - Formulario Modificar Empleado";
                $btnEnviar = "Modificar";

                $hdnModificar = "<input type='hidden' name='hdnModificar' id='hdnModificar' value='" . $dni . "'>";

                $nombre = $e->GetNombre();
                $apellido = $e->GetApellido();
                
                if($e->GetSexo() == "M")
                {
                    $cboM = "selected";
                }
                else
                {
                    $cboF = "selected";
                }

                $legajoValue = "value=" . $e->GetLegajo() . " readonly";
                
                $sueldo = $e->GetSueldo();

                if($e->GetTurno() == "m")
                {
                    $rdoM = "checked";
                }
                else
                {
                    if($e->GetTurno() == "t")
                    {
                        $rdoT = "checked";
                    }
                    else
                    {
                        $rdoN = "checked";
                    }
                }
            }
        }
    }
}

//echo "El nombre es: " . $nombre . "</br>";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $titulo; ?></title>
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />-->
    <script src="./javascript/funciones.js"></script>
</head>
<body id="indexBody">
    <h2><?php echo $tituloH2; ?></h2>
    <form id="formIndex" action="./administracion.php" method="post" enctype="multipart/form-data">
        <table align="center">
            <tr>
                <td>
                	<h4>Datos Personales</h4>
                	<hr>
                </td>
            </tr>
            <tr>
                <td>
                	DNI: <input type="number" min="1000000" max="55000000" id="txtDni" name="dni" <?php echo $dniValue; ?>/><span id="spTxtDni" style="display:none"> *</span>
                </td>
            </tr>
            <tr>
                <td>
                	Apellido: <input type="text" id="txtApellido" name="apellido" <?php echo "value='" . $apellido . "'"; ?>/><span id="spTxtApellido" style="display:none"> *</span>
                </td>
            </tr>
            <tr>
                <td>
                	Nombre: <input type="text" id="txtNombre" name="nombre" <?php echo "value='" . $nombre . "'"; ?>/><span id="spTxtNombre" style="display:none"> *</span>
                </td>
            </tr>
            <tr>
                <td>
	                Sexo: <select id="cboSexo" size=1 name="sexo"><span id="spCboSexo" style="display:none"> *</span>
	                    <option value="---">Seleccione</option>
	                    <option value="M" <?php echo $cboM?>>Masculino</option>
	                    <option value="F" <?php echo $cboF?>>Femenino</option>
	                </select>
                </td>
            </tr>
            <tr>
            	<td>
            		<h4>Datos Laborales</h4>
            		<hr>
            	</td>
           	</tr>
           	<tr>
                <td>
                	Legajo: <input type="number" min="100" max="550" id="txtLegajo" name="legajo" <?php echo $legajoValue; ?>/><span id="spTxtLegajo" style="display:none"> *</span>
                </td>
            </tr>
            <tr>
                <td>
                	Sueldo: <input type="number" min="8000" max="25000" id="txtSueldo" step="500" name="sueldo" <?php echo "value='" . $sueldo . "'"; ?>/><span id="spTxtSueldo" style="display:none"> *</span>
                </td>
            </tr>
            <tr>
                <td>
                	Turno:
                </td>
            </tr>
            <tr>
            	<td align="center">
            		<input type="radio" id="rdoTurno" value="m" name="turno" <?php echo $rdoM?>> Mañana
            	</td>
            </tr>
            <tr>
        		<td align="center">
            		<input type="radio" id="rdoTurno" value="t" name="turno" <?php echo $rdoT?>> Tarde
            	</td>
            </tr>
            <tr>
        		<td align="center">
            		<input type="radio" id="rdoTurno" value="n" name="turno" <?php echo $rdoN?>> Noche
            	</td>
            </tr>
            <tr>
                <td align="center">
                    Foto: <input type="file" id="fileFoto" name="foto"><span id="spFileFoto" style="display:none"> *</span>
                </td>
            </tr>
            <tr>	
				<td colspan="2" align="right">
					<hr>
					<input type="submit" id="btnLimpiar" value="Limpiar" />
				</td>
			</tr>
            <tr>
				<td colspan="2" align="right">
					<input type="button" id="btnEnviar" name="btnEnviar" value=<?php echo $btnEnviar?> onclick="Main.AdministrarValidaciones()">
				</td>
			</tr>
            <?php echo $hdnModificar?>
        </table>
    </form>
    <a href="./backend/cerrarSesion.php">Log out</a>
</body>
</html>