<?php
    /*
        require_once "./backend/validarSesion.php";
        session_destroy();
        sleep(5);
        header('Location: ./login.html');
    */
    