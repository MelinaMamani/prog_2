<?php

    require_once "./clases/persona.php";
    require_once "./clases/empleado.php";
    require_once "./clases/interfaces.php";
    require_once "./clases/fabrica.php";
    

    $leg = $_GET['nLeg'];
    //buscar en archivo
    $fabrica = new Fabrica("test",9999);
    $fabrica->TraerDeArchivo("./archivos/archivos.txt");
    //var_dump($fabrica);
    $empAEliminar = $fabrica->BuscarEmpleadoPorLegajo($leg);

    //var_dump($empAEliminar);
    
    if($empAEliminar != false)
        $eliminado = $fabrica->EliminarEmpleado($empAEliminar);   

    if ($eliminado) {
        echo "el empleado con el Nºde leg: ".$leg. "  fue eliminado";
        $fabrica->GuardarEnArchivo("./archivos/archivos.txt");
    }else{
        echo "el empleado con el Nºde leg: ".$leg. "  no fue eliminado";
    }
    echo '<a href="./index.html">volver</a>';
    echo '<a href="./mostrar.php">Mostrar</a>';

    // links a mostrar o a index*/
    ?>