
<?php
    require_once "./clases/persona.php";
    require_once "./clases/empleado.php";    
    //require_once "./backend/validarSesion.php";
        
        
    $archivo = fopen("./archivos/archivos.txt","r");
    $encabezado=    '<html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <meta http-equiv="X-UA-Compatible" content="ie=edge">
                            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
                            
                        </head>
                        <body>';
    $cierreEncabezado=  '</body>
                    </html>';
    $tabla= "<h2>Alta de empleados</h2>
                <div class='container-fluid' >
                    <hr size='10' width='95%' style='color: #0056b2;' />
                    <h4>Info</h4>
                    <table border=1>
                        <tr>
                            <td>dni</td>
                            <td>nombre</td>
                            <td>apellido</td>
                            <td>sexo</td>
                            <td>leg</td>
                            <td>sueldo</td>
                            <td>turno</td>
                            <td>foto</td>
                            <td>eliminar</td>
                        <tr>";
    
    while(($recupero=fgets($archivo))!=null){
        $array=explode("-",$recupero);
        for ($i=0; $i <count($array); $i++) { 
            $array[$i]=trim($array[$i]);
        }
        $retVal = ($array[6]==1) ? "M" : ($retVal = ($array[6]==2) ? "T" : "N");
        $tabla.=    "<tr>
                        <td>$array[2]</td>
                        <td>$array[0]</td>
                        <td>$array[1]</td>
                        <td>$array[3]</td>
                        <td>$array[4]</td>
                        <td>$array[5]</td>                        
                        <td>$retVal</td>
                        <td>
                            <img src=\"$array[7]\" height=\"100 px\" width=\"100 px\" >
                        </td>                     
                        <td><a href='./eliminar.php?nLeg=$array[4]'>eliminar</a></td>
                    <tr>";
        $empleadoRecuperado=new Empleado($array[0],$array[1],$array[2],$array[3],$array[4],$array[5],$array[6]);
        $empleadoRecuperado->SetPathFoto($array[7]);
        //echo $empleadoRecuperado->ToString(). '<a href="./eliminar.php?nLeg='.$array[4].'">eliminar</a>'."<br>";
    }
    $tabla.=        "</table>
                    <hr size='10' width='95%' style='color: #0056b2;' />
                </div>";
    echo $encabezado.$tabla.'<a href="./index.php">Alta Empleados</a>'."<br>".$cierreEncabezado;
