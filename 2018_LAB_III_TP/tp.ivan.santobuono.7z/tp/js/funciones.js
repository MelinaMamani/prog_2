"use strict";
var Test;
(function (Test) {
    //CREO UNA INSTANCIA DE XMLHTTPREQUEST
    var xhttp = new XMLHttpRequest();
    function ValidarUsuario() {
        var usuario = document.getElementById('usuarioTxt').value;
        var pass = document.getElementById('passTxt').value;
        //METODO; URL; ASINCRONICO?
        xhttp.open("POST", "./validar.php", true);
        //SETEO EL ENCABEZADO DE LA PETICION	
        xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        //ENVIO DE LA PETICION CON LOS PARAMETROS
        xhttp.send("uss=" + usuario + "&pass=" + pass);
        //FUNCION CALLBACK
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                if (xhttp.responseText === "ok") {
                    //alert(xhttp.responseText);
                    document.getElementById("DivLoguin").style.backgroundColor = "green";
                    //document.body.style.backgroundColor=""
                }
                else {
                    //alert(xhttp.responseText);
                    document.getElementById("DivLoguin").style.backgroundColor = "red";
                }
            }
        };
    }
    Test.ValidarUsuario = ValidarUsuario;
    function TraerTodos() {
        xhttp.open("POST", "./administrar.php", true);
        //SETEO EL ENCABEZADO DE LA PETICION	
        xhttp.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        //ENVIO DE LA PETICION CON LOS PARAMETROS
        xhttp.send("queHago=todos");
        //FUNCION CALLBACK
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                document.getElementById("todos").nodeValue = "awd";
                /*if (xhttp.responseText === "ok"){
                    //alert(xhttp.responseText);
                    //(<HTMLDivElement>document.getElementById("DivLoguin")).style.backgroundColor = "green";
                    //document.body.style.backgroundColor=""
                }else{
                    //alert(xhttp.responseText);
                    //(<HTMLDivElement>document.getElementById("DivLoguin")).style.backgroundColor = "red";
                }*/
            }
        };
    }
    Test.TraerTodos = TraerTodos;
    function ValidarCamposVacios(id) {
        return ValidarCombo(id, "");
    }
    Test.ValidarCamposVacios = ValidarCamposVacios;
    function ValidarCombo(id, valError) {
        if (document.getElementById(id).value !== valError) {
            //AdministrarSpanError(id,true);
            return true;
        }
        //AdministrarSpanError(id,false);
        return false;
    }
    Test.ValidarCombo = ValidarCombo;
    function ObtenerTurnoSeleccionado() {
        var turno = "";
        if (document.getElementById('0').checked) {
            turno = document.getElementById('0').value;
        }
        else if (document.getElementById('1').checked) {
            turno = document.getElementById('1').value;
        }
        else if (document.getElementById('2').checked) {
            turno = document.getElementById('2').value;
        }
        //let onselect:any = turno.onselect();
        return turno;
    }
    Test.ObtenerTurnoSeleccionado = ObtenerTurnoSeleccionado;
    function ObtenerSueldoMaximo(t) {
        var sueldo = 0;
        if (t == "0") {
            //mañana
            //(<HTMLInputElement> document.getElementById("sueldoTxt")).max=20000;
            sueldo = 20000;
        }
        else if (t == "1") {
            //tarde
            sueldo = 18500;
        }
        else if (t == "2") {
            //noche
            sueldo = 25000;
        }
        //console.log("valor: "+t);
        return sueldo;
    }
    Test.ObtenerSueldoMaximo = ObtenerSueldoMaximo;
    function cambiarSueldoMax() {
        document.getElementById("sueldoTxt").max = ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()).toString();
    }
    Test.cambiarSueldoMax = cambiarSueldoMax;
    function ValidarRangoNumerico(num, min, max) {
        return (num >= min && num <= max);
    }
    Test.ValidarRangoNumerico = ValidarRangoNumerico;
    function AdministrarSpanError(campo, bool) {
        if (!bool) {
            document.getElementById(campo).style.display = "block";
        }
        else {
            document.getElementById(campo).style.display = "none";
        }
    }
    Test.AdministrarSpanError = AdministrarSpanError;
    function enviar() {
        if (!ValidarCamposVacios('dniTxt')) {
            AdministrarSpanError('dniSpan', false);
            //alert("Complete el campo DNI");
            return false;
        }
        if (!ValidarCamposVacios('apellidoTxt')) {
            AdministrarSpanError('apellidoSpan', false);
            //alert("Complete el campo APELLIDO");
            return false;
        }
        if (!ValidarCamposVacios('nombreTxt')) {
            AdministrarSpanError('nombreSpan', false);
            //alert("Complete el campo NOMBRE"); 
            return false;
        }
        if (!ValidarCamposVacios('legajoTxt')) {
            AdministrarSpanError('legajoSpan', false);
            //alert("Complete el campo LAGAJO"); 
            return false;
        }
        if (!ValidarCombo('comboBoxSexo', "---")) {
            AdministrarSpanError('sexoSpan', false);
            //alert("ELIJA un SEXO");
            return false;
        }
        if (!ValidarCamposVacios('sueldoTxt')) {
            AdministrarSpanError('sueldoSpan', false);
            //alert("Complete el campo SUELDO"); 
            return false;
        }
        if (document.getElementById("archivos").value == "") {
            AdministrarSpanError("filesSpan", false);
            return false;
        }
        //AdministrarSpanError(id,false);
        return true;
    }
    Test.enviar = enviar;
    function AdministrarValidacionesLogin() {
        if (!ValidarCamposVacios('dniTxt')) {
            AdministrarSpanError('dniSpan', false);
            //alert("Complete el campo DNI");
            return false;
        }
        else {
            AdministrarSpanError('dniSpan', true);
        }
        if (!ValidarCamposVacios('apellidoTxt')) {
            AdministrarSpanError('apellidoSpan', false);
            //alert("Complete el campo DNI");
            return false;
        }
        else {
            AdministrarSpanError('apellidoSpan', true);
        }
        if (!ValidarRangoNumerico(parseInt(document.getElementById("dniTxt").value), 1000000, 55000000)) {
            return false;
        }
    }
    Test.AdministrarValidacionesLogin = AdministrarValidacionesLogin;
    function VerificarValidacionesLogin() {
        AdministrarValidacionesLogin();
        var spanDni = document.getElementById('dniSpan').style.display !== "block";
        var spanApellido = document.getElementById('apellidoSpan').style.display !== "block";
        if (spanDni && spanApellido) {
            return true;
        }
        return false;
    }
    Test.VerificarValidacionesLogin = VerificarValidacionesLogin;
})(Test || (Test = {}));
//# sourceMappingURL=funciones.js.map