<?php


class Fabrica implements IArchivo{
    private $_cantidadMaxima;
    public $_empleados;
    private $_razonSocial;

    function __construct($razonSocial,$cantmax=5) {
        $this->_empleados=array();
        $this->_cantidadMaxima=$cantmax;        
        $this->_razonSocial=$razonSocial;
    }

    public function TraerDeArchivo($name){
        $archivo = fopen($name,"r");
        
        while(($recupero=fgets($archivo))!=null){
            //echo "dentro del while";
            $array=explode("-",$recupero);
            for ($i=0; $i <count($array); $i++) { 
                $array[$i]=trim($array[$i]);
            }
            
            $empleadoRecuperado=new Empleado($array[0],$array[1],$array[2],$array[3],$array[4],$array[5],$array[6]);
            //echo $empleadoRecuperado->ToString()."<br>";
            $empleadoRecuperado->SetPathFoto($array[7]);
            $this->AgregarEmpleado($empleadoRecuperado);
        }
        fclose($archivo);
    }
  
    public function GuardarEnArchivo($name){
        $archivo = fopen($name,"w");
        foreach ($this->_empleados as  $empleado) {
            # code...
            fwrite($archivo,$empleado->ToString());
        }
        fclose($archivo);
    }

    /**
     * AgregarEmpleado
     */
    function AgregarEmpleado($emp) {

        if (count($this->_empleados) < $this->_cantidadMaxima) {       
            array_push($this->_empleados,$emp);
            $this->EliminarEmpleadoRepetido();           
            return true;            
        }else{
            echo("fabrica llena <br>");
            return false;
        }
    }
    /**
     * CalcularSueldo
     */
    function CalcularSueldos() {
        $sueldos=0;
        for ($i=0; $i < count($this->_empleados); $i++) { 
            # code...
            $sueldos+=$this->_empleados[$i].GetSueldo();            
        }
        return $sueldos;
    }
    /**
     * EliminarEmpleado
     */
    function BuscarEmpleadoPorDNIyNombre($numero,$nombre){
        //echo $asd;
        //var_dump($this->_empleados);
        foreach ($this->_empleados as  $empleado) {
               
            if ($numero == $empleado->GetDni() && $nombre == $empleado->GetApellido()) {                
                return $empleado;
            }        
        }
        return false;        
    }
    function BuscarEmpleadoPorLegajo($asd){
        echo $asd;
        //var_dump($this->_empleados);
        foreach ($this->_empleados as  $empleado) {
               
            if ($asd == $empleado->GetLegajo()) {                
                return $empleado;
            }        
        }
        
    }

    function EliminarEmpleado($emp){
        $respuesta=false;
        for ($i=0; $i <count($this->_empleados) ; $i++) { 
            # code...        
            if ($emp === $this->_empleados[$i]) {
                unset($this->_empleados[$i]);
                $this->_empleados = array_values($this->_empleados);
                $respuesta= true;
            }        
        };
        return $respuesta;
    }
    /**
     * EliminarEmpleadoRepetido
     */
    private function EliminarEmpleadoRepetido() {
        $this->_empleados = array_values(array_unique($this->_empleados,SORT_REGULAR));
    }     
    
    /**
     * ToString
     */
    function ToString() {
        $cadena= $this->_razonSocial ."-".$this->_cantidadMaxima;
            foreach ($this->_empleados as  $value) {
                $cadena .="-" .$value->ToString();
            }
        $cadena .="\r\n";            
        
        return $cadena;     
    }
}
