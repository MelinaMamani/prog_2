<?php
require_once "./persona.php";
require_once "./empleado.php";
require_once "./interfaces.php";
require_once "./fabrica.php";



//(nombre:string, apellido:string, dni:number, sexo:string, legajo:number, sueldo:number,turno:string )
$empleado1 = new Empleado("alan", "lopez", 10101,"M",1, 17000, "mañana");
$empleado2 = new Empleado("laura", "ramirez", 20202,"F",2, 15000, "noche");
$empleado3 = new Empleado("daniela", "santos", 30303,"F",3, 23000, "mañana");
$empleado4 = new Empleado("daniel", "perez", 40404,"M",4, 12000, "tarde");
$empleado5 = new Empleado("matias", "solis", 50505,"M",5, 14000, "mañana");
$empleado6 = new Empleado("ivan", "lorenzo", 60606,"M",6, 17000, "mañana");
$empleado7 = new Empleado("leonardo", "gutierrez", 70707,"M",7, 15000, "noche");
$empleado8 = new Empleado("lucas", "palmieri", 80808,"M",8, 23000, "mañana");
$empleado9 = new Empleado("martin", "torres", 90909,"M",9, 12000, "tarde");
$empleado10 = new Empleado("franco", "duete", 101010,"M",10, 14000, "mañana");
$empleado11 = new Empleado("roxi", "perez", 111111,"F",11, 17000, "mañana");
$empleado12 = new Empleado("neolia", "morend", 121212,"F",12, 15000, "noche");
$empleado13 = new Empleado("sonia", "ramirez", 131313,"F",13, 23000, "mañana");
$empleado14 = new Empleado("sofy", "perez", 141414,"F",14, 12000, "tarde");
$empleado15 = new Empleado("claudia", "solis", 151515,"F",15, 14000, "mañana");

$array1= ["español","ingles", "frances"];
$array2= ["español","ingles", "frances","chino","aleman","portugues"];
$array3= ["español","ingles"];

$cerveceria= new Fabrica("cerveceria quilmes");
$coto= new Fabrica("coto quilmes");
$easy= new Fabrica("easy quilmes");

$empleado1->SetPathFoto("../fotos/18050404014237f.gif");
$empleado2->SetPathFoto("../fotos/18050404014237f.gif");
$empleado3->SetPathFoto("../fotos/18050404014237f.gif");
$empleado4->SetPathFoto("../fotos/18050404014237f.gif");
$empleado5->SetPathFoto("../fotos/18050404014237f.gif");
$empleado6->SetPathFoto("../fotos/18050404014237f.gif");
$empleado7->SetPathFoto("../fotos/18050404014237f.gif");
$empleado8->SetPathFoto("../fotos/18050404014237f.gif");
$empleado9->SetPathFoto("../fotos/18050404014237f.gif");
$empleado10->SetPathFoto("../fotos/18050404014237f.gif");
$empleado11->SetPathFoto("../fotos/18050404014237f.gif");
$empleado12->SetPathFoto("../fotos/18050404014237f.gif");
$empleado13->SetPathFoto("../fotos/18050404014237f.gif");
$empleado14->SetPathFoto("../fotos/18050404014237f.gif");
$empleado15->SetPathFoto("../fotos/18050404014237f.gif");


echo ("empleados creados: "."<br>");
echo ($empleado1->ToString()."<br>");
echo ($empleado2->ToString()."<br>");
echo ($empleado3->ToString()."<br>");
echo ($empleado4->ToString()."<br>");
echo ($empleado5->ToString()."<br>");
echo ($empleado6->ToString()."<br>");
echo ($empleado7->ToString()."<br>");
echo ($empleado8->ToString()."<br>");
echo ($empleado9->ToString()."<br>");
echo ($empleado10->ToString()."<br>");
echo ($empleado11->ToString()."<br>");
echo ($empleado12->ToString()."<br>");
echo ($empleado13->ToString()."<br>");
echo ($empleado14->ToString()."<br>");
echo ($empleado15->ToString()."<br>");


echo ("lengas de los empleados creados: "."<br>");
echo ($empleado1->Hablar($array1)."<br>");
echo ($empleado2->Hablar($array2)."<br>");
echo ($empleado3->Hablar($array3)."<br>");
echo ($empleado4->Hablar($array2)."<br>");
echo ($empleado5->Hablar($array1)."<br>");

$cerveceria->AgregarEmpleado($empleado1);
$cerveceria->AgregarEmpleado($empleado2);
$cerveceria->AgregarEmpleado($empleado3);
$cerveceria->AgregarEmpleado($empleado4);
$cerveceria->AgregarEmpleado($empleado5);

$coto->AgregarEmpleado($empleado6);
$coto->AgregarEmpleado($empleado7);
$coto->AgregarEmpleado($empleado8);
$coto->AgregarEmpleado($empleado9);
$coto->AgregarEmpleado($empleado10);
$coto->AgregarEmpleado($empleado11);// fabrica llena


$easy->AgregarEmpleado($empleado11);
$easy->AgregarEmpleado($empleado11);//repetido
$easy->AgregarEmpleado($empleado12);
$easy->AgregarEmpleado($empleado13);
$easy->AgregarEmpleado($empleado11);//repetido
$easy->AgregarEmpleado($empleado14);
$easy->AgregarEmpleado($empleado15);

echo ($cerveceria->ToString()."<br>");
echo ($coto->ToString()."<br>");
echo ($easy->ToString()."<br>");

$easy->GuardarEnArchivo("../archivos/archivos.txt");
$coto->GuardarEnArchivo("../archivos/archivos.txt");
$cerveceria->GuardarEnArchivo("../archivos/archivos.txt");

