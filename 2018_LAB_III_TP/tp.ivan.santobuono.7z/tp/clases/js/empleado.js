"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Empleado = /** @class */ (function (_super) {
    __extends(Empleado, _super);
    function Empleado(nombre, apellido, dni, sexo, legajo, sueldo, turno) {
        var _this = _super.call(this, nombre, apellido, dni, sexo) || this;
        _this._legajo = legajo;
        _this._sueldo = sueldo;
        _this._turno = turno;
        return _this;
    }
    /**
     * Getters
     */
    Empleado.prototype.GetLegajo = function () { return this._legajo; };
    Empleado.prototype.GetSueldo = function () { return this._sueldo; };
    Empleado.prototype.GetTurno = function () { return this._turno; };
    /**
     * Hablar
     */
    Empleado.prototype.Hablar = function (idioma) {
        var mensaje = "El empleado habla ";
        for (var index = 0; index < idioma.length; index++) {
            if (index == idioma.length - 1) {
                mensaje += idioma[index] + ".";
            }
            else {
                mensaje += idioma[index] + ", ";
            }
        }
        return mensaje;
    };
    /**
     * ToString
     */
    Empleado.prototype.ToString = function () {
        return _super.prototype.ToString.call(this) + "-" + this.GetLegajo() + "-" + this.GetSueldo() + "-" + this.GetTurno();
    };
    return Empleado;
}(Persona));
//# sourceMappingURL=empleado.js.map