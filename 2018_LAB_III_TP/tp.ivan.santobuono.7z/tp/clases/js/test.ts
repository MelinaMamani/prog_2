//(nombre:string, apellido:string, dni:number, sexo:string, legajo:number, sueldo:number,turno:string )
let empleado1 = new Empleado("alan", "lopez", 10101,"M",1, 17000, "mañana");
let empleado2 = new Empleado("laura", "ramirez", 20202,"F",2, 15000, "noche");
let empleado3 = new Empleado("daniela", "santos", 30303,"F",3, 23000, "mañana");
let empleado4 = new Empleado("daniel", "perez", 40404,"M",4, 12000, "tarde");
let empleado5 = new Empleado("matias", "solis", 50505,"M",5, 14000, "mañana");
let empleado6 = new Empleado("ivan", "lorenzo", 60606,"M",6, 17000, "mañana");
let empleado7 = new Empleado("leonardo", "gutierrez", 70707,"M",7, 15000, "noche");
let empleado8 = new Empleado("lucas", "palmieri", 80808,"M",8, 23000, "mañana");
let empleado9 = new Empleado("martin", "torres", 90909,"M",9, 12000, "tarde");
let empleado10 = new Empleado("franco", "duete", 101010,"M",10, 14000, "mañana");
let empleado11 = new Empleado("roxi", "perez", 111111,"F",11, 17000, "mañana");
let empleado12 = new Empleado("neolia", "morend", 121212,"F",12, 15000, "noche");
let empleado13 = new Empleado("sonia", "ramirez", 131313,"F",13, 23000, "mañana");
let empleado14 = new Empleado("sofy", "perez", 141414,"F",14, 12000, "tarde");
let empleado15 = new Empleado("claudia", "solis", 151515,"F",15, 14000, "mañana");

let array1: string[]= ["español","ingles", "frances"];
let array2: string[]= ["español","ingles", "frances","chino","aleman","portugues"];
let array3: string[]= ["español","ingles"];

let cerveceria: Fabrica= new Fabrica("cerveceria quilmes");
let coto: Fabrica= new Fabrica("coto quilmes");
let easy: Fabrica= new Fabrica("easy quilmes");

console.log("empleados creados: ");
console.log(empleado1.ToString());
console.log(empleado2.ToString());
console.log(empleado3.ToString());
console.log(empleado4.ToString());
console.log(empleado5.ToString());
console.log(empleado6.ToString());
console.log(empleado7.ToString());
console.log(empleado8.ToString());
console.log(empleado9.ToString());
console.log(empleado10.ToString());
console.log(empleado11.ToString());
console.log(empleado12.ToString());
console.log(empleado13.ToString());
console.log(empleado14.ToString());
console.log(empleado15.ToString());


console.log("lengas de los empleados creados: ");
console.log(empleado1.Hablar(array1));
console.log(empleado2.Hablar(array2));
console.log(empleado3.Hablar(array3));
console.log(empleado4.Hablar(array2));
console.log(empleado5.Hablar(array1));

cerveceria.AgregarEmpleado(empleado1);
cerveceria.AgregarEmpleado(empleado2);
cerveceria.AgregarEmpleado(empleado3);
cerveceria.AgregarEmpleado(empleado4);
cerveceria.AgregarEmpleado(empleado5);

coto.AgregarEmpleado(empleado6);
coto.AgregarEmpleado(empleado7);
coto.AgregarEmpleado(empleado8);
coto.AgregarEmpleado(empleado9);
coto.AgregarEmpleado(empleado10);
coto.AgregarEmpleado(empleado11);// fabrica llena


easy.AgregarEmpleado(empleado11);
easy.AgregarEmpleado(empleado11);//repetido
easy.AgregarEmpleado(empleado12);
easy.AgregarEmpleado(empleado13);
easy.AgregarEmpleado(empleado11);//repetido
easy.AgregarEmpleado(empleado14);
easy.AgregarEmpleado(empleado15);

console.log(cerveceria.ToString());
console.log(coto.ToString());
console.log(easy.ToString());