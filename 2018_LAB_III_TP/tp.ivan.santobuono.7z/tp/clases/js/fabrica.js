"use strict";
var Fabrica = /** @class */ (function () {
    function Fabrica(razonSocial) {
        this._empleados = [];
        this._cantidadMaxima = 5;
        this._razonSocial = razonSocial;
    }
    /**
     * AgregarEmpleado
     */
    Fabrica.prototype.AgregarEmpleado = function (emp) {
        if (this._empleados.length < this._cantidadMaxima) {
            this._empleados.push(emp);
            this.EliminarEmpleadoRepetido();
            return true;
        }
        else {
            console.log("fabrica llena");
            return false;
        }
    };
    /**
     * CalcularSueldo
     */
    Fabrica.prototype.CalcularSueldos = function () {
        var sueldos = 0;
        for (var index = 0; index < this._empleados.length; index++) {
            sueldos += this._empleados[index].GetSueldo();
        }
        return sueldos;
    };
    /**
     * EliminarEmpleado
     */
    Fabrica.prototype.EliminarEmpleado = function (emp) {
        var respuesta = false;
        for (var index = 0; index < this._empleados.length; index++) {
            if (emp === this._empleados[index]) {
                this._empleados.splice(index, 1);
                respuesta = true;
            }
        }
        return false;
    };
    /**
     * EliminarEmpleadoRepetido
     */
    Fabrica.prototype.EliminarEmpleadoRepetido = function () {
        for (var i = 0; i < this._empleados.length - 1; i++) {
            for (var j = i + 1; j < this._empleados.length; j++) {
                if (this._empleados[i] === this._empleados[j]) {
                    this._empleados.splice(j, 1);
                    console.log("empleado repetido");
                }
            }
        }
    };
    /**
     * ToString
     */
    Fabrica.prototype.ToString = function () {
        var cadena = this._razonSocial + "-" + this._cantidadMaxima;
        if (this._empleados.length > 0) {
            for (var index = 0; index < this._empleados.length; index++) {
                if (index == this._empleados.length - 1) {
                    cadena += this._empleados[index].ToString() + "\r\n";
                }
                else {
                    cadena += "-" + this._empleados[index].ToString();
                }
            }
        }
        return cadena;
    };
    return Fabrica;
}());
//# sourceMappingURL=fabrica.js.map