var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Persona = /** @class */ (function () {
    function Persona(nombre, apellido, dni, sexo) {
        this._apellido = apellido;
        this._nombre = nombre;
        this._dni = dni;
        this._sexo = sexo;
    }
    /**
     * Getters
     */
    Persona.prototype.GetApellido = function () { return this._apellido; };
    Persona.prototype.GetNombre = function () { return this._nombre; };
    Persona.prototype.GetDni = function () { return this._dni; };
    Persona.prototype.GetSexo = function () { return this._sexo; };
    /**
     * ToString
     */
    Persona.prototype.ToString = function () {
        return this.GetApellido() + "-" + this.GetNombre() + "-" + this.GetDni() + "-" + this.GetSexo();
    };
    return Persona;
}());
var Empleado = /** @class */ (function (_super) {
    __extends(Empleado, _super);
    function Empleado(nombre, apellido, dni, sexo, legajo, sueldo, turno) {
        var _this = _super.call(this, nombre, apellido, dni, sexo) || this;
        _this._legajo = legajo;
        _this._sueldo = sueldo;
        _this._turno = turno;
        return _this;
    }
    /**
     * Getters
     */
    Empleado.prototype.GetLegajo = function () { return this._legajo; };
    Empleado.prototype.GetSueldo = function () { return this._sueldo; };
    Empleado.prototype.GetTurno = function () { return this._turno; };
    /**
     * Hablar
     */
    Empleado.prototype.Hablar = function (idioma) {
        var mensaje = "El empleado habla ";
        for (var index = 0; index < idioma.length; index++) {
            if (index == idioma.length - 1) {
                mensaje += idioma[index] + ".";
            }
            else {
                mensaje += idioma[index] + ", ";
            }
        }
        return mensaje;
    };
    /**
     * ToString
     */
    Empleado.prototype.ToString = function () {
        return _super.prototype.ToString.call(this) + "-" + this.GetLegajo() + "-" + this.GetSueldo() + "-" + this.GetTurno();
    };
    return Empleado;
}(Persona));
var Fabrica = /** @class */ (function () {
    function Fabrica(razonSocial) {
        this._empleados = [];
        this._cantidadMaxima = 5;
        this._razonSocial = razonSocial;
    }
    /**
     * AgregarEmpleado
     */
    Fabrica.prototype.AgregarEmpleado = function (emp) {
        if (this._empleados.length < this._cantidadMaxima) {
            this._empleados.push(emp);
            this.EliminarEmpleadoRepetido();
            return true;
        }
        else {
            console.log("fabrica llena");
            return false;
        }
    };
    /**
     * CalcularSueldo
     */
    Fabrica.prototype.CalcularSueldos = function () {
        var sueldos = 0;
        for (var index = 0; index < this._empleados.length; index++) {
            sueldos += this._empleados[index].GetSueldo();
        }
        return sueldos;
    };
    /**
     * EliminarEmpleado
     */
    Fabrica.prototype.EliminarEmpleado = function (emp) {
        var respuesta = false;
        for (var index = 0; index < this._empleados.length; index++) {
            if (emp === this._empleados[index]) {
                this._empleados.splice(index, 1);
                respuesta = true;
            }
        }
        return false;
    };
    /**
     * EliminarEmpleadoRepetido
     */
    Fabrica.prototype.EliminarEmpleadoRepetido = function () {
        for (var i = 0; i < this._empleados.length - 1; i++) {
            for (var j = i + 1; j < this._empleados.length; j++) {
                if (this._empleados[i] === this._empleados[j]) {
                    this._empleados.splice(j, 1);
                    console.log("empleado repetido");
                }
            }
        }
    };
    /**
     * ToString
     */
    Fabrica.prototype.ToString = function () {
        var cadena = this._razonSocial + "-" + this._cantidadMaxima;
        if (this._empleados.length > 0) {
            for (var index = 0; index < this._empleados.length; index++) {
                if (index == this._empleados.length - 1) {
                    cadena += this._empleados[index].ToString() + "\r\n";
                }
                else {
                    cadena += "-" + this._empleados[index].ToString();
                }
            }
        }
        return cadena;
    };
    return Fabrica;
}());
//(nombre:string, apellido:string, dni:number, sexo:string, legajo:number, sueldo:number,turno:string )
var empleado1 = new Empleado("alan", "lopez", 10101, "M", 1, 17000, "mañana");
var empleado2 = new Empleado("laura", "ramirez", 20202, "F", 2, 15000, "noche");
var empleado3 = new Empleado("daniela", "santos", 30303, "F", 3, 23000, "mañana");
var empleado4 = new Empleado("daniel", "perez", 40404, "M", 4, 12000, "tarde");
var empleado5 = new Empleado("matias", "solis", 50505, "M", 5, 14000, "mañana");
var empleado6 = new Empleado("ivan", "lorenzo", 60606, "M", 6, 17000, "mañana");
var empleado7 = new Empleado("leonardo", "gutierrez", 70707, "M", 7, 15000, "noche");
var empleado8 = new Empleado("lucas", "palmieri", 80808, "M", 8, 23000, "mañana");
var empleado9 = new Empleado("martin", "torres", 90909, "M", 9, 12000, "tarde");
var empleado10 = new Empleado("franco", "duete", 101010, "M", 10, 14000, "mañana");
var empleado11 = new Empleado("roxi", "perez", 111111, "F", 11, 17000, "mañana");
var empleado12 = new Empleado("neolia", "morend", 121212, "F", 12, 15000, "noche");
var empleado13 = new Empleado("sonia", "ramirez", 131313, "F", 13, 23000, "mañana");
var empleado14 = new Empleado("sofy", "perez", 141414, "F", 14, 12000, "tarde");
var empleado15 = new Empleado("claudia", "solis", 151515, "F", 15, 14000, "mañana");
var array1 = ["español", "ingles", "frances"];
var array2 = ["español", "ingles", "frances", "chino", "aleman", "portugues"];
var array3 = ["español", "ingles"];
var cerveceria = new Fabrica("cerveceria quilmes");
var coto = new Fabrica("coto quilmes");
var easy = new Fabrica("easy quilmes");
console.log("empleados creados: ");
console.log(empleado1.ToString());
console.log(empleado2.ToString());
console.log(empleado3.ToString());
console.log(empleado4.ToString());
console.log(empleado5.ToString());
console.log(empleado6.ToString());
console.log(empleado7.ToString());
console.log(empleado8.ToString());
console.log(empleado9.ToString());
console.log(empleado10.ToString());
console.log(empleado11.ToString());
console.log(empleado12.ToString());
console.log(empleado13.ToString());
console.log(empleado14.ToString());
console.log(empleado15.ToString());
console.log("lengas de los empleados creados: ");
console.log(empleado1.Hablar(array1));
console.log(empleado2.Hablar(array2));
console.log(empleado3.Hablar(array3));
console.log(empleado4.Hablar(array2));
console.log(empleado5.Hablar(array1));
cerveceria.AgregarEmpleado(empleado1);
cerveceria.AgregarEmpleado(empleado2);
cerveceria.AgregarEmpleado(empleado3);
cerveceria.AgregarEmpleado(empleado4);
cerveceria.AgregarEmpleado(empleado5);
coto.AgregarEmpleado(empleado6);
coto.AgregarEmpleado(empleado7);
coto.AgregarEmpleado(empleado8);
coto.AgregarEmpleado(empleado9);
coto.AgregarEmpleado(empleado10);
coto.AgregarEmpleado(empleado11); // fabrica llena
easy.AgregarEmpleado(empleado11);
easy.AgregarEmpleado(empleado11); //repetido
easy.AgregarEmpleado(empleado12);
easy.AgregarEmpleado(empleado13);
easy.AgregarEmpleado(empleado11); //repetido
easy.AgregarEmpleado(empleado14);
easy.AgregarEmpleado(empleado15);
console.log(cerveceria.ToString());
console.log(coto.ToString());
console.log(easy.ToString());
