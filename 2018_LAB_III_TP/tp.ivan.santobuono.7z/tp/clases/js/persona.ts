abstract class Persona {
    private _apellido : string;
    private _nombre : string;
    private _dni : number;
    private _sexo : string;
    
    public constructor(nombre:string, apellido:string, dni:number, sexo:string) {
        this._apellido=apellido;
        this._nombre=nombre;
        this._dni=dni;
        this._sexo=sexo;        
    }

    /**
     * Getters
     */
    public GetApellido():string {return this._apellido;}
    public GetNombre():string {return this._nombre;}
    public GetDni():number {return this._dni;}
    public GetSexo():string {return this._sexo;}

    /**
     * name
     */
    public abstract Hablar(idioma :string[] ): string;

    /**
     * ToString
     */
    public ToString():string {
        return this.GetApellido()+"-"+this.GetNombre()+"-"+ this.GetDni()+"-"+this.GetSexo();
    }

}