class Fabrica {
    private _cantidadMaxima:number;
    private _empleados:Empleado[]=[];
    private _razonSocial:string;

    constructor(razonSocial:string) {
        this._cantidadMaxima=5;        
        this._razonSocial=razonSocial;
    }

    /**
     * AgregarEmpleado
     */
    public AgregarEmpleado(emp:Empleado) {

        if (this._empleados.length < this._cantidadMaxima) {       
            this._empleados.push(emp);
            this.EliminarEmpleadoRepetido();           
            return true;            
        }else{
            console.log("fabrica llena");
            return false;
        }
    }
    /**
     * CalcularSueldo
     */
    public CalcularSueldos():number {
        var sueldos:number =0;
        for (let index = 0; index < this._empleados.length; index++) {
            sueldos+=this._empleados[index].GetSueldo();            
        }
        return sueldos;
    }
    /**
     * EliminarEmpleado
     */
    public EliminarEmpleado(emp:Empleado):boolean {
        var respuesta:boolean=false;
        for (let index = 0; index < this._empleados.length; index++) {
            if (emp === this._empleados[index]) {
                this._empleados.splice(index, 1);
                respuesta= true;
            }        
        }
        return false
    }
    /**
     * EliminarEmpleadoRepetido
     */
    private EliminarEmpleadoRepetido():void {        
        for (let i = 0; i < this._empleados.length-1; i++) {            
            for (let j = i+1; j < this._empleados.length; j++) {
                if (this._empleados[i]===this._empleados[j]) {
                    this._empleados.splice(j, 1);
                    console.log("empleado repetido");
                }                
            }
        }
    }

    /**
     * ToString
     */
    public ToString():string {
        let cadena:string= this._razonSocial +"-"+this._cantidadMaxima;
        if (this._empleados.length>0) {
            for (let index = 0; index < this._empleados.length; index++) {
                if (index == this._empleados.length-1) {
                    cadena +=this._empleados[index].ToString()+"\r\n";
                }else{
                    cadena +="-" +this._empleados[index].ToString();
                }
            }
        }
        return cadena;     
    }
}
