
class Empleado extends Persona {
    protected _legajo:number;
    protected _sueldo:number;
    protected _turno:string;

    constructor(nombre:string, apellido:string, dni:number, sexo:string, legajo:number, sueldo:number,turno:string ) {
        super(nombre,apellido,dni,sexo);
        this._legajo=legajo;
        this._sueldo=sueldo;
        this._turno=turno;
    }

    /**
     * Getters
     */
    public GetLegajo():number {return this._legajo;}
    public GetSueldo():number {return this._sueldo;}
    public GetTurno():string {return this._turno;}
    
    /**
     * Hablar
     */
    public Hablar(idioma :string[] ): string {
        var mensaje:string = "El empleado habla ";
        for (let index = 0; index < idioma.length; index++) {
            if (index == idioma.length-1) {
                mensaje+= idioma[index]+".";
            }else{
                mensaje+= idioma[index]+", ";
            }           
        }
        
        
        return mensaje;
    }

    /**
     * ToString
     */
    public ToString():string {
        return super.ToString()+"-"+ this.GetLegajo()+"-"+this.GetSueldo()+"-"+ this.GetTurno();
    }

}