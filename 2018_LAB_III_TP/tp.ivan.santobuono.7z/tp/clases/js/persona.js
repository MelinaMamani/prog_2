"use strict";
var Persona = /** @class */ (function () {
    function Persona(nombre, apellido, dni, sexo) {
        this._apellido = apellido;
        this._nombre = nombre;
        this._dni = dni;
        this._sexo = sexo;
    }
    /**
     * Getters
     */
    Persona.prototype.GetApellido = function () { return this._apellido; };
    Persona.prototype.GetNombre = function () { return this._nombre; };
    Persona.prototype.GetDni = function () { return this._dni; };
    Persona.prototype.GetSexo = function () { return this._sexo; };
    /**
     * ToString
     */
    Persona.prototype.ToString = function () {
        return this.GetApellido() + "-" + this.GetNombre() + "-" + this.GetDni() + "-" + this.GetSexo();
    };
    return Persona;
}());
//# sourceMappingURL=persona.js.map