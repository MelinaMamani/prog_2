<?php
    interface IArchivo
    {
        public function GuardarEnArchivo($name);
        public function TraerDeArchivo($name);
    }