<?php
//require_once "./persona.php";

class Empleado extends Persona {
    protected $_legajo;
    protected $_sueldo;
    protected $_turno;
    protected $_path;

    function __construct($apellido,$nombre,$dni,$sexo,$legajo,$sueldo,$turno ) {
        parent::__construct($nombre,$apellido,$dni,$sexo);
        $this->_legajo=$legajo;
        $this->_sueldo=$sueldo;
        $this->_turno=$turno;
    }

    /**
     * Getters
     */
    function GetLegajo() {return $this->_legajo;}
    function GetSueldo() {return $this->_sueldo;}
    function GetTurno() {return $this->_turno;}
    function GetPathFoto() {return $this->_path;}

    function SetPathFoto($path) {$this->_path=$path;}
    
    /**
     * Hablar
     */
    function Hablar($idioma){
        $mensaje = "El empleado habla ";
        for ($i=0; $i < count( $idioma); $i++) { 
            # code...        
            if ($i == count( $idioma)-1) {
                $mensaje.= $idioma[$i].".";
            }else{
                $mensaje.= $idioma[$i].", ";
            }           
        }        
        return $mensaje;
    }

    /**
     * ToString
     */
    function ToString(){
        return parent::ToString()."-". $this->GetLegajo()."-".$this->GetSueldo()."-". $this->GetTurno()."-".$this->GetPathFoto()."\r\n";
    }

}