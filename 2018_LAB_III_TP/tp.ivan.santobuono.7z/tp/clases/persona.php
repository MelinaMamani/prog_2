<?php

abstract class Persona {
    private $_apellido;
    private $_nombre;
    private $_dni;
    private $_sexo;
    
    function __construct($nombre,$apellido,$dni,$sexo) {
        $this->_apellido=$apellido;
        $this->_nombre=$nombre;
        $this->_dni=$dni;
        $this->_sexo=$sexo;        
    }

    /**
     * Getters
     */
    function GetApellido() {return $this->_apellido;}
    function GetNombre(){return $this->_nombre;}
    function GetDni() {return $this->_dni;}
    function GetSexo() {return $this->_sexo;}

    /**
     * name
     */
    
    abstract function Hablar($idioma);

    /**
     * ToString
     */
    function ToString() {
        return $this->GetNombre()."-".$this->GetApellido()."-". $this->GetDni()."-".$this->GetSexo();
    }

}