<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Formulario Alta Empleado </title>
    <!-- css -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></link>
</head>
<body>
    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="./js/funciones.js"></script>
    <!--script src="./clases/app.js"></script-->
    <?php 
        require_once "./backend/validarSesion.php";
    ?>

    <h2>Alta de empleados</h2>
    <div class="container-fluid col-md-6" >
        <form action="administracion.php" method="post" onsubmit='return Test.enviar()' enctype="multipart/form-data" >
            <h4>Datos personales</h4>
            <hr size="10" width="95%" style="color: #0056b2;" />
            <div class="container-fluid " align="left">

                <label class="col-md-2" for="dniTxt"><h4>Dni: </h4></label>
                <span id="dniSpan" style="display:none">*</span>              
                <input class="col-md-3" type="number" name="dni" id="dniTxt" min="1000000" max="55000000">
                <br>

                <label class="col-md-2" for="apellidoTxt">Apellido: </label>
                <span id="apellidoSpan" style="display:none">*</span>
                <input class="col-md-3" type="text" name="apellido" id="apellidoTxt">
                <br>

                <label class="col-md-2" for="nombreTxt">Nombre: </label>
                <span id="nombreSpan" style="display:none">*</span>
                <input class="col-md-3" type="text" name="nombre" id="nombreTxt">
                <br>

                <label class="col-md-2" for="comboBoxSexo">Sexo: </label>
                <span id="sexoSpan" style="display:none">*</span>
                <select name="comboBoxSexo" id="comboBoxSexo"> 
                        <option hidden value="---">Seleccione una opcion</option>   
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>                        
                </select>
                <br>
            </div>
            <h4>Datos Laborales</h4>
            <hr size="10" width="95%" style="color: #0056b2;" />
            <div class="container-fluid">

                <span id="legajoSpan" style="display:none">*</span>
                <label class="col-md-2" for="legajoTxt">Legajo: </label>
                <input class="col-md-3" type="number" name="legajo" id="legajoTxt" min="100" max="550">
                <br>
                <label class="col-md-2" for="sueldoTxt">Sueldo: </label>

                <span id="sueldoSpan" style="display:none">*</span>
                <input class="col-md-3" type="number" name="sueldo" id="sueldoTxt" min="8000" step="500" oninput="Test.cambiarSueldoMax()">
                <br>
                <label class="col-md-2" for="radioTurno"><H5 align="left">Turno: </H5></label>
                <div>
                    <input type="radio" id="0" name="radioTurno" value="0" checked>
                    <label >Mañana</label>
                
                    <input type="radio" id="1" name="radioTurno" value="1">
                    <label>Tarde</label>
                
                    <input type="radio" id="2" name="radioTurno" value="2">
                    <label>Noche</label>
                </div>
                <hr size="10" width="95%" style="color: #0056b2;" />
                <label>Foto</label>
                <span id="filesSpan" style="display:none">*</span>
                <input type="file" name="archivos" id="archivos"/>

            </div>      
            
            <hr size="10" width="95%" style="color: #0056b2;" />
            <div id="next_button" align="right">
                <input align="right" type="reset" value="reset">
                <input align="right" type="submit" value="enviar">
            </div>
            
        </form>
    </div>
    

</body>
</html>