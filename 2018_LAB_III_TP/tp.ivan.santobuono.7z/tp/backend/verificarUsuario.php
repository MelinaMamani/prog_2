<?php
    require_once "../clases/persona.php";
    require_once "../clases/empleado.php";
    require_once "../clases/interfaces.php";
    require_once "../clases/fabrica.php";

    //var_dump($_POST);

    $fabrica =new Fabrica("test",999999);
    $fabrica->TraerDeArchivo("../archivos/archivos.txt");
    $respuesta = $fabrica->BuscarEmpleadoPorDNIyNombre($_POST['dni'],$_POST['apellido']);
    if ($respuesta!=false) {
        //echo "Usuario logueado!!";
        session_start();
		$_SESSION['DNIEmpleado'] = $respuesta->GetDni();
        header('Location: ../mostrar.php');
    }else {
        echo "<br> El D.N.I. y/o Apellido son incorrectos <br>";
        echo '<a href="../login.html">Volver a Loguear</a>';
    }