<?php
    require_once "./clases/persona.php";
    require_once "./clases/empleado.php";
    require_once "./clases/interfaces.php";
    require_once "./clases/fabrica.php";
    //var_dump($_FILES["archivos"]["tmp_name"]);

    if (isset($_POST['nombre'])) {
        $path=$_FILES["archivos"]["tmp_name"];
        $extension=pathinfo($_FILES["archivos"]["name"],PATHINFO_EXTENSION);
        //echo $extension;
        if ($extension != "jpg" && $extension != "jpeg" && $extension != "png" && $extension != "gif") {
            echo "el tipo de archivo no es el permitido ( jpg, jpeg, png) ";
        }
        else {
            echo "el archivo pasó la validacion de tipo";
            $path="./fotos/".date("ymddhisf").".".$extension;
            move_uploaded_file($_FILES["archivos"]["tmp_name"],$path);
            //$fp = fopen("archivos.txt","a");
            //fwrite($fp,$path . PHP_EOL);
            //fclose($fp);    
            //require_once "visor.php";
        }
        $empleado=new Empleado($_POST['nombre'],$_POST['apellido'],$_POST['dni'],$_POST['comboBoxSexo'],$_POST['legajo'],$_POST['sueldo'] ,$_POST['radioTurno']);
        $empleado->SetPathFoto($path);
        $fabrica = new Fabrica("PEPSI",999999);
        $fabrica->TraerDeArchivo("./archivos/archivos.txt");
        if($fabrica->AgregarEmpleado($empleado)){
            $fabrica->GuardarEnArchivo("./archivos/archivos.txt");
            echo '<a href="./mostrar.php">Mostrar</a>';
        }else {
            echo '<a href="./index.html">volver</a>';
        }
    }else {
        echo ("DNI: ".$_POST['dni']." ---- Apellido: ".$_POST['apellido']);
    }
    
    
?>