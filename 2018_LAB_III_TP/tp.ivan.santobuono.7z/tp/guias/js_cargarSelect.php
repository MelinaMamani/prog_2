<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Selects dinamicos con PHP y Jquery</title>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script>
        $(document).ready(function(){
            $("select[name=select1]").change(function(){
                $.post("js_cargarSelect2.php", {id:$(this).val()}, function(data){
                    $("select[name=select2] option").remove();
                    if(data.correcto==1)
                    {
                        $.each(data.contenido, function(i, item) {
                            $("select[name=select2]").append(new Option(item, i));
                        });
                        
                        // activamos el select
                        $("select[name=select2]").prop('disabled', false);
                    }else{
                        // desactivamos el select
                        $("select[name=select2]").prop('disabled', true);
                    }
                }, "json");
            });
        });
    </script>
</head>

<body>
    <h1>Selects dinamicos con PHP y Jquery</h1>
    
    <p>Script que muestra como actualizar un select sin refrescar
    la página, obteniendo los valores del segundo select con AJAX de un
    archivo PHP. Se utiliza JQuery, y el contenido del segundo select se
    envia con JSON des de la pagina PHP.</p>
    
    <form name="formulario">
        <select name="select1">
            <option value='0'>Seleccione una opción</option>
            <option value='1'>coche</option>
            <option value='2'>moto</option>
            <option value='3'>avion</option>
            <option value='4'>opci&oacute;n sin resultados</option>
        </select>
        
        <!-- Segundo select. Se llena automaticamente segun la seleccion
        del primer select -->
        <select name="select2" disabled>
        </select>
    </form>
    
    <p><a href="http://www.lawebdelprogramador.com">La Web del Programador</a></p>
</body>
</html>