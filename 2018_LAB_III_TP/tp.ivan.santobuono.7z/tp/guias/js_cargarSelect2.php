<?php
/**
 * Página llamada desde cargarSelect para devolver el contenido del segundo
 * select en formato json
 *
 * Tiene que devolver:
 *  correcto [1|0] => determina si muestra resultados o no
 *  contenido => array con los valores a mostrar en el segundo desplegable
 *
 * http://www.lawebdelprogramador.com
 */
$valoresSegundoSelect=array(
    "0"=>"Selecciona una opción"
);

$correcto=1;

if($_POST["id"]==1)
{
    // coche
    array_push($valoresSegundoSelect,"Ford", "Toyota", "Ferrari");
}elseif($_POST["id"]==2){
    // moto
    array_push($valoresSegundoSelect,"Yamaha", "Honda", "BMW");
}elseif($_POST["id"]==3){
    // avion
    array_push($valoresSegundoSelect,"Iberia", "Lufthansa", "Air France");
}else{
    $correcto=0;
}

# devolvemos el resultado en json
echo json_encode(array("correcto"=>$correcto, "contenido"=>$valoresSegundoSelect));
?>