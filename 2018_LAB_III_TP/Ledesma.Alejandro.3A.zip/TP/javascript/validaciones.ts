class Main
{
    public static AdministrarValidaciones(): void
    {
        let idTxt = new Array("txtApellido","txtNombre");
        let idNum : any = new Array(["txtDni",1000000,55000000],["txtLegajo",100,550],["txtSueldo",8000,Main.ObtenerSueldoMaximo(Main.ObtenerTurnoSeleccionado())]);
        idTxt.forEach(element => {
            if(Main.ValidarCamposVacios(element)==false)
            {
                Main.AdministrarSpanError(element+"Sp", false);
                console.log("El campo " + element + " se encuentra vacio.");
            }
            else
                Main.AdministrarSpanError(element+"Sp", true);
        });
        if(Main.ValidarCombo("cboSexo","N")==false)
        {
            Main.AdministrarSpanError("cboSexoSp", false);
            console.log("El campo cboSexo se encuentra vacio.");
        }
        else
            Main.AdministrarSpanError("cboSexoSp", true);
        idNum.forEach(element => {
            if(Main.ValidarCamposVacios(element[0])==false)
            {
                Main.AdministrarSpanError(element[0]+"Sp", false);
                console.log("El campo " + element[0] + " se encuentra vacio.");
            }
            else
            {
                let valor : number = Number((<HTMLInputElement> document.getElementById(element[0])).value);
                if(Main.ValidarRangoNumerico(valor,element[1],element[2])==false)
                {
                    Main.AdministrarSpanError(element[0]+"Sp", false);
                    console.log("El campo " + element[0] + " no se encuentra en el rango.");
                }
                else
                    Main.AdministrarSpanError(element[0]+"Sp", true);
            }
        });
        if ((<HTMLInputElement> document.getElementById('fileFoto')).value == "")
            Main.AdministrarSpanError("fileFotoSp", false);
        else
            Main.AdministrarSpanError("fileFotoSp", true);
        if (Main.VerificarValidacionesLogin())
        {
            console.log("No hay errores.");
            (<HTMLFormElement> document.getElementById("formIndex")).submit();
        }
        else
            console.log("Se encontraron errores.");
    }

    public static ValidarCamposVacios(id:string): boolean
    {
        let campo : string = (<HTMLInputElement> document.getElementById(id)).value;
        if (campo.length == 0)
            return false;
        else
            return true;
    }

    public static ValidarRangoNumerico(valor:number, minimo:number, maximo:number): boolean
    {
        if (valor >= minimo && valor <= maximo)
            return true;
        else
            return false;
    }

    public static ValidarCombo(id:string, valor:string): boolean
    {
        let campo : string = (<HTMLInputElement> document.getElementById(id)).value;
        if (campo!=valor)
            return true;
        else
            return false;
    }

    public static ObtenerTurnoSeleccionado(): string
    {
        if ((<HTMLInputElement> document.getElementById("rdoTurno")).checked)
            return (<HTMLInputElement> document.getElementById("rdoTurno")).value;
        else
            return "";
    }

    public static ObtenerSueldoMaximo(turno:string): number
    {
        if (turno == "Manana")
            return 20000;
        else if (turno == "Tarde")
            return 18500;
        else
            return 25000;
    }

    public static AdministrarValidacionesLogin(): void
    {
        if(Main.ValidarCamposVacios("txtDni")==false)
        {
            Main.AdministrarSpanError("txtDniSp", false);
            console.log("El campo txtDni se encuentra vacio.");
        }
        else
        {
            let valor : number = Number((<HTMLInputElement> document.getElementById("txtDni")).value);
            if(Main.ValidarRangoNumerico(valor,1000000,55000000)==false)
            {
                Main.AdministrarSpanError("txtDniSp", false);
                console.log("El campo txtDni no se encuentra en el rango.");
            }
            else
                Main.AdministrarSpanError("txtDniSp", true);
        }
        if(Main.ValidarCamposVacios("txtApellido")==false)
        {
            Main.AdministrarSpanError("txtApellidoSp", false);
            console.log("El campo txtApellido se encuentra vacio.");
        }
        else
            Main.AdministrarSpanError("txtApellidoSp", true);
        if (Main.VerificarValidacionesLogin())
        {
            console.log("No hay errores.");
            (<HTMLFormElement> document.getElementById("formLogin")).submit();
        }
        else
            console.log("Se encontraron errores.");
    }

    public static AdministrarSpanError(id:string, ocultar:boolean): void
    {
        if (ocultar)
            (<HTMLInputElement> document.getElementById(id)).setAttribute("style", "display:none");
        else
            (<HTMLInputElement> document.getElementById(id)).setAttribute("style", "display:block");
            
    }

    public static VerificarValidacionesLogin(): boolean
    {
        let campos = document.getElementsByTagName("span");
        for (let i : number = 0; i < campos.length; i++)
        {
            if ((<HTMLSpanElement> campos[i]).getAttribute("style") == "display:block")
                return false;
        }
        return true;
    }

    public static AdministrarModificar(dni: number): void
    {
        (<HTMLInputElement> document.getElementById('hdnEnviar')).setAttribute('value', dni.toString());
        (<HTMLFormElement> document.getElementById('formHidden')).submit();
    }
}