var Main = /** @class */ (function () {
    function Main() {
    }
    Main.AdministrarValidaciones = function () {
        var idTxt = new Array("txtApellido", "txtNombre");
        var idNum = new Array(["txtDni", 1000000, 55000000], ["txtLegajo", 100, 550], ["txtSueldo", 8000, Main.ObtenerSueldoMaximo(Main.ObtenerTurnoSeleccionado())]);
        idTxt.forEach(function (element) {
            if (Main.ValidarCamposVacios(element) == false) {
                Main.AdministrarSpanError(element + "Sp", false);
                console.log("El campo " + element + " se encuentra vacio.");
            }
            else
                Main.AdministrarSpanError(element + "Sp", true);
        });
        if (Main.ValidarCombo("cboSexo", "N") == false) {
            Main.AdministrarSpanError("cboSexoSp", false);
            console.log("El campo cboSexo se encuentra vacio.");
        }
        else
            Main.AdministrarSpanError("cboSexoSp", true);
        idNum.forEach(function (element) {
            if (Main.ValidarCamposVacios(element[0]) == false) {
                Main.AdministrarSpanError(element[0] + "Sp", false);
                console.log("El campo " + element[0] + " se encuentra vacio.");
            }
            else {
                var valor = Number(document.getElementById(element[0]).value);
                if (Main.ValidarRangoNumerico(valor, element[1], element[2]) == false) {
                    Main.AdministrarSpanError(element[0] + "Sp", false);
                    console.log("El campo " + element[0] + " no se encuentra en el rango.");
                }
                else
                    Main.AdministrarSpanError(element[0] + "Sp", true);
            }
        });
        if (document.getElementById('fileFoto').value == "")
            Main.AdministrarSpanError("fileFotoSp", false);
        else
            Main.AdministrarSpanError("fileFotoSp", true);
        if (Main.VerificarValidacionesLogin()) {
            console.log("No hay errores.");
            document.getElementById("formIndex").submit();
        }
        else
            console.log("Se encontraron errores.");
    };
    Main.ValidarCamposVacios = function (id) {
        var campo = document.getElementById(id).value;
        if (campo.length == 0)
            return false;
        else
            return true;
    };
    Main.ValidarRangoNumerico = function (valor, minimo, maximo) {
        if (valor >= minimo && valor <= maximo)
            return true;
        else
            return false;
    };
    Main.ValidarCombo = function (id, valor) {
        var campo = document.getElementById(id).value;
        if (campo != valor)
            return true;
        else
            return false;
    };
    Main.ObtenerTurnoSeleccionado = function () {
        if (document.getElementById("rdoTurno").checked)
            return document.getElementById("rdoTurno").value;
        else
            return "";
    };
    Main.ObtenerSueldoMaximo = function (turno) {
        if (turno == "Manana")
            return 20000;
        else if (turno == "Tarde")
            return 18500;
        else
            return 25000;
    };
    Main.AdministrarValidacionesLogin = function () {
        if (Main.ValidarCamposVacios("txtDni") == false) {
            Main.AdministrarSpanError("txtDniSp", false);
            console.log("El campo txtDni se encuentra vacio.");
        }
        else {
            var valor = Number(document.getElementById("txtDni").value);
            if (Main.ValidarRangoNumerico(valor, 1000000, 55000000) == false) {
                Main.AdministrarSpanError("txtDniSp", false);
                console.log("El campo txtDni no se encuentra en el rango.");
            }
            else
                Main.AdministrarSpanError("txtDniSp", true);
        }
        if (Main.ValidarCamposVacios("txtApellido") == false) {
            Main.AdministrarSpanError("txtApellidoSp", false);
            console.log("El campo txtApellido se encuentra vacio.");
        }
        else
            Main.AdministrarSpanError("txtApellidoSp", true);
        if (Main.VerificarValidacionesLogin()) {
            console.log("No hay errores.");
            document.getElementById("formLogin").submit();
        }
        else
            console.log("Se encontraron errores.");
    };
    Main.AdministrarSpanError = function (id, ocultar) {
        if (ocultar)
            document.getElementById(id).setAttribute("style", "display:none");
        else
            document.getElementById(id).setAttribute("style", "display:block");
    };
    Main.VerificarValidacionesLogin = function () {
        var campos = document.getElementsByTagName("span");
        for (var i = 0; i < campos.length; i++) {
            if (campos[i].getAttribute("style") == "display:block")
                return false;
        }
        return true;
    };
    Main.AdministrarModificar = function (dni) {
        document.getElementById('hdnEnviar').setAttribute('value', dni.toString());
        document.getElementById('formHidden').submit();
    };
    Main.AdministrarEliminar = function (legajo) {
        document.getElementById('hdnEliminar').setAttribute('value', legajo.toString());
        document.getElementById('formHiddenTwo').submit();
    };
    return Main;
}());
