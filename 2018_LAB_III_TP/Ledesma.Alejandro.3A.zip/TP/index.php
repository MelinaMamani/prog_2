<?php
    session_start();
    require_once("./clases/fabrica.php");
    require_once("./clases/empleado.php");
    require_once("./backend/ValidarSesion.php");
    $dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;
    $id = 0;
    if($dni)
    {
        $fabrica = new Fabrica("Fabrica A");
        $fabrica->TraerDeArchivo("./archivos/empleados.txt");
        $empleados = $fabrica->GetEmpleados();
        for ($i = 0; $i < count($empleados); $i++)
        {
            if ($empleados[$i]->GetDni() == $dni)
            {
                $id = $i;
                break;
            }
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php if ($dni) echo("HTML5 - Formulario Modificar Empleado"); else echo("HTML 5 – Formulario Alta Empleado"); ?></title>
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />-->
    <script src="./javascript/funciones.js"></script>
</head>
<body>
    <h2 align="center"><?php if ($dni) echo("Modificar Empleado"); else echo("Alta de Empleados"); ?></h2>
    <h4 align="right"><a href='./backend/cerrarSesion.php'>Cerrar Sesion</a></h2>
    <!--<form>-->
    <form id="formIndex" action="./administracion.php" method="post" enctype="multipart/form-data">
        <table align="center">
            <tr>
                <td colspan="2"><h4>Datos Personales</h4></td>
            </tr>
            <tr>
                <td colspan="2"><hr /></td>
            </tr>
            <tr>
                <td>DNI:</td>
                <td><input type="number" id="txtDni" name="dni" min="1000000" max="55000000" <?php if ($dni) echo("value='" . $empleados[$id]->GetDni() . "' readonly"); else echo("required"); ?>></td>
                <td><span id="txtDniSp" style="display:none">*</span></td>
            </tr>
            <tr>
                <td>Apellido:</td>
                <td><input type="text" id="txtApellido" name="apellido" <?php if ($dni) echo("value='" . $empleados[$id]->GetApellido() . "'"); ?> required></td>
                <td><span id="txtApellidoSp" style="display:none">*</span></td>
            </tr>
            <tr>
                <td>Nombre:</td>
                <td><input type="text" id="txtNombre" name="nombre" <?php if ($dni) echo("value='" . $empleados[$id]->GetNombre() . "'"); ?> required></td>
                <td><span id="txtNombreSp" style="display:none">*</span></td>
            </tr>
            <tr>
                <td>Sexo:</td>
                <td>
                    <select id="cboSexo" name="sexo">
                            <option value="N" disabled selected>Seleccione</option>
                            <option value="M" <?php if ($dni) { if ($empleados[$id]->GetSexo() == "M") echo("selected");}?>>Masculino</option>
                            <option value="F" <?php if ($dni) { if ($empleados[$id]->GetSexo() == "F") echo("selected");}?>>Femenino</option>
                    </select>
                </td>
                <td><span id="cboSexoSp" style="display:none">*</span></td>
            </tr>
            <tr>
                    <td colspan="2"><h4>Datos Laborales</h4></td>
            </tr>
            <tr>
                <td colspan="2"><hr /></td>
            </tr>
            <tr>
                <td>Legajo:</td>
                <td><input type="number" id="txtLegajo" name="legajo" min="100" max="550" <?php if ($dni) echo("value='" . $empleados[$id]->GetLegajo() . "' readonly"); else echo("required"); ?>></td>
                <td><span id="txtLegajoSp" style="display:none">*</span></td>
            </tr>
            <tr>
                <td>Sueldo:</td>
                <td><input type="number" id="txtSueldo" name="sueldo" min="8000" max="25000" step="500" <?php if ($dni) echo("value='" . $empleados[$id]->GetSueldo() . "'"); ?> required></td>
                <td><span id="txtSueldoSp" style="display:none">*</span></td>
            </tr>
            <tr>
				<td>Turno:</td>
			</tr>
			<tr>				
				<td  style="text-align:right;padding-left:15px">
					<input type="radio" id="rdoTurno" name="turno" value="Manana" <?php if ($dni) { if ($empleados[$id]->GetTurno() == "Manana") echo("checked='checked'");} else echo("checked='checked'");?>/>						
                </td>
                <td>Mañana</td>	
			</tr>
			<tr>			
				<td  style="text-align:right;padding-left:15px">
					<input type="radio" id="rdoTurno" name="turno" value="Tarde" <?php if ($dni) { if ($empleados[$id]->GetTurno() == "Tarde") echo("checked='checked'");}?>/>						
                </td>
                <td>Tarde</td>	
			</tr>
			<tr>			
				<td  style="text-align:right;padding-left:15px">
					<input type="radio" id="rdoTurno" name="turno" value="Noche" <?php if ($dni) { if ($empleados[$id]->GetTurno() == "Noche") echo("checked='checked'");}?>/>						
                </td>
                <td>Noche</td>	
            </tr>
            <tr>
                <td>
                    Foto:
                </td>
                <td><input type="file" id="fileFoto" name="foto"></td>
                <td><span style="display:none" id="fileFotoSp">*</span></td>
            </tr>
            <tr>
                <td colspan="2"><hr /></td>
            </tr>
            <tr>
				<td colspan="2" align="right">
					<input type="reset" value="Limpiar" />
				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">
					<input type="button" id="btnEnviar" <?php if ($dni) echo("value='Modificar'"); else echo("value='Enviar'"); ?> onclick="Main.AdministrarValidaciones()"/>
                </td>
                <?php
                    if ($dni) echo("<td colspan='2' align='right'><input type='hidden' id='hdnEnviar' name='hidden' value='hidden'></td>");
                ?>
			</tr>
        </table>
    </form>
</body>
</html>