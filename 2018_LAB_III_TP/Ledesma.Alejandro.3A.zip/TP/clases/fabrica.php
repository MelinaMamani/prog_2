<?php
    require_once("interfaces.php");

    class Fabrica implements IArchivo
    {
        private $_cantidadMaxima;
        private $_empleados;
        private $_razonSocial;

        public function __construct($razonSocial)
        {
            $this->_cantidadMaxima = 7;
            $this->_empleados = array();
            $this->_razonSocial = $razonSocial;
        }
        public function AgregarEmpleado(Empleado $empleado)
        {
            if(count($this->_empleados) < $this->_cantidadMaxima)
            {
                array_push($this->_empleados,$empleado);
                $this->_empleados = $this->EliminarEmpleadosRepetidos();
            }
        }
        public function CalcularSueldo()
        {
            $sueldo = 0;
            foreach($this->_empleados as $valor)
            {
                $sueldo += $valor->_sueldo;
            }
            return $sueldo;
        }
        public function EliminarEmpleado(Empleado $empleado)
        {
            for ($i = 0; $i < count($this->_empleados); $i++)
            {
                if ($this->_empleados[$i]->GetDni() == $empleado->GetDni())
                {
                    if (file_exists($empleado->GetPathFoto()))
                    {
                        unlink($empleado->GetPathFoto());
                    }
                    if (file_exists("." . $empleado->GetPathFoto()))
                    {
                        unlink("." . $empleado->GetPathFoto());
                    }
                    unset($this->_empleados[$i]);
                    break;
                }
            }
        }
        private function EliminarEmpleadosRepetidos()
        {
            return array_unique($this->_empleados, SORT_REGULAR);
        }
        public function GetEmpleados()
        {
            return $this->_empleados;
        }
        public function ToString()
        {
            $empleados = "";
            foreach($this->_empleados as $valor)
            {
                $empleados = $empleados . $valor->ToString() . "<br>";
            }
            return $empleados;
        }
        public function GuardarEnArchivo($nombreArchivo)
        {
            $archivo = fopen($nombreArchivo,"w");
            foreach($this->_empleados as $valor)
            {
                fwrite($archivo, $valor->ToString() . "\r\n");
            }
            fclose($archivo);
        }

        public function TraerDeArchivo($nombreArchivo)
        {
            $archivo = fopen($nombreArchivo, "r");
            while (!feof($archivo))
            {
                $empleado = explode("-", trim(fgets($archivo)));
                if ($empleado[0] != "")
                {
                    $empleadoNuevo = new Empleado($empleado[0], $empleado[1], $empleado[2], $empleado[3], $empleado[4], $empleado[5], $empleado[6]);
                    $empleadoNuevo->SetPathFoto(trim($empleado[7] . "-" . $empleado[8]));
                    $this->AgregarEmpleado($empleadoNuevo);
                }
            }
            fclose($archivo);
        }
    }
?>