<?php
    require_once("clases/fabrica.php");
    require_once("clases/empleado.php");

    $dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;
    $apellido = isset($_POST["apellido"]) ? $_POST["apellido"] : NULL;
    $nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : NULL;
    $sexo = isset($_POST["sexo"]) ? $_POST["sexo"] : NULL;
    $legajo = isset($_POST["legajo"]) ? $_POST["legajo"] : NULL;
    $sueldo = isset($_POST["sueldo"]) ? $_POST["sueldo"] : NULL;
    $turno = isset($_POST["turno"]) ? $_POST["turno"] : NULL;
    $foto = isset($_FILES["foto"]) ? pathinfo($_FILES['foto']['name']) : NULL;
    $hidden = isset($_POST["hidden"]) ? $_POST["hidden"] : NULL;

    if ($foto['extension'] != 'jpg' && $foto['extension'] != 'png' && $foto['extension'] != 'jpeg' && $foto['extension'] != 'gif' && $foto['extension'] != 'bmp' && $foto['size'] > 1024)
    {
        echo "Hubo un error en la imagen.";
    }
    else
    {
        $empleado = new Empleado($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno);
        move_uploaded_file($_FILES['foto']['tmp_name'], "./fotos/" . $dni . "-" . $apellido . "." . $foto['extension']);
        $empleado->SetPathFoto("./fotos/" . $dni . "-" . $apellido . "." . $foto['extension']);
        $fabrica = new Fabrica("Fabrica A");
        
        if (file_exists("./archivos/empleados.txt"))
            echo $fabrica->TraerDeArchivo("./archivos/empleados.txt");
        try
        {
            if($hidden)
            {
                $empleados = $fabrica->GetEmpleados();
                for ($i = 0; $i < count($empleados); $i++)
                {
                    if ($empleados[$i]->GetDni() == $dni)
                    {
                        $fabrica->EliminarEmpleado($empleados[$i]);
                        break;
                    }
                }
            }
            $fabrica->AgregarEmpleado($empleado);
            $fabrica->GuardarEnArchivo("./archivos/empleados.txt");
            
            echo "<a href='./backend/mostrar.php'>Mostrar</a>";
        }
        catch (Exception $e)
        {
            echo "Hubo un error al agregar al Empleado.";
            echo "<a href='./index.html'>Index</a>";
        }
    }
?>