<?php
    if (!isset($_SESSION['DNIEmpleado']))
    {
        if (file_exists("./login.html"))
		{
	 		header("Location: ./login.html");
		}
		if (file_exists("../login.html"))
		{
	 		header("Location: ../login.html");
		}
    }
?>