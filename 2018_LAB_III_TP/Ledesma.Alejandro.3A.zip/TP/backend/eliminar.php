<?php
    require_once("../clases/fabrica.php");
    require_once("../clases/empleado.php");
    
    $legajo = isset($_POST["legajo"]) ? $_POST["legajo"] : NULL;

    $isCorrect = false;
    if ($legajo)
    {
        $fabrica = new Fabrica("Fabrica A");
        $fabrica->TraerDeArchivo("../archivos/empleados.txt");
        $empleados = $fabrica->GetEmpleados();
        foreach ($empleados as $valor)
        {
            if ($legajo == $valor->GetLegajo())
            {
                $fabrica->EliminarEmpleado($valor);
                echo "Se elimino el empleado.";
                $fabrica->GuardarEnArchivo("../archivos/empleados.txt");
                $isCorrect = true;
                break;
            }
        }
        if (!$isCorrect)
        {
            echo "No se encontro el empleado.";
        }
    }
?>
</br>
<a href="./mostrar.php">Mostrar</a>