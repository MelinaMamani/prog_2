<?php
    session_start();
    require_once("../clases/fabrica.php");
    require_once("../clases/empleado.php");
    require_once("./ValidarSesion.php");

    $fabrica = new Fabrica("Fabrica A");
    $fabrica->TraerDeArchivo("../archivos/empleados.txt");
    $empleados = $fabrica->GetEmpleados(); 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>HTML 5 – Listado de Empleados</title>
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />-->
    <script src="../javascript/funciones.js"></script>
</head>
<body>
    <h2 align="center">Listado de Empleados</h2>
    <h4 align="right"><a href='./cerrarSesion.php'>Cerrar Sesion</a></h2>
    <table align="center">
        <tr>
            <td><h4>Info</h4></td>
        </tr>
        <td colspan="4"><hr /></td>
        <?php
            foreach ($empleados as $valor)
            {
                echo "<tr><td>" . $valor->GetDni() . " - " . $valor->GetNombre() . " - " . $valor->GetApellido() . " - " . $valor->GetSexo() . " - " . $valor->GetSueldo() . " - " . $valor->GetTurno() . " - " . $valor->GetPathFoto() . "</td><td>" . "<img src='." . $valor->GetPathFoto() . "' style='width:90px;height:90px;'>" . "</td><td><a href='#' onclick='Main.AdministrarEliminar(" . $valor->GetLegajo() . ")'>Eliminar</a></td><td><input type='button' id='btnModificar' value='Modificar' onclick='Main.AdministrarModificar(" . $valor->GetDni() . ")'/></td></tr>";
            }
        ?>
        <td colspan="4"><hr /></td>
        <tr>
          <form action="../index.php" id="formHidden" method="post">
            <input type="hidden" id="hdnEnviar" name="dni">
          </form>
          <form action="./eliminar.php" id="formHiddenTwo" method="post">
            <input type="hidden" id="hdnEliminar" name="legajo">
          </form>
        </tr>
    <table>
</body>
</html>