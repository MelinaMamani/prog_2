<?php
    require_once("../clases/fabrica.php");
    require_once("../clases/empleado.php");

    session_start();

    $dni = isset($_POST["dni"]) ? $_POST["dni"] : NULL;
    $apellido = isset($_POST["apellido"]) ? $_POST["apellido"] : NULL;

    if ($dni && $apellido)
    {
        $fabrica = new Fabrica("Fabrica A");
        $fabrica->TraerDeArchivo("../archivos/empleados.txt");
        $empleados = $fabrica->GetEmpleados();
        if(count($empleados) > 0)
        {
            $isFound = false;
            foreach ($empleados as $valor)
            {
                if ($dni == $valor->GetDni() && $apellido == $valor->GetApellido())
                {
                    $_SESSION['DNIEmpleado'] = $_POST['dni'];
                    header("Location: ./mostrar.php");
                }
            }
            if (!$isFound)
            {
                echo "No se encontro el empleado.</br><a href='../login.html'>Login</a>";
            }
        }
        else
        {
            echo "No hay empleados en la lista.</br><a href='../login.html'>Login</a>";
        }
    }
?>