<?php
	session_start();
	session_unset();
	session_destroy();
	if (file_exists("./login.html"))
	{
		header("Location: ./login.html");
	}
	if (file_exists("../login.html"))
	{
		header("Location: ../login.html");
	}
?>