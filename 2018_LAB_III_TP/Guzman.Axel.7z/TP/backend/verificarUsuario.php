<?php
// GUZMAN AXEL 2018
require_once "empleado.php";
session_start();

$postDni = $_POST["numDni"]; // 2
$postApellido = $_POST["txtApellido"]; // 1

$existeEmpleado = false;

if (file_exists("../archivos/empleados.txt"))
{
    $archivo = fopen("../archivos/empleados.txt", "r");

    while(!feof($archivo))
    {
        $bufer = fgets($archivo);
        
        $datos = explode(" - ", $bufer);
        $datos[0] = trim($datos[0]);
        if($datos[0] != "")
        {
            $empleado = new Empleado($datos[0],$datos[1],$datos[2],$datos[3],$datos[4],$datos[5],$datos[6]);
            if ($datos[1] == $postApellido && $datos[2] == $postDni)
            {
                $existeEmpleado = true;
                header("Location:./mostrar.php");
            }
        }
    }
    fclose($archivo);
}
if($existeEmpleado)
{
    $_SESSION["DNIEmpleado"] = $postDni;
    header("Location:./mostrar.php");
}
else
{
    echo "Error. No existe empleado. <br>";
    echo "<br><a href=./index.php> Index.php </a>";
}