<?php
include_once "persona.php";

class Empleado extends Persona
{
    private $_legajo;
    private $_sueldo;
    private $_turno;
    private $_pathFoto;
    
    public function __construct($nombre,$apellido,$dni,$sexo,$legajo,$sueldo,$turno)
    {
        parent::__construct($nombre,$apellido,$dni,$sexo);

        $this->_legajo = $legajo;
        $this->_sueldo = $sueldo;
        $this->_turno = $turno;
        $this->_pathFoto = "";
    }

    public function GetLegajo()
    {
        return $this->_legajo;
    }

    public function GetSueldo()
    {
        return $this->_sueldo;
    }

    public function GetTurno()
    {
        return $this->_turno;
    }

    public function GetPathFoto()
    {
        return $this->_pathFoto;
    }

    public function SetPathFoto($valor)
    {
        $this->_pathFoto = $valor;
    }

    public function Hablar($idioma)
    {
        $bandera = false;
        $string = "El empleado habla ";

        foreach($idioma as $valor)
        {
            if($bandera == false)
            {
                $bandera=true;
                $string .= $valor;
            }
            else
            {
                $string .= ", " . $valor;
            }
        }
        return $string;
    }

    public function ToString()
    {
        return parent::ToString()." - ".$this->GetLegajo()." - ".$this->GetSueldo()." - ".$this->GetTurno()." - ".$this->GetPathFoto();
    }
}