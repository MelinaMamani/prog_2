<?php
// GUZMAN AXEL 2018
session_start();
    
if(!isset($_SESSION["DNIEmpleado"]))
{
    header("Location: ../login.html");
}