<?php
require_once "fabrica.php";
require_once "empleado.php";

$nombreDeArchivo = "../archivos/empleados.txt";
$legajo = $_GET["legajo"];

$sePudoEliminar = false;

$archivo = fopen($nombreDeArchivo, "r");

while(!feof($archivo))
{
    $bufer = fgets($archivo);
    $datos = explode(" - ", $bufer);
    $datos[0] = trim($datos[0]);
    if ($datos[0] != "")
    {
        if ($datos[4] == $legajo)
        {
            $empleado = new Empleado($datos[0],$datos[1],$datos[2],$datos[3],$datos[4],$datos[5],$datos[6]);
            $empleado->SetPathFoto($datos[7]);
            $fabrica = new Fabrica("Fabricota");
            $fabrica->TraerDeArchivo($nombreDeArchivo);
            unlink(trim($empleado->GetPathFoto()));
            if ($fabrica->EliminarEmpleado($empleado))
            {
                $sePudoEliminar = true;
                $fabrica->GuardarEnArchivo($nombreDeArchivo);
            }
        }
    }
}
fclose($archivo);

if ($sePudoEliminar)
{
    echo "Se elimino correctamente.";
}
else
{
    echo "Error. No se pudo eliminar,";
}

echo "<br><a href=./mostrar.php> Mostrar.php </a>";
echo "<br><a href=./index.php> Index.php </a>";
// GUZMAN AXEL 2018
?>