<?php
// GUZMAN AXEL 2018
include_once "persona.php";
include_once "empleado.php";
include_once "fabrica.php";

$empleado1 = new Empleado("Pedro", "Picapiedra", 12365498, 'm', 502369, 10000, "mañana");
$empleado2 = new Empleado("Pablo", "Marmol", 36587602, 'm', 502379, 11000, "noche");
$empleado3 = new Empleado("Vilma", "Picapiedra", 25364988, 'f', 502311, 15000, "mañana");
$idiomas = array("español", "italiano");
$fabrica1 = new Fabrica("Rason Sosial");

echo "Empleado1 ToString: <br>";
echo $empleado1->ToString();
echo "<br>Empleado1 Hablar: <br>";
echo $empleado1->Hablar($idiomas);

echo "<br> <br>";

echo "Agregar empleado 1: ";
if($fabrica1->AgregarEmpleado($empleado1))  echo "true";
else echo "false";

$fabrica1->AgregarEmpleado($empleado2);
$fabrica1->AgregarEmpleado($empleado3);

echo "<br> <br>Fabrica1 Primer ToString: <br>";
echo $fabrica1->ToString();

echo "<br>Eliminar empleado 1: ";
if($fabrica1->EliminarEmpleado($empleado1))
    echo "true";
else
    echo "false";

$fabrica1->AgregarEmpleado($empleado2);
echo "<br> <br>Fabrica1 Segundo ToString: <br>";
echo $fabrica1->ToString();