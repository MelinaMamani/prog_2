<?php
require_once "empleado.php";
require_once "fabrica.php";

$postDni = $_POST["txtDni"];
$postApellido = $_POST["txtApellido"];
$postModificar = isset($_POST["hdnModificar"]) ? $_POST["hdnModificar"] : "n"; // 

$nombreDeArchivo = "../archivos/empleados.txt";

$nameFoto = $_FILES["foto"]["name"];
$sizeFoto = $_FILES["foto"]["size"];
$extension = pathinfo($nameFoto, PATHINFO_EXTENSION);

$pathFoto = "fotos/".$postDni.'-'.$postApellido.'.'.$extension;
$fotoOk = true;
$modifOk = true;

if ($postModificar != "n")
{
    unlink(trim($postModificar));
}

if ($nameFoto == "")
    $fotoOk = false;
else if ($sizeFoto > 1048576)   
    $fotoOk = false;
else if($extension != "jpg" && $extension != "bmp" && $extension != "gif" && $extension != "png" && $extension != "jpeg")
    $fotoOk = false;
else if (file_exists($pathFoto))
    $fotoOk = false;
else if(move_uploaded_file($_FILES["foto"]["tmp_name"],$pathFoto))
{
    $nuevoEmpleado = new Empleado($_POST["txtNombre"],$postApellido,$postDni,$_POST["cboSexo"],$_POST["txtLegajo"],$_POST["txtSueldo"],$_POST["rdoTurno"]);
    $nuevoEmpleado->SetPathFoto($pathFoto);

    $fabrica = new Fabrica("Fabricota");
    $fabrica->TraerDeArchivo($nombreDeArchivo);

    if ($postModificar != "n")
    {
        $empleados = $fabrica->GetEmpleados();
        foreach ($empleados as $e)
        {
            if ($e->GetDNI() == $postDni)
            {
                $modifOk = $fabrica->EliminarEmpleado($e);
                break;
            }
        }
    }
    if ($modifOk)
    {
        $fabrica->AgregarEmpleado($nuevoEmpleado);
        $fabrica->GuardarEnArchivo($nombreDeArchivo);
    }
}
if($fotoOk && $modifOk)
{
    echo "<a href=./mostrar.php> Empleado guardado. Mostrar </a>";
}
else
{
    echo "<a href=./index.php> Error al guardar el empleado. Volver </a>";	
}