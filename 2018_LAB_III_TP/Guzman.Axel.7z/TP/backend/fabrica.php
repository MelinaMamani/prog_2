<?php
require_once "interfaces.php";
require_once "empleado.php";
// GUZMAN AXEL 2018

class Fabrica implements IArchivo
{
    private $_cantidadMaxima;
    private $_empleados;
    private $_razonSocial;

    public function __construct($razonSocial, $cantidadMaxima=5)
    {
        $this->_razonSocial = $razonSocial;
        $this->_cantidadMaxima = $cantidadMaxima;
        $this->_empleados = array();
    }

    public function GetEmpleados()
    {
        return $this->_empleados;
    }

    public function AgregarEmpleado($emp)
    {
        $retorno = false;
        if($this->_cantidadMaxima > count($this->_empleados))
        {
            array_push($this->_empleados, $emp);
            $this->EliminarEmpleadoRepetidos();
            $retorno = true;
        }
        return $retorno;
    }

    public function CalcularSueldos()
    {
        $double = 0;
        foreach($this->_empleados as $emp)
        {
            $double += $emp->GetSueldo();
        }
        return $double;
    }

    public function EliminarEmpleado($emp)
    {
        $retorno = false;
        $i = 0;
        foreach($this->_empleados as $valor)
        {
            if($valor->GetLegajo() == $emp->GetLegajo())
            {
                unset($this->_empleados[$i]);
                $retorno = true;
                break;
            }
            $i++;
        }
        return $retorno;
    }

    private function EliminarEmpleadoRepetidos()
    {
        $this->_empleados = array_unique($this->_empleados, SORT_REGULAR);
    }

    public function ToString()
    {
        $string = $this->_razonSocial . " - " . count($this->_empleados) . " - " . $this->_cantidadMaxima . " <br> ";
        foreach($this->_empleados as $valor)
        {
            $string .= $valor->ToString();
            $string .= "<br>";
        }
        return $string;
    }

    public function TraerDeArchivo($nombreArchivo)
    {
        if (file_exists($nombreArchivo))
        {
            $file = fopen($nombreArchivo, "r");
        
            while(!feof($file))
            {
                $buffer = fgets($file);
                $datos = explode(" - ",$buffer);
                $datos[0] = trim($datos[0]);
                if($datos[0] != "")
                {
                    $empleado = new Empleado($datos[0],$datos[1],$datos[2],$datos[3],$datos[4],$datos[5],$datos[6]);
                    $empleado->SetPathFoto($datos[7]);
                    $this->AgregarEmpleado($empleado);
                }
            }
            fclose($file);
        }
    }

    public function GuardarEnArchivo($nombreArchivo)
    {
        $file = fopen($nombreArchivo, "w");

        foreach ($this->_empleados as $empleadoA)
        {
            fwrite($file, $empleadoA->ToString()."\r\n");
        }
        fclose($file);
    }
}