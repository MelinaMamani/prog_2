<?php
include_once "./validarSesion.php";
include_once "./fabrica.php";
include_once "./empleado.php";

$postDni = isset($_POST["hdnDni"]) ? $_POST["hdnDni"] : NULL;

$estoyModificando = ($postDni != NULL);

$modoLectura = "";

$tituloDePagina = "HTML 5 - Formulario Alta Empleado";
$tituloDeFormulario = "Alta de empleado";

$valueDni = "";
$valueApellido = "";
$valueNombre = "";
$valueMasculino = "";
$valueFem = "";
$valueLegajo = "";
$valueSueldo = "";
$valueTurnoManana = "checked";
$valueTurnoTarde = "";
$valueTurnoNoche = "";

$pathModificar = "n";

if($estoyModificando)
{
    $titulo = "Modificación de empleado";
    $botonTxt = "Modificar";
    
    $fabrica = new Fabrica("Fabricota");
    $fabrica->TraerDeArchivo("../archivos/empleados.txt");
    $empleados = $fabrica->GetEmpleados();
    foreach ($empleados as $e)
    {
        if ($e->GetDni() == $postDni)
        {
            $modoLectura = "readonly";
            $tituloDePagina = "HTML 5 - Formulario Modificacion Empleado";
            $tituloDeFormulario = "Modificar empleado";

            $valueDni = $postDni;
            $valueApellido = $e->GetApellido();
            $valueNombre = $e->GetNombre();
            $valueLegajo = $e->GetLegajo();
            $valueSueldo = $e->GetSueldo();

            if ($e->GetSexo() == 'M')
                $valueMasculino = "selected";
            else
                $valueFem = "selected";

            $turno = $e->GetTurno();
            if ($turno == 'Tarde')
                $valueTurnoTarde = "checked";
            else if ($turno == 'Noche')
                $valueTurnoNoche = "checked";

            $pathModificar = $e->GetPathFoto();

            break;                   
        }
    }
}
// GUZMAN AXEL 2018
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $tituloDePagina; ?></title>
    <script src="../javascript/funciones.js"></script>
</head>
<body>
    <h2><?php echo $tituloDeFormulario; ?></h2>
    <form method="POST" action="administracion.php" enctype="multipart/form-data">
        <table align="center">
				<tr>
					<td colspan="2"><h4>Datos Personales</h4></td>
                </tr>
                <tr>
                    <td colspan="2"><hr></td>
                </tr>
                <tr>
                    <td>DNI:</td>
                    <td><input type="number" name="txtDni" id="txtDni" min="1000000" max="55000000" value="<?php echo $valueDni;?>"<?php echo $modoLectura;?>>
                    <span id="spanDNI" style="display:none">*</span></td>
                </tr>
                <tr>
                    <td>Apellido:</td>
                    <td><input type="text" id="txtApellido" name="txtApellido" value="<?php echo $valueApellido;?>">
                    <span id="spanApellido" style="display:none">*</span></td>
                </tr>
                <tr>
                    <td>Nombre:</td>
                    <td><input type="text" name="txtNombre" id="txtNombre" value="<?php echo $valueNombre;?>">
                    <span id="spanNombre" style="display:none">*</span></td>
                </tr>
                <tr>
                    <td>Sexo:</td>
                    <td><select id="cboSexo" name="cboSexo">
                        <option value="---">Seleccione</option>
                        <option value="M" <?php echo $valueMasculino; ?>>Masculino</option>
                        <option value="F"<?php echo $valueFem; ?>>Femenino</option>
                    </select>
                    <span id="spanSexo" style="display:none">*</span></td>
                </tr>            
                <tr>
                    <td colspan="2"><h4>Datos Laborales</h4></td>
                </tr>
                <tr>
                    <td colspan="2"><hr></td>
                </tr>
                <tr>
                    <td>Legajo:</td>
                    <td><input type="text" name="txtLegajo" id="txtLegajo" maxlength="3" size="3" value="<?php echo $valueLegajo;?>" <?php echo $modoLectura;?>>
                    <span id="spanLegajo" style="display:none">*</span></td>
                </tr>
                <tr>
                    <td>Sueldo:</td>
                    <td><input type="text" name="txtSueldo" id="txtSueldo" value="<?php echo $valueSueldo;?>">
                    <span id="spanSueldo" style="display:none">*</span>
                    </td>
                </tr>
                <tr>
                    <td>Turno:</td>
                </tr>   
                <tr>
                    <td style="padding-left:40px" colspan="2">
                        <input type="radio" name="rdoTurno" id="rdoTurno" value="Mañana" <?php echo $valueTurnoManana; ?>/>Mañana
                    </td>   
                </tr>
                <tr>
                    <td style="padding-left:40px" colspan="2">
                        <input type="radio" name="rdoTurno" id="rdoTurno" value="Tarde" <?php echo $valueTurnoTarde; ?>/>Tarde
                    </td>
                </tr>
                <tr>
                    <td style="padding-left:40px" colspan="2">
                        <input type="radio" name="rdoTurno" id="rdoTurno" value="Noche" <?php echo $valueTurnoNoche; ?>/>Noche
                    </td>
                </tr>
                <tr>
                    <td colspan="2">Foto:
                    <input type="file" name="foto" id="foto">
                    <span id="spanFoto" style="display:none">*</span>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><hr></td>
                </tr>
                <tr>
                    <td colspan="2" align="right">
                        <input type="reset" value="Limpiar">
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="right">
						<input type="submit" id="btnEnviar" value="<?php echo ($estoyModificando) ? "Modificar" : "Enviar"?>" onclick="return AdministrarValidaciones()"/>
                    </td>
                </tr>
        </table>
        <input type="hidden" name="hdnModificar" id="hdnModificar" value="<?php echo $pathModificar; ?>">   
    </form>
    <a href='./cerrarSesion.php'>Cerrar Sesion</a>
</body>
</html>