<?php
// GUZMAN AXEL 2018
require_once "./empleado.php";

$arrayDeEmpleados = array();
if (file_exists("../archivos/empleados.txt"))
{
    $file = fopen("../archivos/empleados.txt", "r");

    while(!feof($file))
    {
        $buffer = fgets($file);
        $datos = explode(" - ",$buffer);
        $datos[0] = trim($datos[0]);
        if($datos[0] != "")
        {
            $empleado = new Empleado($datos[0],$datos[1],$datos[2],$datos[3],$datos[4],$datos[5],$datos[6]);
            $empleado->SetPathFoto($datos[7]);
            array_push($arrayDeEmpleados,$empleado);
        }
    }
    fclose($file);
}

$body='';

foreach ($arrayDeEmpleados as $empleado)
{
    $body.= "<tr>";
    $body.= "<td>" . $empleado->ToString() . "</td>";
    $body.= "<td><img src=" . $empleado->GetPathFoto() . "height='100' width='100'></td>";
    $body.= "<td><a href='./eliminar.php?legajo=" . $empleado->GetLegajo() . "'>Eliminar</a></td>";
    $body.= "<td><input type='button' value='Modificar' onclick='AdministrarModificar(" . $empleado->GetDni() . ")'></td>";
    $body.= '</tr>';
}

?>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="../javascript/funciones.js"></script>
    <title> Mostrar Empleados </title>
</head>
<body>
    <form action="./index.php" method="POST" id="formMostrar">
        <h2>Listado de Empleados</h2>
        <table align="center" border="0">
            <tr>
                <td colspan="4">
                    <h4>Info</h4><hr>
                </td>
            </tr>
                <?php echo $body; ?>
            <tr>
                <td align="center" colspan="4">
                    <hr><a href="./index.php">Index.php</a>
                </td>
            </tr>
            <tr>
                <td align="center" colspan="4">
                    <a href="./cerrarSesion.php">Cerrar Sesion</a>
                </td>
            </tr>
        </table>
        <input type="hidden" name="hdnDni" id="hdnDni">
    </form>
</body>
</html> 