function AdministrarValidaciones() : boolean
{
    let todoOk = false;

    let dni : number = parseInt((<HTMLInputElement> document.getElementById("txtDni")).value);
    let legajo : number = parseInt((<HTMLInputElement> document.getElementById("txtLegajo")).value);
    let sueldo : number = parseInt((<HTMLInputElement> document.getElementById("txtSueldo")).value);

    let dniValido : boolean = ValidarCamposVacios("txtDni") && ValidarRangoNumerico(dni,1000000,55000000);
    let apellidoValido : boolean = ValidarCamposVacios("txtApellido");
    let nombreValido : boolean = ValidarCamposVacios("txtNombre");
    let sexoValido : boolean = ValidarCombo("cboSexo", "---");
    let legajoValido : boolean = ValidarCamposVacios("txtLegajo") && ValidarRangoNumerico(legajo,100,550);
    let sueldoValido : boolean = ValidarCamposVacios("txtSueldo") && ValidarRangoNumerico(sueldo,8000,ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()));
    let fotoValida : boolean = ValidarCamposVacios("foto");
    
    if (dniValido && apellidoValido && nombreValido && sexoValido && legajoValido && sueldoValido && fotoValida)
    {
        todoOk = true;
    }
    else
    {
        AdministrarSpanError("spanDNI",dniValido);
        AdministrarSpanError("spanApellido",apellidoValido);
        AdministrarSpanError("spanNombre",nombreValido);
        AdministrarSpanError("spanSexo",sexoValido);
        AdministrarSpanError("spanSueldo",sueldoValido);
        AdministrarSpanError("spanLegajo",legajoValido);
        AdministrarSpanError("spanFoto",fotoValida);
    }
    return todoOk;
}

function ValidarCamposVacios(idAValidar : string) : boolean
{
    let retorno :boolean = false;
    let cadena = (<HTMLInputElement> document.getElementById(idAValidar)).value;

    if(cadena!="")
    {
        retorno = true;
    }
    return retorno;
}

function ValidarRangoNumerico(valorAValidar:number, minimo:number, maximo:number):boolean
{
    let retorno :boolean = false;

    if(valorAValidar>=minimo && valorAValidar<=maximo)
    {
        retorno = true;
    }
    return retorno;
}

function ValidarCombo(idComboAValidar:string, valorQueNoDebeTener:string):boolean
{
    let retorno :boolean = true;
    let cadena = (<HTMLInputElement> document.getElementById(idComboAValidar)).value;

    if(cadena==valorQueNoDebeTener)
    {
        retorno = false;
    }
    return retorno;
}

function ObtenerTurnoSeleccionado():string
{
    let retorno = "";
    let radios: NodeListOf<HTMLInputElement> = (<NodeListOf<HTMLInputElement>> document.getElementsByName("rdoTurno"));

    radios.forEach(opcion => {
        if(opcion.checked)
        {
            retorno = opcion.value;
        }
    });
    return retorno;
}

function ObtenerSueldoMaximo(turnoElegido:string):number
{
    let retorno : number = 0;

    switch (turnoElegido)
    {
        case "Noche":
        {
            retorno = 25000;
            break;
        }
        case "Tarde":
        {
            retorno = 18500;
            break;
        }
        default:
        {
            retorno = 20000;
            break;
        }
    }
    return retorno;
}

function AdministrarValidacionesLogin() : boolean
{    
    let dni : number = parseInt((<HTMLInputElement> document.getElementById("txtDni")).value);
    let dniValido : boolean = ValidarRangoNumerico(dni,1000000,55000000);
    let apellidoValido : boolean = ValidarCamposVacios("txtApellido");

    AdministrarSpanError("spanDNI",dniValido);
    AdministrarSpanError("spanApellido",apellidoValido);

    return VerificarValidacionesLogin();
}

function AdministrarSpanError(idSpan:string, ocultar:boolean) : void
{
    if (ocultar)
    {
        (<HTMLSpanElement> document.getElementById(idSpan)).style.display="none";
    }
    else
    {
        (<HTMLSpanElement> document.getElementById(idSpan)).style.display="block";
    }
}

function VerificarValidacionesLogin() : boolean
{
    let retorno = false;
    let displayDni = (<HTMLSpanElement> document.getElementById("spanDNI")).style.display; 
    let displayApellido = (<HTMLSpanElement> document.getElementById("spanApellido")).style.display; 

    if(displayDni === "none" && displayApellido === "none")
    {
        retorno = true;
    }
    return retorno;
}

function AdministrarModificar(dni:string) : void
{
    (<HTMLInputElement> document.getElementById("hdnDni")).value = dni;
    (<HTMLFormElement> document.forms["formMostrar"]).submit();
}