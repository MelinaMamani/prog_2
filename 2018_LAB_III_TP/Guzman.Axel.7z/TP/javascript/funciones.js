function AdministrarValidaciones() {
    var todoOk = false;
    var dni = parseInt(document.getElementById("txtDni").value);
    var legajo = parseInt(document.getElementById("txtLegajo").value);
    var sueldo = parseInt(document.getElementById("txtSueldo").value);
    var dniValido = ValidarCamposVacios("txtDni") && ValidarRangoNumerico(dni, 1000000, 55000000);
    var apellidoValido = ValidarCamposVacios("txtApellido");
    var nombreValido = ValidarCamposVacios("txtNombre");
    var sexoValido = ValidarCombo("cboSexo", "---");
    var legajoValido = ValidarCamposVacios("txtLegajo") && ValidarRangoNumerico(legajo, 100, 550);
    var sueldoValido = ValidarCamposVacios("txtSueldo") && ValidarRangoNumerico(sueldo, 8000, ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()));
    var fotoValida = ValidarCamposVacios("foto");
    if (dniValido && apellidoValido && nombreValido && sexoValido && legajoValido && sueldoValido && fotoValida) {
        todoOk = true;
    }
    else {
        AdministrarSpanError("spanDNI", dniValido);
        AdministrarSpanError("spanApellido", apellidoValido);
        AdministrarSpanError("spanNombre", nombreValido);
        AdministrarSpanError("spanSexo", sexoValido);
        AdministrarSpanError("spanSueldo", sueldoValido);
        AdministrarSpanError("spanLegajo", legajoValido);
        AdministrarSpanError("spanFoto", fotoValida);
    }
    return todoOk;
}
function ValidarCamposVacios(idAValidar) {
    var retorno = false;
    var cadena = document.getElementById(idAValidar).value;
    if (cadena != "") {
        retorno = true;
    }
    return retorno;
}
function ValidarRangoNumerico(valorAValidar, minimo, maximo) {
    var retorno = false;
    if (valorAValidar >= minimo && valorAValidar <= maximo) {
        retorno = true;
    }
    return retorno;
}
function ValidarCombo(idComboAValidar, valorQueNoDebeTener) {
    var retorno = true;
    var cadena = document.getElementById(idComboAValidar).value;
    if (cadena == valorQueNoDebeTener) {
        retorno = false;
    }
    return retorno;
}
function ObtenerTurnoSeleccionado() {
    var retorno = "";
    var radios = document.getElementsByName("rdoTurno");
    radios.forEach(function (opcion) {
        if (opcion.checked) {
            retorno = opcion.value;
        }
    });
    return retorno;
}
function ObtenerSueldoMaximo(turnoElegido) {
    var retorno = 0;
    switch (turnoElegido) {
        case "Noche":
            {
                retorno = 25000;
                break;
            }
        case "Tarde":
            {
                retorno = 18500;
                break;
            }
        default:
            {
                retorno = 20000;
                break;
            }
    }
    return retorno;
}
function AdministrarValidacionesLogin() {
    var dni = parseInt(document.getElementById("txtDni").value);
    var dniValido = ValidarRangoNumerico(dni, 1000000, 55000000);
    var apellidoValido = ValidarCamposVacios("txtApellido");
    AdministrarSpanError("spanDNI", dniValido);
    AdministrarSpanError("spanApellido", apellidoValido);
    return VerificarValidacionesLogin();
}
function AdministrarSpanError(idSpan, ocultar) {
    if (ocultar) {
        document.getElementById(idSpan).style.display = "none";
    }
    else {
        document.getElementById(idSpan).style.display = "block";
    }
}
function VerificarValidacionesLogin() {
    var retorno = false;
    var displayDni = document.getElementById("spanDNI").style.display;
    var displayApellido = document.getElementById("spanApellido").style.display;
    if (displayDni === "none" && displayApellido === "none") {
        retorno = true;
    }
    return retorno;
}
function AdministrarModificar(dni) {
    document.getElementById("hdnDni").value = dni;
    document.forms["formMostrar"].submit();
}
