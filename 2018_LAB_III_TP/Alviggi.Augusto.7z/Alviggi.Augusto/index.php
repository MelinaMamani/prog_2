<?php
include "backend/validarSesion.php";
if(isset($_POST['hidModificar']))
{
    $dni = $_POST['hidModificar'];
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script type="text/javascript" src="javascript/funciones.js"></script>
    <title>HTML 5 - Formulario Alta Empleado</title>
    <?php
if (isset($dni)) 
{
    require "backend/php/fabrica.php";

    echo '<script type="text/javascript" src="javascript/cargarFormulario.js"></script>';
    $nuevaFabrica = new Fabrica("Fabrica Programacion", 7);
    $nuevaFabrica->TraerDeArchivo("backend/archivos/empleados.txt", true);
    $arrayEmpleados = $nuevaFabrica->GetEmpleados();

}
?>
</head>

<body>
    <h2 id="tituloForm">Alta de Empleados</h2>
    <form method="POST" action="backend/administracion.php" onsubmit="return AdministrarValidaciones()" enctype="multipart/form-data">
        <?php
if (isset($dni)) 
{
    echo '<input type="hidden" name="hdnModificar" value="1">';
}
?>
        <table align="center">
            <th colspan="2">
                <h4 align="left">Datos Personales</h4>
                <hr>
            </th>
            <tr>
                <td>
                    <label for="txtDni">DNI:</label>
                </td>
                <td>
                    <input type="number" name="txtDni" id="txtDni" min="1000000" max="55000000">
                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="txtApellido">Apellido:</label>

                </td>
                <td>
                    <input type="text" name="txtApellido" id="txtApellido">
                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="txtNombre">Nombre:</label>

                </td>
                <td>
                    <input type="text" name="txtNombre" id="txtNombre">
                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="cboSexo">Sexo:</label>

                </td>
                <td>
                    <select name="cboSexo" id="cboSexo">
                        <option value="---">Seleccione</option>
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </select>
                    <span style="display:none">*</span>
                </td>
            </tr>

            <th colspan="2">
                <h4 align="left">Datos Laborales</h4>
                <hr>
            </th>
            <tr>
                <td>
                    <label for="txtLegajo">Legajo:</label>
                </td>
                <td>
                    <input type="number" min="100" max="550" id="txtLegajo" name="txtLegajo">
                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="txtSueldo">Sueldo:</label>
                    <span style="display:none">*</span>
                </td>
                <td>
                    <input type="number" min="8000" max="25000" step="500" id="txtSueldo" name="txtSueldo">
                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="rdoTurno">Turno:</label>

                </td>
                <tr>
                    <td></td>
                    <td>
                        <input type="radio" name="rdoTurno" id="rdoTurnoMañana" value="Mañana" checked>
                        <label for="rdoTurnoMañana">Mañana</label>
                        <br>
                        <input type="radio" name="rdoTurno" id="rdoTurnoTarde" value="Tarde">
                        <label for="rdoTurnoTarde">Tarde</label>
                        <br>
                        <input type="radio" name="rdoTurno" id="rdoTurnoNoche" value="Noche">
                        <label for="rdoTurnoNoche">Noche</label>
                        <br>
                    </td>
                </tr>
            </tr>
            <tr>
                <td>
                    Foto:
                </td>
                <td>
                    <input type="file" name="fotoEmpleado" id="fotoEmpleado">
<?php
if (isset($dni)) 
{
    echo '<label for="chckNoFoto">No sube foto</label>
                                            <input type="checkbox" value="si" name="chckNoFoto" id="chckNoFoto" checked>';
}
?>

                    <span style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right">
                    <button type="reset" name="btnLimpiar" id="btnLimpiar">Limpiar</button>
                    <br>
                    <button type="submit" name="btnEnviar" id="btnEnviar">Enviar</button>
                </td>
            </tr>
        </table>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <a href="backend/cerrarSesion.php">Cerrar Sesión</a>

    </form>
    <?php
if (isset($dni)) 
{
    foreach ($arrayEmpleados as $empleado) 
    {
        if ($empleado->GetDni() == $dni) 
        {
            $apellido = $empleado->GetApellido();
            $nombre = $empleado->GetNombre();
            $sexo = $empleado->GetSexo();
            $legajo = $empleado->GetLegajo();
            $sueldo = $empleado->GetSueldo();
            $turno = $empleado->GetTurno();
            $pathFoto = $empleado->GetPathFoto();
            echo "<script>ModificarEmpleados('$dni', '$apellido', '$nombre', '$sexo', '$legajo', '$sueldo', '$turno', '$pathFoto' );</script>";
        }
    }
}

?>
</body>

</html>