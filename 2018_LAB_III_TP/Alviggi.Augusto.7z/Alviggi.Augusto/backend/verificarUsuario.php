<?php

require "php/fabrica.php";

session_start();
$dni=$_POST['txtDni'];
$apellido=$_POST['txtApellido'];
$ruta="archivos/empleados.txt";
$archivoEmpleados = fopen($ruta,"r");
$cadenaBuscada = "$apellido - $dni";
$stringEmpleados = fread($archivoEmpleados,filesize($ruta));
fclose($archivoEmpleados);

if (strpos($stringEmpleados, $cadenaBuscada) !== false) 
{
    $_SESSION['DNIEmpleado']=$dni;    
    header("Location: mostrar.php");
    exit;
}
else
{
    echo 'Empleado no encontrado, volver al <a href="../login.html">indice</a>';    
}
