<?php
session_start();

if (!$_SESSION['DNIEmpleado']) 
{
    if (file_exists('login.html')) 
    {
        header("Location: login.html");
    } 
    else 
    {
        header("Location: ../login.html");
    }
    exit;
}
