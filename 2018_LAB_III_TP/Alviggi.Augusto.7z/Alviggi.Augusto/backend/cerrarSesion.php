<?php
session_start();

if ($_SESSION['DNIEmpleado']) 
{
    session_destroy();
    header("Location: ../login.html");
    exit;
}
header("Location: ../login.html");
