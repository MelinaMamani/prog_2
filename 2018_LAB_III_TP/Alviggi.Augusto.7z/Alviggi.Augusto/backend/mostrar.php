<?php

include "validarSesion.php";

?>
<!DOCTYPE html>
<head>
    <script type="text/javascript" src="../javascript/funciones.js"></script>
    <meta charset="UTF-8">
    <title>HTML 5 – Listado de Empleados</title>

</head>
<body>
<table>
    <form action="../index.php" method="POST" id="frmModificar">
        <input type="hidden" id="hidModificar" name="hidModificar">
    </form>
<?php
require "php/fabrica.php";
$ruta = "archivos/empleados.txt";
$archivoDeEmpleados = fopen($ruta, "r");
echo "Empleados: <br>";
while (!feof($archivoDeEmpleados)) 
{
    $lineaDeTexto = trim(fgets($archivoDeEmpleados));
    
    if ($lineaDeTexto) 
    {
        $empRecortado = explode(" - ", $lineaDeTexto);
        $empleadoOrdenado = $empRecortado[2] . " - " . $empRecortado[0] . " - " . $empRecortado[1] . " - " . $empRecortado[3] . " - " . $empRecortado[4] . " - " . $empRecortado[5] . " - " . $empRecortado[6][0] . " - " . $empRecortado[7];
        echo "<tr><td>$empleadoOrdenado</td><td><img src='" . $empRecortado[7] . "'width='90px' height='90px'/></td><td><a href='eliminar.php?id=" . $empRecortado[4] . "'>Eliminar</a></td><td><input type='button' value='Modificar' onclick='AdministrarModificar(" . $empRecortado[2] . ")'></td></tr>";
    }
}
fclose($archivoDeEmpleados);
?>
</table>

<p><a href="../index.php">Alta de Empleados</a></p>
<a href="cerrarSesion.php">Cerrar Sesión</a>
</body>
</html>
