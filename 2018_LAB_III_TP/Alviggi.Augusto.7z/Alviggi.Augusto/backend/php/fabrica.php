<?php

require_once "empleado.php";
require_once "interfaces.php";

class Fabrica implements IArchivo
{
    private $_cantidadMaxima;
    private $_empleados = array();
    private $_razonSocial;

    public function __construct($razonSocial, $cantidadMaxima=5)
    {
        $this->_razonSocial=$razonSocial;
        $this->_cantidadMaxima=$cantidadMaxima;
        $this->_empleados=array();
    }

    public function AgregarEmpleado($emp)
    {
        if(count($this->_empleados)<$this->_cantidadMaxima)
        {
            array_push($this->_empleados,$emp);
            $this->EliminarEmpleadosRepetidos();
            return true;
        }
        else
        {
            return false;
        }
    }

    public function CalcularSueldos()
    {
        $auxSueldo = 0;
        
        foreach($this->_empleados as $empleado)
        {
            $auxSueldo += $empleado->GetSueldo();
        }
        return $auxSueldo;
    }

    public function EliminarEmpleado($emp)
    {
        if(($ubicacion=array_search($emp,$this->_empleados))!==false)
        {
            unset($this->_empleados[$ubicacion]);
            return true;
        }
        else
        {
            return false;
        }
    }

    public function GetEmpleados()
    {
        return $this->_empleados;
    }

    public function ToString()
    {
        $auxRetorno = $this->_razonSocial;

        foreach($this->_empleados as $empleado)
        {
            $auxRetorno = $auxRetorno."<br>".$empleado->ToString();
        }
        return $auxRetorno;
    }

    public function GuardarEnArchivo($nombreArchivo)
    {
        $ruta="archivos/".$nombreArchivo;
        $archivoDeEmpleados=fopen($ruta,"w");
        $auxEscritura = "";

        foreach($this->_empleados as $unEmpleado)
        {
            $auxEscritura=$auxEscritura.$unEmpleado->ToString()."\r\n";
        }
        if(!(fwrite($archivoDeEmpleados, $auxEscritura)))
        {
            fclose($archivoDeEmpleados);            
            return false;
        }
        
        fclose($archivoDeEmpleados);        
        return true;

    }

    public function TraerDeArchivo($nombreArchivo, $fullPath=false)
    {
        if($fullPath==true)
        {
            $ruta=$nombreArchivo;
        }
        else
        {
            $ruta="archivos/".$nombreArchivo;            
        }
        $archivoDeEmpleados=fopen($ruta,"r");

        while(!feof($archivoDeEmpleados))
        {
            $lineaDeTexto=trim(fgets($archivoDeEmpleados));
            if($lineaDeTexto)
            {
                $empRecortado=explode(" - ",$lineaDeTexto);
                $unEmpleado = new Empleado($empRecortado[0],$empRecortado[1],$empRecortado[2],$empRecortado[3],$empRecortado[4],$empRecortado[5],$empRecortado[6]);
                $unEmpleado->SetPathFoto($empRecortado[7]);
                $this->AgregarEmpleado($unEmpleado);
            }
        }
        
        fclose($archivoDeEmpleados);
    }
    private function EliminarEmpleadosRepetidos()
    {
        if(count($this->_empleados)>1)
        {
            $this->_empleados=array_unique($this->_empleados);
        }
    }
}

?>