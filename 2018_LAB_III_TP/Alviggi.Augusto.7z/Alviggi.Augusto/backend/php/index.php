<?php
include_once "empleado.php";
include_once "fabrica.php";
$idiomas=array("Español", "Inglés", "Francés");
$Empleado1 = new Empleado("TestNombre1","TestApellido1",39906650,'M',10,28000,"Mañana");
$Empleado2 = new Empleado("TestNombre2","TestApellido2",39906650,'M',10,28000,"Mañana");
$Empleado3 = new Empleado("TestNombre3","TestApellido3",39906650,'M',10,28000,"Mañana");
$Empleado4 = new Empleado("TestNombre4","TestApellido4",39906650,'M',10,28000,"Mañana");
$Empleado5 = new Empleado("TestNombre5","TestApellido5",39906650,'M',10,28000,"Mañana");
$Empleado6 = new Empleado("TestNombre6","TestApellido6",39906650,'M',10,28000,"Mañana");


echo "<-------------------------------------------Test Empleado------------------------------------------------------><br>";
echo $Empleado1->ToString();
echo "<br>";
echo $Empleado1->Hablar($idiomas);

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<-------------------------------------------Test Cargar Empleados y Empleado Duplicado------------------------------------------------------><br>";

$unaFabrica = new Fabrica("La Fábrica");

if($unaFabrica->AgregarEmpleado($Empleado1)){}
else{
    echo "Fabrica llena1";
}

if($unaFabrica->AgregarEmpleado($Empleado2)){}
else{
    echo "Fabrica llena2";
}

if($unaFabrica->AgregarEmpleado($Empleado3)){}
else{
    echo "Fabrica llena3";
}

if($unaFabrica->AgregarEmpleado($Empleado3)){}
else{
    echo "Fabrica llena4";
}

if($unaFabrica->AgregarEmpleado($Empleado5)){}
else{
    echo "Fabrica llena5";
}

if($unaFabrica->AgregarEmpleado($Empleado6)){
    echo $unaFabrica->ToString();
}
else{
    echo "Fabrica llena";
}
echo "<br>";
if($unaFabrica->AgregarEmpleado($Empleado4)){}
else{
        echo "Fabrica llena";
}
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<-------------------------------------------Test Sueldos------------------------------------------------------><br>";
echo $unaFabrica->CalcularSueldos();

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";

echo "<-------------------------------------------Test Eliminar------------------------------------------------------><br>";
if($unaFabrica->EliminarEmpleado($Empleado3)){
    echo "Empleado 3 eliminado con éxito <br> <br>";
}
echo $unaFabrica->ToString();

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<-------------------------------------------Test Sueldos Después de Eliminar------------------------------------------------------><br>";
echo $unaFabrica->CalcularSueldos();



?>
