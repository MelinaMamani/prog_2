<?php

require_once "php/fabrica.php";

if(isset($_POST['hdnModificar']))
{
    $hdnModificar=$_POST['hdnModificar'];
}
$MB = 1048576;
$extensionFoto = pathinfo($_FILES["fotoEmpleado"]["name"])["extension"];
$tamañoFoto = $_FILES["fotoEmpleado"]["size"];
$extensionesPermitidas = array('jpg', 'bmp', 'gif', 'png', 'jpeg');
$rutaImagen = "fotos/" . $_POST['txtDni'] . "-" . $_POST['txtApellido'] . ".$extensionFoto";

if ($hdnModificar) 
{
    $ruta = "archivos/empleados.txt";
    $archivoDeEmpleados = fopen($ruta, "r");
    while (!feof($archivoDeEmpleados)) 
    {
        $lineaDeTexto = trim(fgets($archivoDeEmpleados));
        if ($lineaDeTexto) 
        {
            $empRecortado = explode(" - ", $lineaDeTexto);
            if ($empRecortado[2] == $_POST['txtDni']) 
            {
                $unEmpleado = new Empleado($empRecortado[0], $empRecortado[1], $empRecortado[2], $empRecortado[3], $empRecortado[4], $empRecortado[5], $empRecortado[6]);
                $unEmpleado->SetPathFoto($empRecortado[7]);
                break;
            }
        }
    }
    fclose($archivoDeEmpleados);
    $nuevaFabrica = new Fabrica("Fabrica Programacion", 7);
    $nuevaFabrica->TraerDeArchivo("empleados.txt");

    if ($nuevaFabrica->EliminarEmpleado($unEmpleado)) 
    {
        $nuevaFabrica->GuardarEnArchivo("empleados.txt");
        if ($_POST['chckNoFoto'] != "si") 
        {
            if (!unlink($empRecortado[7])) 
            {
                echo "Hubo un error al eliminar el empleado";
            }
        }
    }
}

if ((in_array($extensionFoto, $extensionesPermitidas) && $tamañoFoto <= $MB && !file_exists($rutaImagen) && is_array(getimagesize($_FILES['fotoEmpleado']['tmp_name']))) || $_POST['chckNoFoto'] == "si") {
    if ($_POST['chckNoFoto'] != "si")
    {
        move_uploaded_file($_FILES['fotoEmpleado']['tmp_name'], $rutaImagen);
    } 
    else 
    {
        $extensionFoto = (explode(".", $empRecortado[7]));
        $rutaImagen .= $extensionFoto;

        if (file_exists($empRecortado[7]) && $empRecortado[7] != $rutaImagen)
        {
            rename($empRecortado[7], $rutaImagen);
        }
    }

    $nuevoEmpleado = new Empleado($_POST['txtNombre'], $_POST['txtApellido'], $_POST['txtDni'], $_POST['cboSexo'], $_POST['txtLegajo'], $_POST['txtSueldo'], $_POST['rdoTurno']);
    $nuevoEmpleado->SetPathFoto($rutaImagen);
    $nuevaFabrica = new Fabrica("Fabrica Programacion", 7);
    $nuevaFabrica->TraerDeArchivo("empleados.txt");

    if ($nuevaFabrica->AgregarEmpleado($nuevoEmpleado)) {
        if (!$nuevaFabrica->GuardarEnArchivo("empleados.txt"))
        {
            echo "<a href=../index.php>Error al escribir archivo, ir al indice</a>";
        } 
        else 
        {
            echo "<a href=mostrar.php>Éxito, mostrar lista de empleados</a>";
        }
    } 
    else 
    {
        echo "<a href=../index.php>Error al agregar empleado (fábrica llena), ir al indice</a>";
    }
} 
else 
{
    echo "<a href=../index.php>Error al cargar la imagen, ir al indice</a>";
}
