<?php
require_once "php/fabrica.php";

$legajo = $_GET["id"];
$ruta = "archivos/empleados.txt";
$archivoDeEmpleados = fopen($ruta, "r");

while (!feof($archivoDeEmpleados)) 
{

    $lineaDeTexto = trim(fgets($archivoDeEmpleados));
    if ($lineaDeTexto) 
    {
        $empRecortado = explode(" - ", $lineaDeTexto);
        if ($empRecortado[4] == $legajo) 
        {
            $unEmpleado = new Empleado($empRecortado[0], $empRecortado[1], $empRecortado[2], $empRecortado[3], $empRecortado[4], $empRecortado[5], $empRecortado[6]);
            $unEmpleado->SetPathFoto($empRecortado[7]);
            break;
        }
    }
}
fclose($archivoDeEmpleados);

if ($unEmpleado) 
{
    $nuevaFabrica = new Fabrica("Fabrica Programacion", 7);
    $nuevaFabrica->TraerDeArchivo("empleados.txt");

    if ($nuevaFabrica->EliminarEmpleado($unEmpleado)) 
    {
        $nuevaFabrica->GuardarEnArchivo("empleados.txt");

        if (unlink($unEmpleado->GetPathFoto())) 
        {
            echo "Empleado eliminado con éxito";
        } else 
        {
            echo "No se pudo eliminar la imagen del empleado";
        }
    } else 
    {
        echo "Hubo un error al eliminar el empleado";
    }
} else 
{
    echo "El empleado no existe o ya fue borrado!!";
}
?>
<br>
<a href="../index.php">Volver al índice</a>
