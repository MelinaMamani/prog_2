function ModificarEmpleados(dni, apellido, nombre, sexo, legajo, sueldo, turno, foto) {
    var turnoSeleccionado = turno;
    var sexoSeleccionado = 0;
    switch (sexo) {
        case "M":
            sexoSeleccionado = 1;
            break;
        case "F":
            sexoSeleccionado = 2;
            break;
    }
    switch (turno) {
        case "Mañana":
            turnoSeleccionado = "rdoTurnoMañana";
            break;
        case "Tarde":
            turnoSeleccionado = "rdoTurnoTarde";
            break;
        case "Noche":
            turnoSeleccionado = "rdoTurnoNoche";
            break;
    }
    document.title = "HTML5 Formulario Modificar Empleado";
    document.getElementById("tituloForm").innerHTML = "Modificar Empleado";
    document.getElementById("btnEnviar").innerHTML = "Modificar";
    document.getElementById("txtDni").value = dni;
    document.getElementById("txtDni").readOnly = true;
    document.getElementById("txtApellido").value = apellido;
    document.getElementById("txtNombre").value = nombre;
    document.getElementById("cboSexo").selectedIndex = sexoSeleccionado;
    document.getElementById("txtLegajo").value = legajo;
    document.getElementById("txtLegajo").readOnly = true;
    document.getElementById("txtSueldo").value = sueldo;
    document.getElementById(turnoSeleccionado).checked = true;
    document.getElementById("fotoEmpleado").value = foto;
}
