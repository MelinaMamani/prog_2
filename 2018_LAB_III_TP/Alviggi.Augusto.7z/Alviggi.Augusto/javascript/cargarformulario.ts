function ModificarEmpleados(dni: string, apellido: string, nombre: string, sexo: string, legajo: string, sueldo: string, turno: string, foto: string): void {

    let turnoSeleccionado = turno;
    let sexoSeleccionado = 0;

    switch (sexo) 
    {
        case "M":
            sexoSeleccionado = 1;
            break;
        case "F":
            sexoSeleccionado = 2;
            break;
    }
    switch (turno) 
    {
        case "Mañana":
            turnoSeleccionado = "rdoTurnoMañana";
            break;
        case "Tarde":
            turnoSeleccionado = "rdoTurnoTarde";

            break;
        case "Noche":
            turnoSeleccionado = "rdoTurnoNoche";
            break;
    }

    document.title = "HTML5 Formulario Modificar Empleado";
    (<HTMLElement>document.getElementById("tituloForm")).innerHTML = "Modificar Empleado";
    (<HTMLElement>document.getElementById("btnEnviar")).innerHTML = "Modificar";
    (<HTMLInputElement>document.getElementById("txtDni")).value = dni;
    (<HTMLInputElement>document.getElementById("txtDni")).readOnly = true;
    (<HTMLInputElement>document.getElementById("txtApellido")).value = apellido;
    (<HTMLInputElement>document.getElementById("txtNombre")).value = nombre;
    (<HTMLSelectElement>document.getElementById("cboSexo")).selectedIndex = sexoSeleccionado;
    (<HTMLInputElement>document.getElementById("txtLegajo")).value = legajo;
    (<HTMLInputElement>document.getElementById("txtLegajo")).readOnly = true;
    (<HTMLInputElement>document.getElementById("txtSueldo")).value = sueldo;
    (<HTMLInputElement>document.getElementById(turnoSeleccionado)).checked = true;
    (<HTMLInputElement>document.getElementById("fotoEmpleado")).value = foto;


}
