"use strict";
function AdministrarValidaciones() {
    var dni = Number(document.getElementById("txtDni").value);
    var sueldo = Number(document.getElementById("txtSueldo").value);
    var sueldoMaximo = ObtenerSueldoMaximo(ObtenerSueldoSeleccionado());
    var legajo = Number(document.getElementById("txtLegajo").value);
    var validarDni = ValidarRangoNumerico(dni, 55000000, 1000000) && ValidarCamposVacios("txtDni");
    var validarLegajo = ValidarRangoNumerico(legajo, 550, 100) && ValidarCamposVacios("txtLegajo");
    var validarSueldo = ValidarRangoNumerico(sueldo, sueldoMaximo, 8000) && ValidarCamposVacios("txtSueldo");
    AdministrarSpanError("txtDni", !validarDni);
    AdministrarSpanError("txtApellido", !ValidarCamposVacios("txtApellido"));
    AdministrarSpanError("txtNombre", !ValidarCamposVacios("txtNombre"));
    AdministrarSpanError("txtLegajo", !validarLegajo);
    AdministrarSpanError("txtSueldo", !validarSueldo);
    AdministrarSpanError("cboSexo", !ValidarCombo("cboSexo", "---"));
    AdministrarSpanError("fotoEmpleado", !ValidarCamposVacios("fotoEmpleado"));
    return VerificarValidacionesLogin();
}
function AdministrarValidacionesLogin() {
    var dni = Number(document.getElementById("txtDni").value);
    var validarDni = !(ValidarCamposVacios("txtDni") && ValidarRangoNumerico(dni, 55000000, 1000000));
    AdministrarSpanError("txtDni", validarDni);
    AdministrarSpanError("txtApellido", !ValidarCamposVacios("txtApellido"));
    return VerificarValidacionesLogin();
}
function ValidarCamposVacios(campoAValidar) {
    if (document.getElementById(campoAValidar).value != "") {
        return true;
    }
    else {
        return false;
    }
}
function ValidarRangoNumerico(campoAValidar, valorMax, valorMin) {
    return campoAValidar >= valorMin && campoAValidar <= valorMax;
}
function ValidarCombo(idAtributo, valorQueNoDebeTener) {
    return document.getElementById(idAtributo).value != valorQueNoDebeTener;
}
function ObtenerSueldoSeleccionado() {
    if (document.getElementById("rdoTurnoMañana").checked) {
        return "mañana";
    }
    else if (document.getElementById("rdoTurnoTarde").checked) {
        return "tarde";
    }
    else {
        return "noche";
    }
}
function ObtenerSueldoMaximo(turno) {
    if (turno == "mañana") {
        return 20000;
    }
    else if (turno == "tarde") {
        return 18500;
    }
    else {
        return 25000;
    }
}
function AdministrarSpanError(id, mostrar) {
    var blockOrNone;
    if (mostrar) {
        blockOrNone = "block";
    }
    else {
        blockOrNone = "none";
    }
    document.getElementById(id).nextElementSibling.style.display = blockOrNone;
}
function VerificarValidacionesLogin() {
    var auxRetorno = true;
    var listaNode = document.querySelectorAll("span");
    var arraySpans = Array.prototype.slice.call(listaNode);
    arraySpans.forEach(function (element) {
        if (element.style.display == "block") {
            auxRetorno = false;
        }
    });
    return auxRetorno;
}
function AdministrarModificar(dni) {
    document.getElementById("hidModificar").value = dni;
    document.getElementById("frmModificar").submit();
}
