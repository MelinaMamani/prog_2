function AdministrarValidaciones(): boolean {
    
    let dni = Number((<HTMLInputElement>document.getElementById("txtDni")).value);
    let sueldo = Number((<HTMLInputElement>document.getElementById("txtSueldo")).value);
    let sueldoMaximo = ObtenerSueldoMaximo(ObtenerSueldoSeleccionado());
    let legajo = Number((<HTMLInputElement>document.getElementById("txtLegajo")).value);

    let validarDni: boolean = ValidarRangoNumerico(dni, 55000000, 1000000) && ValidarCamposVacios("txtDni");
    let validarLegajo: boolean = ValidarRangoNumerico(legajo, 550, 100) && ValidarCamposVacios("txtLegajo");
    let validarSueldo: boolean = ValidarRangoNumerico(sueldo, sueldoMaximo, 8000) && ValidarCamposVacios("txtSueldo");

    AdministrarSpanError("txtDni", !validarDni);
    AdministrarSpanError("txtApellido", !ValidarCamposVacios("txtApellido"));
    AdministrarSpanError("txtNombre", !ValidarCamposVacios("txtNombre"));
    AdministrarSpanError("txtLegajo", !validarLegajo);
    AdministrarSpanError("txtSueldo", !validarSueldo);
    AdministrarSpanError("cboSexo", !ValidarCombo("cboSexo", "---"));
    AdministrarSpanError("fotoEmpleado", !ValidarCamposVacios("fotoEmpleado"));


    return VerificarValidacionesLogin();
}

function AdministrarValidacionesLogin(): boolean {
    
    let dni = Number((<HTMLInputElement>document.getElementById("txtDni")).value);
    let validarDni = !(ValidarCamposVacios("txtDni") && ValidarRangoNumerico(dni, 55000000, 1000000));
    AdministrarSpanError("txtDni", validarDni);
    AdministrarSpanError("txtApellido", !ValidarCamposVacios("txtApellido"));


    return VerificarValidacionesLogin();
}

function ValidarCamposVacios(campoAValidar: string): boolean {

    let retorno = false;

    if ((<HTMLInputElement>document.getElementById(campoAValidar)).value != "") 
    {
        retorno = true;
    }
    else 
    {
        retorno = false;
    }
    return retorno;
}

function ValidarRangoNumerico(campoAValidar: number, valorMax: number, valorMin: number): boolean {

    return campoAValidar >= valorMin && campoAValidar <= valorMax;
}

function ValidarCombo(idAtributo: string, valorQueNoDebeTener: string): boolean {

    return (<HTMLInputElement>document.getElementById(idAtributo)).value != valorQueNoDebeTener;
}

function ObtenerSueldoSeleccionado(): string {

    if ((<HTMLInputElement>document.getElementById("rdoTurnoMañana")).checked) 
    {
        return "mañana";
    }
    else if ((<HTMLInputElement>document.getElementById("rdoTurnoTarde")).checked) 
    {
        return "tarde";
    }
    else 
    {
        return "noche";
    }
}

function ObtenerSueldoMaximo(turno: string): number {

    if (turno == "mañana") 
    {
        return 20000;
    }
    else if (turno == "tarde") 
    {
        return 18500;
    }
    else 
    {
        return 25000;
    }
}

function AdministrarSpanError(id: string, mostrar: boolean) {

    let blockOrNone: string;
    if (mostrar) 
    {
        blockOrNone = "block";
    }
    else
    {
        blockOrNone = "none";
    }
    (<HTMLElement>(<HTMLElement>document.getElementById(id)).nextElementSibling).style.display = blockOrNone;
}

function VerificarValidacionesLogin(): boolean {

    let auxRetorno = true;
    let listaNode: NodeList = document.querySelectorAll("span");
    let arraySpans: HTMLSpanElement[] = Array.prototype.slice.call(listaNode);

    arraySpans.forEach(function (element) 
    {
        if (element.style.display == "block") 
        {
            auxRetorno = false;
        }
    })
    return auxRetorno;
}

function AdministrarModificar(dni: string) {

    (<HTMLInputElement>document.getElementById("hidModificar")).value = dni;
    (<HTMLFormElement>document.getElementById("frmModificar")).submit();
}