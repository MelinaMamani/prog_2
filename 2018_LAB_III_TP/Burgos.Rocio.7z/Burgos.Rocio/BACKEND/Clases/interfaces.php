<?php

interface IArchivos{
    public function GuardarEnArchivo($nombreArchivo);
    public function TraerDeArchivo($nombreArchivo);
}
?>