<?php
require_once "Empleado.php";
require_once "Interfaces.php";

class Fabrica implements IArchivo
{
    private $_cantidadMaxima;
    private $_empleados;
    private $_razonSocial;

    public function __construct($RazonSocial, $Cantidad)
    {
        $this->_cantidadMaxima = $Cantidad;
        $this->_empleados = array();
        $this->_razonSocial = $RazonSocial;
    }

    public function GetEmpleados()
    {
        return $this->_empleados;
    }

    public function AgregarEmpleado($empleado)
    {        
        $CantidadEmpleados;

        foreach($this->_empleados as $value)
        {
            if($value->GetLegajo() === $empleado->GetLegajo())
            {
                return false;
            }
        }

        if(count($this->_empleados) < $this->_cantidadMaxima)
        {
            array_push($this->_empleados, $empleado);
            $CantidadEmpleados = count($this->_empleados);
            $this->EliminarEmpleadoRepetido();
        }
        
        if($CantidadEmpleados == count($this->_empleados))
        {
            return true;
        }
        return false;
    }

    public function TraerDeArchivo($nombreArchivo)
    {
        $ar = fopen($nombreArchivo, "r");
        $linea="";

        while(($linea = fgets($ar)) !== false)
        {
            $linea = trim($linea);
            $empleadoArray = explode(" - ", $linea);
            $Empleado = new Empleado($empleadoArray[0], $empleadoArray[1], $empleadoArray[2], $empleadoArray[3],
            $empleadoArray[4], $empleadoArray[5], $empleadoArray[6]);
            $Empleado->SetPathFoto($empleadoArray[7]);
            $this->AgregarEmpleado($Empleado);            
        }
        fclose($ar);
    }

    public function GuardarEnArchivo($nombreArchivo)
    {
        $ar = fopen("../Archivos/".$nombreArchivo, "w");
        
        foreach($this->_empleados as $value)
        {
            fwrite($ar, $value->ToString()."\r\n");
        }

        fclose($ar);
    }

    public function CalcularSueldos()
    {
        $Sueldos=0;
        foreach ($this->_empleados as $value) {
            $Sueldos += $value->GetSueldo();
        }
        return $Sueldos;
    }

    public function EliminarEmpleado($EmpleadoEliminar)
    {
        foreach ($this->_empleados as $key => $value) {
            if($value == $EmpleadoEliminar)
            {
                unlink($this->_empleados[$key]->GetPathFoto());
                unset($this->_empleados[$key]);
                return TRUE;
            }
        }
        return FALSE;
    }
    
    private function EliminarEmpleadoRepetido()
    {
        $this->_empleados = array_unique($this->_empleados, SORT_REGULAR);
    }

    public function ToString()
    {
        $retorno = $this->_razonSocial."<br/>";
        foreach($this->_empleados as $item)
        {
            $retorno .="&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp-".$item->ToString()."<br/>";
        }
        $retorno .= "-Sueldos: ".$this->CalcularSueldos();
        return $retorno;
    }

    
}
?>