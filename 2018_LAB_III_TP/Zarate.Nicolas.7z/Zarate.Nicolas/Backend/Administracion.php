<?php
session_start();
require_once "../Clases/Empleado.php";
require_once "../Clases/Fabrica.php";

$alta = isset($_POST["btnEnviar"]) ? TRUE : FALSE;


/* ********************************Validaciones de Foto************************************ */
$nombre = $_FILES["Foto"]["name"];
$ext  = pathinfo($nombre, PATHINFO_EXTENSION);
$ext = strtolower($ext);
$destino = "../Fotos/" . $_POST["txtDni"] . "-" . $_POST["txtApellido"] . "." . $ext;

if(@getimagesize($_FILES["Foto"]["tmp_name"]))
{    
    //Verifico extensiones
    if($ext !== "jpg" && $ext !== "jpeg" && $ext !== "png" && $ext !== "gif" && $ext !== "bmp")
    {
        echo "Solo se permiten las extensiones: JPG, JPEG, PNG, GIF Y BMP.<br>";
        $alta = false;
    }
    //Verifico tamaño
    if ($_FILES["Foto"]["size"] > 1000000) {
        echo "La foto supera el tamaño permitido (1MB).<br>";
        $alta = false;
    }
    //VERIFICO QUE EL ARCHIVO NO EXISTA
    if($_POST["hdnModificar"] === "")
    {
        if (file_exists($destino))
        {
            echo "El archivo ya existe.<br>";
            $alta=false;
        }
    }    

}else{
    echo "Por favor seleccione una imagen.<br>";
    $alta = false;
}


/* **************************************************************************************** */

if($alta)
{
    $Empleado = new Empleado($_POST["txtNombre"],$_POST["txtApellido"],$_POST["txtDni"],$_POST["cboSexo"],$_POST["txtLegajo"],$_POST["txtSueldo"],$_POST["rdoTurno"]);

    $Empleado->SetPathFoto($destino);

    $MiFabrica = new Fabrica("Alpha S.A.", 7);

    @$MiFabrica->TraerDeArchivo("../Archivos/Empleados.txt");
    //var_dump($_POST);

    //echo $MiFabrica->ToString();    

    if($_POST["txtNombre"] != "" && $_POST["txtApellido"] != "" && $_POST["txtDni"] != "" && $_POST["cboSexo"] != "---" && $_POST["txtLegajo"] != "" && $_POST["txtSueldo"] != "")
    {
        if($_POST["hdnModificar"] !== "")
        {
            //$encontrado=False;
            $eliminado=false;
            foreach ($MiFabrica->GetEmpleados() as $value) 
            {
                //echo "Entor al foraech";
                if($value->GetDNI() == $Empleado->GetDNI())
                {                     

                    if(@$MiFabrica->EliminarEmpleado($value))
                    {
                        $MiFabrica->GuardarEnArchivo("Empleados.txt");
                        //echo "Empleado eliminado";
                        $eliminado=true;
                    }else{
                        echo "No se pudo eliminar";
                    }    
                           
                }
            }            

            if($eliminado)
            {
                $MiFabrica->AgregarEmpleado($Empleado);
                $MiFabrica->GuardarEnArchivo("Empleados.txt");
                move_uploaded_file($_FILES["Foto"]["tmp_name"],$destino);
                echo "<a href='Mostrar.php'>Empleado modificado, Mostrar.</a>";
            }
        }else if(@$MiFabrica->AgregarEmpleado($Empleado))
        {

            $MiFabrica->GuardarEnArchivo("Empleados.txt");
            move_uploaded_file($_FILES["Foto"]["tmp_name"],$destino);
            echo "<a href='Mostrar.php'>Empleado agragado, Mostrar.</a>";
        }else
        {
            echo "<a href='../index.php'>No se pudo agregar el empleado, volver.</a>";
        }

    }else
    {
        echo "<a href='../index.php'>Completar los datos correctamente, volver.</a>";        
    }  

}else{
    echo "<a href='../index.php'>Volver.</a>";
    
}
?>