<?php
session_start();
require_once "../Clases/Empleado.php";
require_once "../Clases/Fabrica.php";

if(isset($_SESSION["DNIEmpleado"]))
{
$Legajo = $_GET["Legajo"];
//echo $Legajo;
$Encontrado = false;
//$Empleado;
$ar = fopen("../Archivos/Empleados.txt", "r");
$linea="";

while(($linea = fgets($ar)) !== false)
{
    $linea = trim($linea);
    $empleadoArray = explode(" - ", $linea);
    if($empleadoArray[4] === $Legajo)
    {
        $Encontrado = true;
        $Empleado = new Empleado($empleadoArray[0], $empleadoArray[1], $empleadoArray[2], $empleadoArray[3],
        $empleadoArray[4], $empleadoArray[5], $empleadoArray[6]);
        $Empleado->SetPathFoto($empleadoArray[7]);
        break;
    }                   
}

if($Encontrado)
{
    $MiFabrica = new Fabrica("Alpha S.A.", 7);
    $MiFabrica->TraerDeArchivo("../Archivos/Empleados.txt");    

    if(@$MiFabrica->EliminarEmpleado($Empleado))
    {
        $MiFabrica->GuardarEnArchivo("Empleados.txt");
        echo "Empleado eliminado";
    }else{
        echo "No se pudo eliminar";
    }   
    
}else{
    echo "Empleado no encontrado";
}

echo "<br><a href='Mostrar.php'>Mostrar empleados</a>
<br><a href='../index.php'>Inicio</a>";}