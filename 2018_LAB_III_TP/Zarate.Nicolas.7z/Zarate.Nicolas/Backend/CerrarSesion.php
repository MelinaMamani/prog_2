<?php
session_start();

if(isset($_SESSION["DNIEmpleado"]))
{
    session_unset();
}
header('Location: ../Login.html');
?>