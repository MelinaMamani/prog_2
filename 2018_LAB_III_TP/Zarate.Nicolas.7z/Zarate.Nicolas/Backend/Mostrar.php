<?php
session_start();

$_SESSION["pathLogin"] = "../Login.html";

require_once("ValidarSesion.php");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML5-Listado de Empleados</title>
    <script src="../javascript/funciones.js"></script>
</head>
<body>
<form action="../index.php" method="POST" id="frmMostrar">
    <h2>Listado de Empleados</h2>

    <table align="center" >

        <th colspan="3" align="left">info</th>

        <tr>
            <td colspan ="3">
                <hr/>
            </td>
        </tr>

                <?php
                require_once "../clases/Persona.php";
                require_once "../clases/Empleado.php";
                require_once "../Clases/Fabrica.php";
                /**************Instacia Fabrica ************/
                $MiFabrica = new Fabrica("Alpha S.A.", 7);

                $MiFabrica->TraerDeArchivo("../Archivos/Empleados.txt");
                /*******************************************/
                $empleados = array();
                $empleados = $MiFabrica->GetEmpleados();
                /*******************************************/
                $linea="";
                foreach ($empleados as $value) {
                    $mostrarLinea = $value->GetDNI()." - ".$value->GetNombre()." - ".$value->GetApellido()." - ".$value->GetSexo()." - ".$value->GetLegajo()." - ".$value->GetSueldo()." - ".$value->GetTurno()." - ".$value->GetPathFoto();
                    
                    $legajo = $value->GetLegajo();

                    echo      "<tr>
                                        <td> $mostrarLinea </td>
                                        <td><img src=".$value->GetPathFoto()." height='90px' width='90px'></td>
                                        <td><a href='Eliminar.php?Legajo=$legajo'>Eliminar</a></td>
                                        <td><input type='button' name='btnModificar' id='btnModificar' value='Modificar' onclick='AdministrarModificar(".$value->GetDNI().")'></td>
                                </tr>";

                }  
                
                  
                ?>

        <tr>
            <td colspan ="3">
                <hr/>
            </td>
        </tr>


    </table>    
    <a href='../index.php'>Alta de Empleados.</a>
    <br>
    <a href='CerrarSesion.php'>Cerrar Sesion.</a>
    <input type="hidden" name="hdnMostrar" id="hdnMostrar">
</form>
</body>
</html>
