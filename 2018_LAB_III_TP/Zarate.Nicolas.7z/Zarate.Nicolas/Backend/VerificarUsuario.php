<?php
/*require_once "./Clases/Empleado.php";
require_once "./Clases/Fabrica.php";*/
session_start();

$alta = isset($_POST["btnEnviar"]) ? TRUE : FALSE;

if($alta)
{
    $ar = fopen("../Archivos/Empleados.txt", "r");
    $linea="";
    $encontrado = false;

    while(($linea = fgets($ar)) !== false)
    {
         $linea = trim($linea);
        $empleadoArray = explode(" - ", $linea);
        if($empleadoArray[1] == $_POST["txtApellido"] && $empleadoArray[2] == $_POST["txtDni"])
        {
            
            $encontrado = true;
            break;
        }           
    }

    if($encontrado)
    {
        $_SESSION["DNIEmpleado"] = $_POST["txtDni"];
        header('Location: Mostrar.php');
    }else{
        echo "<h2>Empleado no valido.</h2>
              <br><a href='../Login.html'>Login</a>";
    }

}
?>