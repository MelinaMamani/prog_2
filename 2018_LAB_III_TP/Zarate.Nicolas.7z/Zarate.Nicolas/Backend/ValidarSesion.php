<?php
//@session_start();
$pathlogin = $_SESSION["pathLogin"];

if(!isset($_SESSION["DNIEmpleado"]))
{
    header("Location: $pathlogin");
}

?>