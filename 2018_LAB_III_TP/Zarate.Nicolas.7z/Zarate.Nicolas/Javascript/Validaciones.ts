function AdministrarValidacionesLogin():boolean
{
    //validar apellido no vacio
    AdministrarSpanError("spnApellido",ValidarCamposVacios((<HTMLInputElement> document.getElementById("txtApellido")).value)); 
    
    //validar dni
    AdministrarSpanError("spnDni", ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtDni")).value),1000000,55000000));
    
    if(!VerificarValidacionesLogin())
    {
        alert("Validar");
        return false;
    }else
    {
        //alert("Paso");
        return true;
    }    
}

function AdministrarValidaciones():boolean
{
    let pasar:boolean = true;
    let errores:string = "";

    AdministrarSpanError("spnFoto", ValidarCamposVacios((<HTMLInputElement> document.getElementById("Foto")).value));

    AdministrarSpanError("spnDni", ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtDni")).value),1000000,55000000));

    AdministrarSpanError("spnApellido",ValidarCamposVacios((<HTMLInputElement> document.getElementById("txtApellido")).value));

    AdministrarSpanError("spnNombre",ValidarCamposVacios((<HTMLInputElement> document.getElementById("txtNombre")).value));

    AdministrarSpanError("spnSexo",ValidarCombo((<HTMLInputElement> document.getElementById("cboSexo")).value,"---"));

    AdministrarSpanError("spnLegajo",ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtLegajo")).value),100,550));

    AdministrarSpanError("spnSueldo",ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtSueldo")).value),8000,ObtenerSueldoMaximo(ObtenerTurnoSeleccionado())));

   
    
    if(!ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtDni")).value),1000000,55000000))
    {
        errores +="-Dni no valido\n";
        pasar=false;
    }

    if(!ValidarCamposVacios((<HTMLInputElement> document.getElementById("txtApellido")).value))
    {        
        errores +="-Apellido vacio\n";
        pasar=false;
    }

    if(!ValidarCamposVacios((<HTMLInputElement> document.getElementById("txtNombre")).value))
    {
        errores +="-Nombre vacio\n";
        pasar=false;
    }

    if(!ValidarCombo((<HTMLInputElement> document.getElementById("cboSexo")).value,"---"))
    {
        errores +="-Elija sexo\n";
        pasar=false;
    }

    if(!ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtLegajo")).value),100,550))
    {
        errores +="-Legajo no valido\n";
        pasar=false;
    }

    if(!ValidarRangoNumerico(parseInt((<HTMLInputElement> document.getElementById("txtSueldo")).value),8000,ObtenerSueldoMaximo(ObtenerTurnoSeleccionado())))
    {
        errores +="-Sueldo no valido\n";
        pasar=false;
    }

    if(!ValidarCamposVacios((<HTMLInputElement> document.getElementById("Foto")).value))
    {
        errores +="-Foto no valida\n";
        pasar=false;
    }

    if(errores != "")
    {
        alert(errores);
    }

    return pasar;
}

function VerificarValidacionesLogin():boolean
{
    if((<HTMLInputElement> document.getElementById("spnDni")).style.display == "block")
    {
        return false;
    }
    if((<HTMLInputElement> document.getElementById("spnApellido")).style.display == "block")
    {
        return false;
    }
    return true;
}

function AdministrarSpanError(id:string, ocultar:boolean):void
{
    if(ocultar)
    {
        (<HTMLInputElement> document.getElementById(id)).style.display="none";
    }else{
        (<HTMLInputElement> document.getElementById(id)).style.display="block";        
    }
}

function ValidarCamposVacios(campo:string):boolean
{
    if(campo != "")
    {
        return true;
    }
    return false;
}

function ValidarRangoNumerico(numero:number, min:number, max:number):boolean
{
    if(numero>=min && numero<=max)
    {
        return true;
    }
    return false;
}

function ValidarCombo(valor:string, novalor:string):boolean
{
    if(valor != novalor)
    {
        return true;
    }
    return false;
}

function ObtenerTurnoSeleccionado():string
{
    var Turno:string ="";
    if((<HTMLInputElement> document.getElementById("0")).checked){
     Turno = (<HTMLInputElement> document.getElementById("0")).value;
    }else if((<HTMLInputElement> document.getElementById("1")).checked){
     Turno = (<HTMLInputElement> document.getElementById("1")).value;
    }else if((<HTMLInputElement> document.getElementById("2")).checked){
     Turno = (<HTMLInputElement> document.getElementById("2")).value;
    }

    return Turno;
}

function ObtenerSueldoMaximo(turno:string):number
{
    var Sueldo:number = 0;
    if(turno == "Mañana")
    {
        Sueldo = 20000;
    }
    if(turno == "Tarde")
    {
        Sueldo = 18500;
    }
    if(turno == "Noche")
    {
        Sueldo = 25000;
    }
    return Sueldo;
}

function AsignarMaximo():void
{
    (<HTMLInputElement> document.getElementById("txtSueldo")).max =  ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()).toString();
}

function AdministrarModificar(DNI:string)
{
    //alert(DNI);
    (<HTMLInputElement>document.getElementById("hdnMostrar")).value=DNI;
    (<HTMLFormElement>document.getElementById("frmMostrar")).submit();
}