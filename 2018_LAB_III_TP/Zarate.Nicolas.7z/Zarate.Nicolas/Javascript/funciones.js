function AdministrarValidacionesLogin() {
    //validar apellido no vacio
    AdministrarSpanError("spnApellido", ValidarCamposVacios(document.getElementById("txtApellido").value));
    //validar dni
    AdministrarSpanError("spnDni", ValidarRangoNumerico(parseInt(document.getElementById("txtDni").value), 1000000, 55000000));
    if (!VerificarValidacionesLogin()) {
        alert("Validar");
        return false;
    }
    else {
        //alert("Paso");
        return true;
    }
}
function AdministrarValidaciones() {
    var pasar = true;
    var errores = "";
    AdministrarSpanError("spnFoto", ValidarCamposVacios(document.getElementById("Foto").value));
    AdministrarSpanError("spnDni", ValidarRangoNumerico(parseInt(document.getElementById("txtDni").value), 1000000, 55000000));
    AdministrarSpanError("spnApellido", ValidarCamposVacios(document.getElementById("txtApellido").value));
    AdministrarSpanError("spnNombre", ValidarCamposVacios(document.getElementById("txtNombre").value));
    AdministrarSpanError("spnSexo", ValidarCombo(document.getElementById("cboSexo").value, "---"));
    AdministrarSpanError("spnLegajo", ValidarRangoNumerico(parseInt(document.getElementById("txtLegajo").value), 100, 550));
    AdministrarSpanError("spnSueldo", ValidarRangoNumerico(parseInt(document.getElementById("txtSueldo").value), 8000, ObtenerSueldoMaximo(ObtenerTurnoSeleccionado())));
    if (!ValidarRangoNumerico(parseInt(document.getElementById("txtDni").value), 1000000, 55000000)) {
        errores += "-Dni no valido\n";
        pasar = false;
    }
    if (!ValidarCamposVacios(document.getElementById("txtApellido").value)) {
        errores += "-Apellido vacio\n";
        pasar = false;
    }
    if (!ValidarCamposVacios(document.getElementById("txtNombre").value)) {
        errores += "-Nombre vacio\n";
        pasar = false;
    }
    if (!ValidarCombo(document.getElementById("cboSexo").value, "---")) {
        errores += "-Elija sexo\n";
        pasar = false;
    }
    if (!ValidarRangoNumerico(parseInt(document.getElementById("txtLegajo").value), 100, 550)) {
        errores += "-Legajo no valido\n";
        pasar = false;
    }
    if (!ValidarRangoNumerico(parseInt(document.getElementById("txtSueldo").value), 8000, ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()))) {
        errores += "-Sueldo no valido\n";
        pasar = false;
    }
    if (!ValidarCamposVacios(document.getElementById("Foto").value)) {
        errores += "-Foto no valida\n";
        pasar = false;
    }
    if (errores != "") {
        alert(errores);
    }
    return pasar;
}
function VerificarValidacionesLogin() {
    if (document.getElementById("spnDni").style.display == "block") {
        return false;
    }
    if (document.getElementById("spnApellido").style.display == "block") {
        return false;
    }
    return true;
}
function AdministrarSpanError(id, ocultar) {
    if (ocultar) {
        document.getElementById(id).style.display = "none";
    }
    else {
        document.getElementById(id).style.display = "block";
    }
}
function ValidarCamposVacios(campo) {
    if (campo != "") {
        return true;
    }
    return false;
}
function ValidarRangoNumerico(numero, min, max) {
    if (numero >= min && numero <= max) {
        return true;
    }
    return false;
}
function ValidarCombo(valor, novalor) {
    if (valor != novalor) {
        return true;
    }
    return false;
}
function ObtenerTurnoSeleccionado() {
    var Turno = "";
    if (document.getElementById("0").checked) {
        Turno = document.getElementById("0").value;
    }
    else if (document.getElementById("1").checked) {
        Turno = document.getElementById("1").value;
    }
    else if (document.getElementById("2").checked) {
        Turno = document.getElementById("2").value;
    }
    return Turno;
}
function ObtenerSueldoMaximo(turno) {
    var Sueldo = 0;
    if (turno == "Mañana") {
        Sueldo = 20000;
    }
    if (turno == "Tarde") {
        Sueldo = 18500;
    }
    if (turno == "Noche") {
        Sueldo = 25000;
    }
    return Sueldo;
}
function AsignarMaximo() {
    document.getElementById("txtSueldo").max = ObtenerSueldoMaximo(ObtenerTurnoSeleccionado()).toString();
}
function AdministrarModificar(DNI) {
    //alert(DNI);
    document.getElementById("hdnMostrar").value = DNI;
    document.getElementById("frmMostrar").submit();
}
