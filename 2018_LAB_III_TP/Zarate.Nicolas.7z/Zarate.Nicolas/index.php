<?php
session_start();

$_SESSION["pathLogin"] = "Login.html";

require_once("./Backend/ValidarSesion.php");
include_once "./clases/Persona.php";
include_once "./clases/Empleado.php";
include_once "./Clases/Fabrica.php";
$linea = "";
$dni = isset($_POST["hdnMostrar"]) ? $_POST["hdnMostrar"] : NULL;
if($dni !== NULL)
{
    
    $MiFabrica = new Fabrica("Alpha S.A.", 7);
    @$MiFabrica->TraerDeArchivo("./Archivos/Empleados.txt");
    
    foreach ($MiFabrica->GetEmpleados() as $value) 
    {
        //echo "Entor al foraech";
        if($value->GetDNI() == $_POST["hdnMostrar"])
        {
            $linea = $value->ToString();
        }
    }
}
if($linea != "")
{
    $linea = trim($linea);
    $empleadoArray = explode(" - ", $linea);
    $E = new Empleado($empleadoArray[0], $empleadoArray[1], $empleadoArray[2], $empleadoArray[3],
    $empleadoArray[4], $empleadoArray[5], $empleadoArray[6]);
    $E->SetPathFoto($empleadoArray[7]);
    //echo $Empleado->ToString();
}
$SoloL="";
if($dni !== NULL)
{
    $SoloL = "readonly";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php echo $dni!==NULL ? "<title>HTML 5 - Formulario Modificar Empleado</title>" : "<title>HTML 5 - Formulario Alta Empleado</title>" ?>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <script src="./javascript/funciones.js"></script>
</head>
<body >

    <?php echo $dni!==NULL ? "<h2>Modificar Empleado</h2>" : "<h2>Alta de Empleados</h2>" ?>

    <form action="./Backend/Administracion.php" method="POST" enctype="multipart/form-data" onsubmit="return AdministrarValidaciones();">
        <table style="margin: 0 auto;">
            
            <th  colspan="2" align="left">
                <h4>Datos Personales</h4>
            </th>
            
            <tr>
                <td colspan="2">
                    <hr/>
                </td>
                
            </tr>
            <tr>
                <td >DNI:</td>
                <td style="padding-right:40px">
                    <input type="number" min="1000000" max="55000000" step="1" id="txtDni" name="txtDni" 
                    value="<?php echo $dni!==NULL ? $E->GetDNI() : '' ?>" <?php echo $SoloL; ?>><span id="spnDni" style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>Apellido:&nbsp;&nbsp;&nbsp;</td>
                <td>
                    <input type="text"  id="txtApellido" name="txtApellido" value="<?php echo $dni!==NULL ? $E->GetApellido() : '' ?>"><span id="spnApellido" style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>Nombre:</td>
                <td>
                    <input type="text" id="txtNombre" name="txtNombre" value="<?php echo $dni!==NULL ? $E->GetNombre() : '' ?>"><span id="spnNombre" style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>Sexo:</td>
                <td>
                    <select  id="cboSexo" name="cboSexo">
                        <?php
                        if($dni !== NULL)
                        {
                            if($E->getSexo() == "M")
                            {
                                echo "<option value='---'>Seleccione</option>
                                <option value='M' selected>Masculino</option>
                                <option value='F'>Femenino</option>";
                            }else{
                                echo "<option value='---'>Seleccione</option>
                                <option value='M'>Masculino</option>
                                <option value='F' selected>Femenino</option>";
                            }
                        }else
                        {
                            echo "<option value='---' selected>Seleccione</option>
                            <option value='M'>Masculino</option>
                            <option value='F'>Femenino</option>";
                        }
                        ?>                        
                    </select><span id="spnSexo" style="display:none">*</span>
                </td>
            </tr>
            <th  colspan="2" align="left">
                    <h4>Datos Laborales</h4>
            </th>
            <tr>
                    <td colspan="2"><hr/></td>
                    
            </tr>
            <tr>
                <td>Legajo:</td>
                <td>
                    <input type="number" min="100" max="550" step="1" id="txtLegajo" name="txtLegajo" size="5" 
                    value="<?php echo $dni!==NULL ? $E->GetLegajo() : '' ?>" <?php echo $SoloL; ?>><span id="spnLegajo" style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td>Sueldo:</td>
                <td>
                    <input type="number" min="8000" step="500" id="txtSueldo" name="txtSueldo" style="width:100%" oninput="AsignarMaximo()"
                    value="<?php echo $dni!==NULL ? $E->GetSueldo() : '' ?>"><span id="spnSueldo" style="display:none">*</span>
                </td>
            </tr>
            <tr>
                <td colspan="2">Turno:</td>
            </tr>
            <?php
            if($dni!==Null)
            {
                $M="";
                $T="";
                $N="";
                if($E->GetTurno() == "Mañana"){$M="checked";}
                else if($E->GetTurno() == "Tarde"){$T="checked";}
                else{$N="checked";}
                echo "<tr>
                <td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='0' value='Mañana' $M>Mañana</td>                
                </tr>
                <tr>
                <td td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='1' value='Tarde' $T>Tarde</td>
                </tr>
                <tr>
                <td td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='2' value='Noche' $N>Noche</td>
                </tr>";
            }else
            {
                echo "<tr>
                <td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='0' value='Mañana' checked>Mañana</td>                
                </tr>
                <tr>
                <td td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='1' value='Tarde'>Tarde</td>
                </tr>
                <tr>
                <td td colspan='2' style='text-align:left;padding-left:40px'>
                <input type='radio' name='rdoTurno' id='2' value='Noche'>Noche</td>
                </tr>";
            }
            ?>            
            <tr>
                <td>Foto:</td>
                <td><input type="file" name="Foto" id="Foto"><span id="spnFoto" style="display:none">*</span></td>
            </tr>
            <tr>
                <td colspan="2"><hr/></td>
            </tr>
            <tr>
                <td colspan="2" align="right"><input type="reset" name="btnLimpiar" id="btnLimpiar" value="Limpiar"></td>
            </tr>
            <tr>
                <td colspan="2" align="right"><input type="submit" name="btnEnviar" id="btnEnviar" 
                value="<?php echo $dni!==NULL ? "Modificar" : "Enviar" ?>"></td>
            </tr>
        </table> 
        <input type="hidden" name="hdnModificar" id="hdnModificar" 
        value="<?php echo $dni!==NULL ? $E->GetDNI() : '' ?>">       
    </form>
    <a href='./Backend/CerrarSesion.php'>Cerrar Sesion.</a>
</body>
</html>