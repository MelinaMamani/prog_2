<?php

require_once "Persona.php";
require_once "Empleado.php";
require_once "Interfaces.php";

class Fabrica{

    private $_razonSocial;
    private $_cantidadMaxima;
    private $_empleados;

    public function __construct($razonSocial, $cantidadMaxima = 5, $empleados = array())
    {
        $this->_razonSocial = $razonSocial;
        $this->_cantidadMaxima = $cantidadMaxima;
        $this->_empleados = $empleados;
    }

    public function GetEmpleados()
    {
        return $this->_empleados;
    }

    public function AgregarEmpleado($empleado)
    {
        $retorno = false;

        $espacioArrayInicial = (count($this->_empleados));

        if($empleado != null &&  ($espacioArrayInicial < $this->_cantidadMaxima) )
        {
            array_push($this->_empleados, $empleado);

            $espacioArrayFinal = count($this->_empleados);

            //Elimino duplicados.

            $this->EliminarEmpleadoRepetido();

            //if($espacioArrayFinal > $espacioArrayInicial)
            //{
                $retorno = true;
            //}
        }
        
        return $retorno;
    }

    public function CalcularSueldos()
    {
        $sueldos = 0;

        foreach($this->_empleados as $empleado)
        {
            $sueldos += $empleado->GetSueldo();
        }

        return $sueldos;
    }

    public function EliminarEmpleado($empleado)
    {
        $retorno = false;

        foreach($this->_empleados as $e)
        {
            $indice = array_search($empleado, $this->_empleados);

            if($empleado->GetLegajo() == $e->GetLegajo())
            {
                unset($this->_empleados[$indice]);

                $retorno = true;
            }
        }

        return $retorno;

    }

    private function EliminarEmpleadoRepetido()
    {
        $this->_empleados = array_unique($this->_empleados, SORT_REGULAR);
    }
    
    public function ToString()
    {
        return $this->_razonSocial . "-" . $this->_cantidadMaxima . "-" . $this->CalcularSueldos() . "-" . var_dump($this->_empleados);
    }

    public function GuardarEnArchivo($nombreArchivo)
    {
        $retornador = false;

        if($archivo = fopen($nombreArchivo, "w"))
        {
            $cadena = "";

            foreach($this->_empleados as $empleado)
            {
                $cadena .= $empleado->ToString() . "\r\n";
            }

            if(fwrite($archivo, $cadena))
            {
                $retornador = true;
            }
        }

        fclose($archivo);

        return $retornador;
    }

    public function TraerDeArchivo($nombreArchivo)
    {

        if($plectura = fopen($nombreArchivo, "r"))
        {
            while(!feof($plectura))
            {
                $stringEmpleado = fgets($plectura);
                $stringEmpleado = trim($stringEmpleado);
                $auxEmpleado = explode("-", $stringEmpleado);
    
                //En 0 el nombre, en 1 el apellido.
    
                if(trim($auxEmpleado[0]) != "" && trim($auxEmpleado[1]) != "" && trim($auxEmpleado[2]) != "" && trim($auxEmpleado[3]) != "" && trim($auxEmpleado[4]) != "" && trim($auxEmpleado[5]) != "" && trim($auxEmpleado[6]) != "")
                {
                    //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)
                    $pathFoto = $auxEmpleado[7] . "-" . $auxEmpleado[8];
                    $empleado = new Empleado($auxEmpleado[0], $auxEmpleado[1], $auxEmpleado[2], $auxEmpleado[3], $auxEmpleado[4], $auxEmpleado[5], $auxEmpleado[6]);
                    $empleado->SetPathFoto($pathFoto);
                    $this->AgregarEmpleado($empleado);
                }
            }
        }
    
        fclose($plectura);
    }
}

?>