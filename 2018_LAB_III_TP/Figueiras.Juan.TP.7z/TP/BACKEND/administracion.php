<?php
    require_once "Persona.php";
    require_once "Empleado.php";
    require_once "Fabrica.php";

    $dni = $_POST["txtDni"];
    $apellido = $_POST["txtApellido"];
    $nombre = $_POST["txtNombre"];
    $legajo = $_POST["txtLegajo"];
    $sueldo = $_POST["txtSueldo"];

    if(isset($_POST["maniana"])) 
    $turno = "m";
    if(isset($_POST["tarde"]))
    $turno = "t";
    if(isset($_POST["noche"]))
    $turno = "n";

    //$turno = $_POST["turno"];
    $sexo = $_POST["cboSexo"];
    
    $foto = $_FILES["foto"];

    $target_dir = "../Fotos/";

    $imageFileType = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));

    $target_file = $target_dir . $dni . "-" . $apellido . "." . $imageFileType;//basename($_FILES["foto"]["name"])

    //Creo la fabrica
    $Fabrica = new Fabrica("U.T.N", 7);

    //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)

    //Creo el empleado.
    //$Empleado = new Empleado("Juan", "Figueiras", 41170819, "M", 49, 17000, "Noche");
    $Empleado = new Empleado($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno);

    $Fabrica->TraerDeArchivo("Empleados.txt");

    if(isset($_POST["hdnModificar"]))
    {
        foreach($Fabrica->GetEmpleados() as $emp)
        {
            if($emp->GetDni() == $_POST["hdnModificar"])
            {
                $Fabrica->EliminarEmpleado($emp);
                break;
            }
        }
    }

    if($Fabrica->AgregarEmpleado($Empleado) && move_uploaded_file($_FILES['foto']['tmp_name'], $target_file))
    {
        $Empleado->SetPathFoto("../Fotos/" . $dni . "-" . $apellido . "." . $imageFileType);
        $Fabrica->GuardarEnArchivo("Empleados.txt");
        echo "<a href='mostrar.php'><- MOSTRAR -></a>";
    }
    else
    {
        //echo $Fabrica->AgregarEmpleado($Empleado);
        //echo $target_file;
        //echo move_uploaded_file($_FILES['foto']['tmp_name'], $target_file);
        echo "Error<br>";
        echo "<a href='./FRONTEND/index.php'><- INDEX -></a>";
    }
    
?>