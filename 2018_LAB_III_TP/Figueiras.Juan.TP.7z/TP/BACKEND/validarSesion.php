<?php
        session_start();

        if(!($_SESSION["DNIEmpleado"]))
        header('Location: ../FRONTEND/login.html');
?>