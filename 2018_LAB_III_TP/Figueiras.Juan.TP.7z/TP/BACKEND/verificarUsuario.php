<?php

    session_start();
    $dni = $_POST["txtDni"];
    $apellido = $_POST["txtApellido"];

    require_once "Persona.php";
    require_once "Empleado.php";
    require_once "Fabrica.php";

    $flag = false;

    if($plectura = fopen("Empleados.txt", "r"))
    {
        while(!feof($plectura))
        {
            $stringEmpleado = fgets($plectura);
            $stringEmpleado = trim($stringEmpleado);
            $auxEmpleado = explode("-", $stringEmpleado);

            //En 0 el nombre, en 1 el apellido.

            if(trim($auxEmpleado[0]) != "" && trim($auxEmpleado[1]) != "" && trim($auxEmpleado[2]) != "" && trim($auxEmpleado[3]) != "" && trim($auxEmpleado[4]) != "" && trim($auxEmpleado[5]) != "" && trim($auxEmpleado[6]) != "")
            {
                //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)
                $empleado = new Empleado($auxEmpleado[0], $auxEmpleado[1], $auxEmpleado[2], $auxEmpleado[3], $auxEmpleado[4], $auxEmpleado[5], $auxEmpleado[6]);
                
                if($auxEmpleado[1] == $apellido && $auxEmpleado[2] == $dni)
                {
                    $flag = true;
                    $_SESSION["DNIEmpleado"] = $dni;
                    header('Location: ../BACKEND/mostrar.php');
                }
            }
        }
    }

    fclose($plectura);

    if(!$flag)
    {
        session_unset();
        echo "Error no se encontró el usuario<br>";
        echo "<a href='../FRONTEND/login.html'>LOGIN</a>";
    }
?>