<?php       
    require_once("../BACKEND/validarSesion.php");     


    require_once "Persona.php";
    require_once "Empleado.php";
    require_once "Fabrica.php";

    $html ='<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Mostrar</title>
        <script src="../FRONTEND/validaciones.js"></script>
    </head></html>';
    $html .= "<tr>
    <th><h2>Listado de Empleados</h2>
    </th>
    </tr>
    <tr>
    <td><hr size='2px' color='black' width=230 align='left'/>
    <h4>Info</h4>
    </td>
    </tr><hr size='2px' color='black' width=500 align='left'/><table border=1><tr><th>Nombre</th><th>Apellido</th>
    <th>DNI</th><th>Sexo</th><th>Legajo</th><th>Sueldo</th><th>Turno</th><th>Path</th><th>Foto</th><th>Acción</th></tr>";

    $arrayEmpleados = array();

    if($plectura = fopen("Empleados.txt", "r+"))
    {
        while(!feof($plectura))
        {
            $stringEmpleado = fgets($plectura);
            $auxEmpleado = explode("-", $stringEmpleado);

            //En 0 el nombre, en 1 el apellido.

            if(trim($auxEmpleado[0]) != "" && trim($auxEmpleado[1]) != "" && trim($auxEmpleado[2]) != "" && trim($auxEmpleado[3]) != "" && trim($auxEmpleado[4]) != "" && trim($auxEmpleado[5]) != "" && trim($auxEmpleado[6]) != "" && trim($auxEmpleado[7]) != "")
            {
                //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)
                $empleado = new Empleado($auxEmpleado[0], $auxEmpleado[1], $auxEmpleado[2], $auxEmpleado[3], $auxEmpleado[4], $auxEmpleado[5], $auxEmpleado[6]);
                array_push($arrayEmpleados, $empleado);

                $html .= "<tr>";
                for($i = 0; $i <= 6; $i++)
                $html .= "<td>". $auxEmpleado[$i] . "</td>";
                $html .= "<td>". $auxEmpleado[7] . "-" . $auxEmpleado[8] . "</td>";
                $html .= '<td> <img src="../Fotos/'. $auxEmpleado[7] . "-" . $auxEmpleado[8].'"width="90" height="90"></td>';
                $html .= "<td> <a href='../BACKEND/eliminar.php?legajo=" . $empleado->GetLegajo() ."'><- ELIMINAR -></a> </td>";
                $html .= '<td><input type="button" name="btnModificar" value="Modificar" onclick="Entidades.Validaciones.AdministrarModificar(' . $empleado->GetDni() .')"></td>';
                $html .= "</tr>";
                
            }
        }
    }

    $html .= "</table><hr size='2px' color='black' width=500 align='left'/>";

    echo $html . "<br><a href='../FRONTEND/index.php'><- INDEX -></a><br>";

    fclose($plectura);

    echo '<form id="formMOD" action="../FRONTEND/index.php" method="POST">
    <input type="hidden" name="hdnModificar" id="hdnModificar">
    </form>';
    echo '<a href = "../BACKEND/cerrarSesion.php">Cerrar sesión</a>';


    /*foreach($arrayEmpleados as $empleado)
    {
        $html .= $empleado->ToString();
    }*/
?>