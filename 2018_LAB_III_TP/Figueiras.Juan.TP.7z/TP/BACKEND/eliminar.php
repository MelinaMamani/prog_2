<?php

    $legajo = $_GET["legajo"];

    require_once "Persona.php";
    require_once "Empleado.php";
    require_once "Fabrica.php";

     //Creo la fabrica
     $Fabrica = new Fabrica("U.T.N", 7);

     if($plectura = fopen("Empleados.txt", "r"))
     {
        $Fabrica->TraerDeArchivo("Empleados.txt");

         while(!feof($plectura))
         {
             $stringEmpleado = fgets($plectura);
             $stringEmpleado = trim($stringEmpleado);
             $auxEmpleado = explode("-", $stringEmpleado);
 
             //En 0 el nombre, en 1 el apellido.
 
             if(trim($auxEmpleado[0]) != "" && trim($auxEmpleado[1]) != "" && trim($auxEmpleado[2]) != "" && trim($auxEmpleado[3]) != "" && trim($auxEmpleado[4]) != "" && trim($auxEmpleado[5]) != "" && trim($auxEmpleado[6]) != "" && trim($auxEmpleado[7]) != "" && trim($auxEmpleado[8]) != "")
             {
                 //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)
                 $empleado = new Empleado($auxEmpleado[0], $auxEmpleado[1], $auxEmpleado[2], $auxEmpleado[3], $auxEmpleado[4], $auxEmpleado[5], $auxEmpleado[6]);
                 $empleado->setPathFoto($auxEmpleado[7] . "-" . $auxEmpleado[8]);
                 
                 if($legajo == $auxEmpleado[4])
                 {
                    echo"Empleado encontrado<br>";

                    if($Fabrica->EliminarEmpleado($empleado) && $Fabrica->GuardarEnArchivo("Empleados.txt") && unlink($empleado->GetPathFoto()))
                    {
                        echo "Empleado eliminado correctamente!<br>";
                        break;
                    }
                    else
                    {
                        echo "El empleado no se ha podido eliminar<br>";
                    }
                 }
             }
         }
     }
 
     fclose($plectura);

     echo"<br><a href='mostrar.php'>Mostrar</a><br>";
     echo"<a href='../FRONTEND/index.php'>Index</a>";
     
?>