<?php

    require_once "Persona.php";
    require_once "Empleado.php";
    require_once "Fabrica.php";

    //($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)

    //Creo el empleado.
    $Empleado = new Empleado("Juan", "Figueiras", 41170819, "M", 49, 17000, "Noche");

    //Creo otro empleado.
    $Empleado2 = new Empleado("Carlos", "Martinez", 30568741, "M", 50, 11000, "Mañana");

    //Creo la fabrica.
    $Fabrica = new Fabrica("UTN S.A", 10);

    echo $Fabrica->AgregarEmpleado($Empleado);
    $Fabrica->AgregarEmpleado($Empleado);
    $Fabrica->AgregarEmpleado($Empleado2);

    echo $Fabrica->ToString();

    //echo $Empleado->ToString();
?>