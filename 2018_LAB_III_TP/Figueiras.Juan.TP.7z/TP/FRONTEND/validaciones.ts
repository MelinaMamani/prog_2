
namespace Entidades{

    export class Validaciones{

        //Llama a todas las funciones.
        public static AdministrarValidaciones() : void
        {
            //Inputs
            var dni : string = (<HTMLInputElement>document.getElementById("txtDni")).value;
            var apellido : string = (<HTMLInputElement>document.getElementById("txtApellido")).value;
            var nombre : string = (<HTMLInputElement>document.getElementById("txtNombre")).value;
            var legajo : string = (<HTMLInputElement>document.getElementById("txtLegajo")).value;
            var sueldo : string = (<HTMLInputElement>document.getElementById("txtSueldo")).value;
            var foto : string = (<HTMLInputElement>document.getElementById("foto")).value;

            //Combo box
            var sexo : string = (<HTMLSelectElement>document.getElementById("cboSexo")).value;

            //Array inputs
            var array_inputs : string[] = [dni, apellido, nombre, legajo, sueldo, sexo, foto];

            //Array combo box
            //var array_cbo : string[] = [sexo];

            var turno : string = Validaciones.ObtenerTurnoSeleccionado();

            //Array radio
            //var array_radio : boolean[] = [maniana, tarde, noche];

            //Validacion de todos los inputs.
            var camposVacios : boolean[] = [false, false, false, false, false, false, false];
            //dni, legajo, sueldo
            var rangoNumerico : boolean[] = [false, false, false];

            for(let i : number = 0; i< array_inputs.length; i++)
            {
                if(i == 5 && !(Validaciones.ValidarCombo(array_inputs[i], "")))
                {
                    camposVacios[i] = true;
                }
                else if(!Validaciones.ValidarCamposVacios(array_inputs[i]))
                {
                    camposVacios[i] = true;
                }

                if((!camposVacios[i]) && i != 5)
                {
                switch(i)
                {
                    case 0:
                    //Verifico DNI
                    rangoNumerico[0] = Validaciones.ValidarRangoNumerico(+array_inputs[0], 1000000, 55000000);
                    break;
                    case 3:
                    //Verifico legajo
                    rangoNumerico[1] = Validaciones.ValidarRangoNumerico(+array_inputs[3], 100, 550);
                    break;
                    case 4:
                    //Verifico sueldo
                    //Si el rango es valido verifico que no sea mayor al maximo del turno asignado
                    if(Validaciones.ValidarRangoNumerico(+array_inputs[4], 8000, 25000))
                    {
                        //alert(Validaciones.ObtenerTurnoSeleccionado());
                        //alert(Validaciones.ObtenerSueldoMaximo(turno.toString()));

                            //Donde esta el sueldo
                        if(+array_inputs[4] > Validaciones.ObtenerSueldoMaximo(turno))
                        {
                            rangoNumerico[2] = false;
                        }
                        else
                        rangoNumerico[2] = true;
                    }
                    break;
                }
                }
            }

            var salioBien : number = 0;
            
            for(let i : number = 0; i< camposVacios.length; i++)
            {
                if(camposVacios[i])
                {
                    salioBien++;
                    switch(i)
                    {
                        case 0:
                        Validaciones.AdministarSpanError("spanDNI", false);
                        break;
                        case 1:
                        Validaciones.AdministarSpanError("spanAp", false);
                        break;
                        case 2:
                        Validaciones.AdministarSpanError("spanNom", false);
                        break;
                        case 3:
                        Validaciones.AdministarSpanError("spanLeg", false);
                        break;
                        case 4:
                        Validaciones.AdministarSpanError("spanSuel", false);
                        break;
                        case 5:
                        Validaciones.AdministarSpanError("spanSexo", false);
                        break;
                        case 6:
                        Validaciones.AdministarSpanError("spanFoto", false);
                        break;
                    }
                }
                else
                {
                    switch(i)
                    {
                        case 0:
                        Validaciones.AdministarSpanError("spanDNI", true);
                        break;
                        case 1:
                        Validaciones.AdministarSpanError("spanAp", true);
                        break;
                        case 2:
                        Validaciones.AdministarSpanError("spanNom", true);
                        break;
                        case 3:
                        Validaciones.AdministarSpanError("spanLeg", true);
                        break;
                        case 4:
                        Validaciones.AdministarSpanError("spanSuel", true);
                        break;
                        case 5:
                        Validaciones.AdministarSpanError("spanSexo", true);
                        break;
                        case 6:
                        Validaciones.AdministarSpanError("spanFoto", true);
                        break;
                    }

                    for(let j : number = 0; j< rangoNumerico.length; j++)
                    {
                        if(!rangoNumerico[j])
                        {
                            salioBien++;
                            switch(j)
                            {
                                case 0:
                                Validaciones.AdministarSpanError("spanDNI", false);
                                break;
                                case 1:
                                Validaciones.AdministarSpanError("spanLeg", false);
                                break;
                                case 2:
                                Validaciones.AdministarSpanError("spanSuel", false);
                                break;
                            }
                        }
                        else
                        {
                            switch(j)
                            {
                                case 0:
                                Validaciones.AdministarSpanError("spanDNI", true);
                                break;
                                case 1:
                                Validaciones.AdministarSpanError("spanLeg", true);
                                break;
                                case 2:
                                Validaciones.AdministarSpanError("spanSuel", true);
                                break;
                            }
                        }
                    }
                }

            }

            /*if(campoVacio)
            {
                alert("Error, campo vacío");
                salioBien++;
            }
            else if(!(rangoNumerico[0] && rangoNumerico[1] && rangoNumerico[2]))
            {
                alert("Error, un rango es inválido");
                salioBien++;
            }
            if(!(Validaciones.ValidarCombo(sexo, "")))
            {
                alert("Error, elija un sexo correcto");
                salioBien++;
            }*/

            //console.log(salioBien);
            if(salioBien == 0)
            {
                let xhttp : XMLHttpRequest = new XMLHttpRequest();

                //METODO; URL; ASINCRONICO?
                xhttp.open("POST", "../BACKEND/administracion.php", true);

                //SETEO EL ENCABEZADO DE LA PETICION	
                //xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");

                var form = document.getElementById("Formulario");
                var data = new FormData(<HTMLFormElement>form);

                //ENVIO DE LA PETICION CON LOS PARAMETROS
                xhttp.send(data);

                //FUNCION CALLBACK
                xhttp.onreadystatechange = () => 
                {
                    if(xhttp.readyState == 4 && xhttp.status == 200) 
                    {
                        if(xhttp.responseText)
                        {
                            //alert(xhttp.responseText);
                            (<HTMLDivElement>document.getElementById("div")).innerHTML ="<a href='../BACKEND/mostrar.php'><- MOSTRAR -></a>";
                        }
                        else
                        {
                            alert("Error");
                        }
                    }
                };

            }
        }

        //Campos no vacíos.
        public static ValidarCamposVacios(string : string) : boolean
        {
            let retornador : boolean = true;

            if(string == "")
            retornador = false;

            return retornador;
        }

        //Rangos numéros correctos.
        public static ValidarRangoNumerico(num : number, min : number, max : number) : boolean
        {
            let retornador : boolean = false;

            if(num >= min && num <= max)
            retornador = true;

            return retornador;
        }

        //Selección del sexo.
        public static ValidarCombo(id : string, nodebecontener : string) : boolean
        {
            let retornador : boolean = false;

            if(id != nodebecontener)
            retornador = true;

            return retornador;
        }

        //Verificación del turno y sueldo máximo.
        public static ObtenerTurnoSeleccionado() : string
        {
            var retornador : string = "";

            //Type=radio
            let maniana : boolean = (<HTMLInputElement>document.getElementById("maniana")).checked;
            let tarde : boolean = (<HTMLInputElement>document.getElementById("tarde")).checked;
            let noche : boolean = (<HTMLInputElement>document.getElementById("noche")).checked

            if(maniana)
                retornador = "m";
            if(tarde)
                retornador = "t";
            if(noche)
                retornador = "n";

            return retornador;
        }

        public static ObtenerSueldoMaximo(turno : string) : number
        {
            let retornador : number = 0;

            switch(turno)
            {
                case 'm':
                retornador = 20000;
                break;
                case 't':
                retornador = 18500;
                break;
                case 'n':
                retornador = 24000;
                break;
            }

            return retornador;
        }

        public static AdministrarValidacionesLogin()
        {
            //Inputs
            var dni : string = (<HTMLInputElement>document.getElementById("txtDni")).value;
            var apellido : string = (<HTMLInputElement>document.getElementById("txtApellido")).value;

            var salioBien : number = 0;

            if(!(Validaciones.ValidarCamposVacios(apellido)))
            {
                Validaciones.AdministarSpanError("spanAp", false);
                salioBien++;
            }
            else
            Validaciones.AdministarSpanError("spanAp", true);

            if((!Validaciones.ValidarCamposVacios(dni) || (!Validaciones.ValidarRangoNumerico(+dni, 1000000, 55000000))))
            {
                Validaciones.AdministarSpanError("spanDNI", false);
                salioBien++;
            }
            else
            Validaciones.AdministarSpanError("spanDNI", true);

            if(salioBien == 0 && Validaciones.VerificarValidacionesLogin())
            {
                return true;
            }
        }
        
        public static AdministarSpanError(id : string, esconder : boolean)
        {
            if(!esconder)
            (<HTMLSpanElement>document.getElementById(id)).style.display='block';
            else
            (<HTMLSpanElement>document.getElementById(id)).style.display='none';
        }

        public static VerificarValidacionesLogin() : boolean
        {
            var retornador : boolean = true;

            var elementos = document.getElementsByTagName('span');

            for (let i = 0; i < elementos.length; i++) 
            {
                 if(elementos[i].style.display == 'block')
                 {
                     //Con que uno este block ya retorno falso.
                    retornador = false;
                    break;
                 }
            }

            return retornador;
        }

        public static AdministrarModificar(dni : string) {

            var formulario = <HTMLFormElement>document.getElementById("formMOD");

            (<HTMLInputElement>document.getElementById("hdnModificar")).value = dni;

            formulario.submit();
        }

        /*public static Modificar(dni : string, apellido : string, nombre : string, sexo : string, legajo : string, sueldo : string, turno : string, foto : string)
        {
            (<HTMLInputElement>document.getElementById("txtDni")).value = dni;
            (<HTMLInputElement>document.getElementById("txtDni")).readOnly = true;

            (<HTMLInputElement>document.getElementById("txtApellido")).value = apellido;
            (<HTMLInputElement>document.getElementById("txtNombre")).value = nombre;

            if(sexo == 'm')
            {
                (<HTMLSelectElement>document.getElementById("cboSexo")).selectedIndex = 1;
            }
            else if(sexo == 'f')
            {
                (<HTMLSelectElement>document.getElementById("cboSexo")).selectedIndex = 2;
            }

            (<HTMLInputElement>document.getElementById("txtLegajo")).value = legajo;
            (<HTMLInputElement>document.getElementById("txtLegajo")).readOnly = true;

            (<HTMLInputElement>document.getElementById("txtSueldo")).value = sueldo;

            (<HTMLInputElement>document.getElementById("hdnModificar")).value = dni;

            var t : string = "";

            switch (turno) 
            {
                case "m":
                    t = "maniana";
                    break;
                case "t":
                    t = "tarde";
                    break;
                case "n":
                    t = "noche";
                    break;
            }

            (<HTMLInputElement>document.getElementById(t)).checked = true;

            (<HTMLInputElement>document.getElementById("foto")).value = foto;
        }*/
    }
}