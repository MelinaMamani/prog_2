var Entidades;
(function (Entidades) {
    var Validaciones = /** @class */ (function () {
        function Validaciones() {
        }
        //Llama a todas las funciones.
        Validaciones.AdministrarValidaciones = function () {
            //Inputs
            var dni = document.getElementById("txtDni").value;
            var apellido = document.getElementById("txtApellido").value;
            var nombre = document.getElementById("txtNombre").value;
            var legajo = document.getElementById("txtLegajo").value;
            var sueldo = document.getElementById("txtSueldo").value;
            var foto = document.getElementById("foto").value;
            //Combo box
            var sexo = document.getElementById("cboSexo").value;
            //Array inputs
            var array_inputs = [dni, apellido, nombre, legajo, sueldo, sexo, foto];
            //Array combo box
            //var array_cbo : string[] = [sexo];
            var turno = Validaciones.ObtenerTurnoSeleccionado();
            //Array radio
            //var array_radio : boolean[] = [maniana, tarde, noche];
            //Validacion de todos los inputs.
            var camposVacios = [false, false, false, false, false, false, false];
            //dni, legajo, sueldo
            var rangoNumerico = [false, false, false];
            for (var i = 0; i < array_inputs.length; i++) {
                if (i == 5 && !(Validaciones.ValidarCombo(array_inputs[i], ""))) {
                    camposVacios[i] = true;
                }
                else if (!Validaciones.ValidarCamposVacios(array_inputs[i])) {
                    camposVacios[i] = true;
                }
                if ((!camposVacios[i]) && i != 5) {
                    switch (i) {
                        case 0:
                            //Verifico DNI
                            rangoNumerico[0] = Validaciones.ValidarRangoNumerico(+array_inputs[0], 1000000, 55000000);
                            break;
                        case 3:
                            //Verifico legajo
                            rangoNumerico[1] = Validaciones.ValidarRangoNumerico(+array_inputs[3], 100, 550);
                            break;
                        case 4:
                            //Verifico sueldo
                            //Si el rango es valido verifico que no sea mayor al maximo del turno asignado
                            if (Validaciones.ValidarRangoNumerico(+array_inputs[4], 8000, 25000)) {
                                //alert(Validaciones.ObtenerTurnoSeleccionado());
                                //alert(Validaciones.ObtenerSueldoMaximo(turno.toString()));
                                //Donde esta el sueldo
                                if (+array_inputs[4] > Validaciones.ObtenerSueldoMaximo(turno)) {
                                    rangoNumerico[2] = false;
                                }
                                else
                                    rangoNumerico[2] = true;
                            }
                            break;
                    }
                }
            }
            var salioBien = 0;
            for (var i = 0; i < camposVacios.length; i++) {
                if (camposVacios[i]) {
                    salioBien++;
                    switch (i) {
                        case 0:
                            Validaciones.AdministarSpanError("spanDNI", false);
                            break;
                        case 1:
                            Validaciones.AdministarSpanError("spanAp", false);
                            break;
                        case 2:
                            Validaciones.AdministarSpanError("spanNom", false);
                            break;
                        case 3:
                            Validaciones.AdministarSpanError("spanLeg", false);
                            break;
                        case 4:
                            Validaciones.AdministarSpanError("spanSuel", false);
                            break;
                        case 5:
                            Validaciones.AdministarSpanError("spanSexo", false);
                            break;
                        case 6:
                            Validaciones.AdministarSpanError("spanFoto", false);
                            break;
                    }
                }
                else {
                    switch (i) {
                        case 0:
                            Validaciones.AdministarSpanError("spanDNI", true);
                            break;
                        case 1:
                            Validaciones.AdministarSpanError("spanAp", true);
                            break;
                        case 2:
                            Validaciones.AdministarSpanError("spanNom", true);
                            break;
                        case 3:
                            Validaciones.AdministarSpanError("spanLeg", true);
                            break;
                        case 4:
                            Validaciones.AdministarSpanError("spanSuel", true);
                            break;
                        case 5:
                            Validaciones.AdministarSpanError("spanSexo", true);
                            break;
                        case 6:
                            Validaciones.AdministarSpanError("spanFoto", true);
                            break;
                    }
                    for (var j = 0; j < rangoNumerico.length; j++) {
                        if (!rangoNumerico[j]) {
                            salioBien++;
                            switch (j) {
                                case 0:
                                    Validaciones.AdministarSpanError("spanDNI", false);
                                    break;
                                case 1:
                                    Validaciones.AdministarSpanError("spanLeg", false);
                                    break;
                                case 2:
                                    Validaciones.AdministarSpanError("spanSuel", false);
                                    break;
                            }
                        }
                        else {
                            switch (j) {
                                case 0:
                                    Validaciones.AdministarSpanError("spanDNI", true);
                                    break;
                                case 1:
                                    Validaciones.AdministarSpanError("spanLeg", true);
                                    break;
                                case 2:
                                    Validaciones.AdministarSpanError("spanSuel", true);
                                    break;
                            }
                        }
                    }
                }
            }
            /*if(campoVacio)
            {
                alert("Error, campo vacío");
                salioBien++;
            }
            else if(!(rangoNumerico[0] && rangoNumerico[1] && rangoNumerico[2]))
            {
                alert("Error, un rango es inválido");
                salioBien++;
            }
            if(!(Validaciones.ValidarCombo(sexo, "")))
            {
                alert("Error, elija un sexo correcto");
                salioBien++;
            }*/
            //console.log(salioBien);
            if (salioBien == 0) {
                var xhttp_1 = new XMLHttpRequest();
                //METODO; URL; ASINCRONICO?
                xhttp_1.open("POST", "../BACKEND/administracion.php", true);
                //SETEO EL ENCABEZADO DE LA PETICION	
                //xhttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
                var form = document.getElementById("Formulario");
                var data = new FormData(form);
                //ENVIO DE LA PETICION CON LOS PARAMETROS
                xhttp_1.send(data);
                //FUNCION CALLBACK
                xhttp_1.onreadystatechange = function () {
                    if (xhttp_1.readyState == 4 && xhttp_1.status == 200) {
                        if (xhttp_1.responseText) {
                            //alert(xhttp.responseText);
                            document.getElementById("div").innerHTML = "<a href='../BACKEND/mostrar.php'><- MOSTRAR -></a>";
                        }
                        else {
                            alert("Error");
                        }
                    }
                };
            }
        };
        //Campos no vacíos.
        Validaciones.ValidarCamposVacios = function (string) {
            var retornador = true;
            if (string == "")
                retornador = false;
            return retornador;
        };
        //Rangos numéros correctos.
        Validaciones.ValidarRangoNumerico = function (num, min, max) {
            var retornador = false;
            if (num >= min && num <= max)
                retornador = true;
            return retornador;
        };
        //Selección del sexo.
        Validaciones.ValidarCombo = function (id, nodebecontener) {
            var retornador = false;
            if (id != nodebecontener)
                retornador = true;
            return retornador;
        };
        //Verificación del turno y sueldo máximo.
        Validaciones.ObtenerTurnoSeleccionado = function () {
            var retornador = "";
            //Type=radio
            var maniana = document.getElementById("maniana").checked;
            var tarde = document.getElementById("tarde").checked;
            var noche = document.getElementById("noche").checked;
            if (maniana)
                retornador = "m";
            if (tarde)
                retornador = "t";
            if (noche)
                retornador = "n";
            return retornador;
        };
        Validaciones.ObtenerSueldoMaximo = function (turno) {
            var retornador = 0;
            switch (turno) {
                case 'm':
                    retornador = 20000;
                    break;
                case 't':
                    retornador = 18500;
                    break;
                case 'n':
                    retornador = 24000;
                    break;
            }
            return retornador;
        };
        Validaciones.AdministrarValidacionesLogin = function () {
            //Inputs
            var dni = document.getElementById("txtDni").value;
            var apellido = document.getElementById("txtApellido").value;
            var salioBien = 0;
            if (!(Validaciones.ValidarCamposVacios(apellido))) {
                Validaciones.AdministarSpanError("spanAp", false);
                salioBien++;
            }
            else
                Validaciones.AdministarSpanError("spanAp", true);
            if ((!Validaciones.ValidarCamposVacios(dni) || (!Validaciones.ValidarRangoNumerico(+dni, 1000000, 55000000)))) {
                Validaciones.AdministarSpanError("spanDNI", false);
                salioBien++;
            }
            else
                Validaciones.AdministarSpanError("spanDNI", true);
            if (salioBien == 0 && Validaciones.VerificarValidacionesLogin()) {
                return true;
            }
        };
        Validaciones.AdministarSpanError = function (id, esconder) {
            if (!esconder)
                document.getElementById(id).style.display = 'block';
            else
                document.getElementById(id).style.display = 'none';
        };
        Validaciones.VerificarValidacionesLogin = function () {
            var retornador = true;
            var elementos = document.getElementsByTagName('span');
            for (var i = 0; i < elementos.length; i++) {
                if (elementos[i].style.display == 'block') {
                    //Con que uno este block ya retorno falso.
                    retornador = false;
                    break;
                }
            }
            return retornador;
        };
        Validaciones.AdministrarModificar = function (dni) {
            var formulario = document.getElementById("formMOD");
            document.getElementById("hdnModificar").value = dni;
            formulario.submit();
        };
        return Validaciones;
    }());
    Entidades.Validaciones = Validaciones;
})(Entidades || (Entidades = {}));
