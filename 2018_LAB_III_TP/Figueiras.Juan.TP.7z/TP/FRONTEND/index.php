<?php       
    require_once "../BACKEND/validarSesion.php"; 

    require_once "../BACKEND/Fabrica.php";

        $titulo = "HTML 5 - Formulario Alta Empleado"; $sub = "Alta de empleado"; $boton = "Enviar";
        $dni = ""; $apellido = ""; $nombre = ""; $sexo = ""; $sexoM=""; $sexoF="";
        $legajo = ""; $sueldo = ""; $turno=""; $turnoM="checked"; $turnoT=""; $turnoN=""; $readOnly = "";
        $modificar = false;

        if(isset($_POST["hdnModificar"]))
        {
            $dniAux = $_POST["hdnModificar"];
            
            $fabrica = new Fabrica("U.T.N", 7);
            $fabrica->TraerDeArchivo("../BACKEND/Empleados.txt");
            $empleados = $fabrica->GetEmpleados();
            
            $titulo  = "HTML 5 - Formulario Modificacion Empleado";
            $sub = "Modificación de empleado";
            $boton = "Modificar";

            foreach($empleados as $empleado)
            {
                if($empleado->GetDni() == $dniAux)
                {
                    $readOnly = "readonly";
                    $modificar = true;
                    $turnoM="";
                    $sexo="";
                    
                    $legajo = $empleado->GetLegajo();
                    $sueldo = $empleado->GetSueldo();
                    $turno = $empleado->GetTurno(); 
                    $foto = $empleado->GetPathFoto();
                    $dni = $empleado->GetDni();
                    $apellido = $empleado->GetApellido();
                    $nombre = $empleado->GetNombre();
                    $sexo = $empleado->GetSexo();
                    
                    switch($sexo){case "f": $sexoF="selected"; break; case "m": $sexoM="selected"; break;}

                    switch($turno){case"n": $turnoN="checked"; break; case"m": $turnoM="checked"; break; case"t": $turnoT="checked"; break;}
                    break;                   
                }
            }
        }

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $titulo; ?></title>
  <script src="validaciones.js"></script>
<meta http-equiv="Content-Type" content="text/html; UTF-8">
</head>

<body>
<form id="Formulario" name="Formulario" align ="center" method="post" enctype="multipart/form-data">
<table name="Tabla" align ="center">

  <tr>
  <th><h2><?php echo $sub; ?></h2>
  </th>
  </tr>

  <tr>
  <td><hr size="2px" color="black"/>
  <h4>Datos Personales</h4>
  <hr size="2px" color="black"/>
  </td>
  </tr>

  <tr>
  <td>DNI:
  <input type="number" name="txtDni" id="txtDni" min=1000000 max=55000000 value=<?php echo $dni;?> <?php echo $readOnly;?>/><span style="display:none" id="spanDNI">*</span>
  </td>
  </tr>

  <tr>
  <td>Apellido:  
  <input type="text" name="txtApellido" id="txtApellido" value=<?php echo $apellido;?>><span style="display:none" id="spanAp">*</span>
  </td>
  </tr>

  <tr>
  <td>Nombre:  
  <input type="text" name="txtNombre" id="txtNombre" value=<?php echo $nombre;?>><span style="display:none" id="spanNom">*</span>
  </td>
  </tr>

  <tr>
  <td>Sexo: 
  <select id="cboSexo" name="cboSexo">
    <option value=""<?php echo $sexo;?>>Seleccione</option>
    <option value="m"<?php echo $sexoM;?>>Masculino (M)</option>
    <option value="f"<?php echo $sexoF;?>>Femenino (F)</option>
  </select>
  <span style="display:none" id="spanSexo">*</span>
  </td>
  </tr>

  <tr>
  <td><hr size="2px" color="black"/>
  <h4>Datos laborales:</h4>
  <hr size="2px" color="black"/>
  </td>
  </tr>

  <tr>
  <td>Legajo:  
  <input type="number" id="txtLegajo" name="txtLegajo" min=100 max=550 value=<?php echo $legajo;?> <?php echo $readOnly;?>/>
  <span style="display:none" id="spanLeg">*</span>
  </td>
  </tr>
  
  <tr>
  <td>
  Sueldo:  
  <input type="number" id="txtSueldo" name="txtSueldo" min=8000 max=25000 step=500 value=<?php echo $sueldo;?>>
  <span style="display:none" id="spanSuel">*</span>
  </td>
  </tr>


  <tr>
  <td>Turno:<br>
  <input type="radio" id="maniana" name="maniana" value="m" checked="true" <?php echo $turnoM; ?>> Mañana<br>
  <input type="radio" id="tarde" name="tarde" value="t" <?php echo $turnoT; ?>> Tarde<br>
  <input type="radio" id="noche" name="noche" value="n" <?php echo $turnoN; ?>> Noche<br>
  <span style="display:none" id="spanTurno">*</span>
  </td>
  </tr>

  <tr><th><hr size="2px" color="black"/></th></tr>

  <tr>
  <td>Elija una foto:<br>
  <input type="file" name="foto" id="foto"><span style="display:none" id="spanFoto">*</span>
  </td>
  </tr>

  <tr>
  <td>
    <div name="Botones" align="right">
    <input type="reset" name="btnLimpiar" value="Limpiar" onclick=""><br>
    <?php
    if($modificar){
    echo '<input type="hidden" name="hdnModificar" id="hdnModificar" value='.$dni.'>';}?>
    <input type="button" name="btnEnviar" value=<?php echo $boton; ?> onclick="Entidades.Validaciones.AdministrarValidaciones()">
    </div>
  </td>
  </tr>

<div id="div" name="div"></div>
<a href = "../BACKEND/cerrarSesion.php">Cerrar sesión</a>
</table>
</form>

</body>
</html>