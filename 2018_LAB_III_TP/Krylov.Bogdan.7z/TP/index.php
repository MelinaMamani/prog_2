<?php
    session_start();
    include "./backend/validarSesion.php";

    //Chequeo si los datos enviados por POST son para el ingreso o modificación
    require_once("./clases/fabrica.php");
    $modif = isset($_POST["inpHidden"]);
    $existe = false;
    if($modif)
    {
        $dni = $_POST["inpHidden"]; // Recupero el dni 
        $fabrica = new Fabrica("Metalurgica NRT",7);
        $fabrica->TraerDeArchivo("./archivos/empleados.txt");
        foreach($fabrica->GetEmpleados() as $emp)
        {
            if($emp->GetDNI() == $dni)
            {
                $empleado = $emp; //Recupero todos los datos del empleado a modificar chequeando su DNI y lo guardo en esa variable
                $existe = true;
            }
        }
    }  #  La variable $empleado sera un objeto de tipo Empleado con todos los atributos y metodos que voy a usar luego.
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/estilo2.css">
    <script src="./javascript/validaciones.js"></script>
    <title><?php if($existe){echo "HTML 5 – Formulario Modificar Empleado"; }else{echo "HTML 5 – Formulario Alta Empleado";}?></title>
</head>
<body class="container-fluid">
    <div  align="center">

    <a name='cerrarSession' class='sign-out fa-sign-out' href='./backend/cerrarSession.php'>Cerrar sesion</a>
    <br><br><a class="btn btn-info" href="mostrar.php">Listado</a>

<form class="col-12 col-s-12" id="alta" method="post" enctype="multipart/form-data" action="administracion.php">
<h2><?php if($existe){echo "Modificación de Empleados"; }else{echo "Alta de Empleados";}?></h2>
    
    <br> 
    <table align="center" class="col-3 col-s-12"><tbody>
            <tr>
                <td colspan="4">
                    <h4>Datos Personales</h4>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <hr />
                </td>
            </tr>
            <tr>
                <td>DNI:</td>
                <td style="text-align:left">
                    <input name="txtDNI" type="number" id="txtDNI" style="width:50%" min="1000000" max="55000000"<?php if($existe){ echo "class='inputModif' value='".$empleado->GetDNI()."' readonly";} ?>>
                    <br><span style="display:none; color:red" id="dni">*</span>
                </td>
            </tr>
            <tr>
                <td>Apellido:</td>
                <td style="text-align:left">
                    <input name="txtApellido" type="Text" id="txtApellido" style="width:100%" <?php if($existe){ echo " value='".$empleado->GetApellido()."'";} ?>>
                    <br><span style="display:none; color:red" id="apellido">*</span>
                </td>
            </tr>
            <tr>
                <td>Nombre:</td>
                <td style="text-align:left">
                    <input name="txtNombre" type="Text" id="txtNombre" style="width:100%" <?php if($existe){ echo " value='".$empleado->GetNombre()."'";} ?>>
                    <br><span style="display:none; color:red" id="nombre">*</span>
                </td>
            </tr>
            <tr>
                <td>Sexo:</td>
                <td style="text-align:left">
                    <select name="cboSexo" id="cboSexo">
                        <option selected disabled value="---">Seleccione</option> <!-- Es disabled para que no se pueda elegir -->
                        <option value="M" <?php if($existe && $empleado->GetSexo()=="M"){echo "selected";}?>>M</option>
                        <option value="F" <?php if($existe && $empleado->GetSexo()=="F"){echo "selected";}?>>F</option>
                    </select>
                    <br><span style="display:none; color:red" id="cbosexo">*</span>
                </td>
            </tr>
            <tr>
                <td colspan="4"><br>
                    <h4>Datos Laborales</h4>
                </td>
            </tr>
            <tr>
                <td colspan="4">
                    <hr />
                </td>
            </tr>
            <tr>
                <td>Legajo:</td>
                <td style="text-align:left">
                    <input name="txtLegajo" id="txtLegajo" type="number" style="width:25%" min="100" max="550" <?php if($existe){ echo "class='inputModif' value='".$empleado->GetLegajo()."' readonly";} ?>/>
                    <br><span style="display:none; color:red" id="legajo">*</span>
                </td>
            </tr>
            <tr>
                <td>Sueldo:</td>
                <td style="text-align:left">
                    <input name="txtSueldo" id="txtSueldo" type="number" min="8000" step="500" max="25000" style="width:100%" <?php if($existe){ echo " value='".$empleado->GetSueldo()."'";} ?>/>
                    <br><span style="display:none; color:red" id="sueldo">*</span>
                </td>
            </tr>
            <tr>
                <td>Turno:</td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:left;padding-left:50px">
                    <input type="radio" name="rdoTurno" id="rdoMañana" value="Mañana" <?php if($existe && $empleado->GetTurno()=="Mañana"){echo "checked";}?> checked /> Mañana
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:left;padding-left:50px">
                    <input type="radio" name="rdoTurno" id="rdoTarde" value="Tarde" <?php if($existe && $empleado->GetTurno()=="Tarde"){echo "checked";}?>/> Tarde
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:left;padding-left:50px">
                    <input type="radio" name="rdoTurno" id="rdoNoche" value="Noche" <?php if($existe && $empleado->GetTurno()=="Noche"){echo "checked";}?>/> Noche
                </td>
            </tr>
            <tr><td>Foto:</td>
                <td colspan="2" style="text-align:left;padding-left:20px">
                <input type="file" name="files" id="files">
                <span style="display:none; color:red" id="foto">*</span>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr />
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right">
                    <input type="reset" class= "btn btn-warning" value="Limpiar" <?php if($existe){echo "style='display:none;'";}else{echo "style='display:block;'";}?>/>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right">
                    <br><input type="submit" class="btnSubmit btn btn-success" name="btnAlta" onclick="return AdministrarValidaciones();"   value=<?php if($existe){echo "'Modificar' ";}else{echo "'Enviar' ";}?>> 
                    <input type='hidden' name='hdnModificar' id='hdnModificar' <?php if($existe){echo "value='".$empleado->GetDNI()."'";}?> />
                </td>
            </tr>
        </tbody>
        </table><br>
</form>
        <br>
    </div>
</html>

