<?php
session_start();
include "./backend/validarSesion.php"; # Valido a que exista la sesion, sino no muestro el resto de este archivo
include "./clases/empleado.php";
include "./clases/fabrica.php"; //Agrego fabrica para usar sus funciones


$fab = new Fabrica("Metalurgica NRT",7);
$fab->TraerDeArchivo("./archivos/empleados.txt"); //Cargo el Array[] desde el archivo
$arrayEmpl = $fab->GetEmpleados(); //Recupero datos desde el array[]

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./css/estilo.css">
    <script src="./javascript/validaciones.js"></script>
    <title>Listado</title>
</head>
<body class="col-12 col-s-3">
    <h1 align="center">Listado de Empleados</h1>
    <div class="container-fluid">
    <table align="center" border="1" class="col-12 col-s-3">
    <div align="center">
        <a name='cerrarSession' class='sign-out fa-sign-out' href='./backend/cerrarSession.php'>Cerrar sesion</a><br><br>
        <a class="btn btn-info" href="index.php">Menu principal</a>
    </div>
	<br>
    <thead>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>DNI</th>
        <th>Sexo</th>
        <th>Legajo</th>
        <th>Sueldo</th>
        <th>Turno</th>
        <th>Acción</th>
  
    </thead>
    <tbody class="col-12 col-s-12">
        <?php
        if(isset($arrayEmpl)==true)
        {
            
            # Empiezo a cargar datos de cada empleado
            foreach($arrayEmpl as $e)
            {
                
                echo "
                <tr>
                <td align='center'>".$e->GetNombre()."</td>
                <td>".$e->GetApellido()."</td>
                <td>".$e->GetDni()."</td>
                <td>".$e->GetSexo()."</td>
                <td>".$e->GetLegajo()."</td>
                <td>".$e->GetSueldo()."</td>
                <td>".$e->GetTurno()."</td>
                <td><table><tr><td><img src=".$e->GetPathFoto()." width='90' heigth='90'></td><td><form action='eliminar.php' method='GET' id='elim'><a name='eliminar'  href='eliminar.php?Legajo=".$e->GetLegajo()."'><input type='button' id='eliminar' class='btn-danger' value='Eliminar'></a></form></td><td><input type='button' value='Modificar' class='btn-success' id='btnModificar' onclick='AdministrarModificar(".$e->GetDNI().");' /></tr></table></td>
                </tr>
                "; /* href='eliminar.php?legajo=".$e->GetLegajo()."' clave = valor() se manda por GET */
                # Creo un boton tipo link para eliminar al empleado y otro boton que me manda a la funcion AdministrarModificar()
            }
        }
        
        ?>
    </tbody>
    </table>
    </div>
    <form action='index.php' method='POST' id='frmModificar'>
        <input type='hidden' name='inpHidden' id='inpHidden'>
    </form>
</body> <!-- Hecho -->
</html>
