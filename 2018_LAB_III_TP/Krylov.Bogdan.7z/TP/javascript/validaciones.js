"use strict";
// Administra validaciones del login
function AdministrarValidacionesLogin() {
    var logok = true;
    if (ValidarCamposVacios("txtDNI") == false) // Valido el campo vacío del DNI
     {
        var div = document.getElementById("dni");
        div.style.display = 'block';
        logok = false;
    }
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtApellido") == false) // Verifico si se completó el Apellido
     {
        var div = document.getElementById("apellido");
        div.style.display = 'block';
        logok = false;
    }
    else {
        var div = document.getElementById("apellido");
        div.style.display = 'none';
    }
    var DNI = parseInt(document.getElementById("txtDNI").value); //Transformo a INT
    if (ValidarRangoNumerico(DNI, 1000000, 55000000) == false) //Valido el rango
     {
        var div = document.getElementById("dni");
        div.style.display = 'block';
        logok = false;
    }
    else {
        var div = document.getElementById("dni");
        div.style.display = 'none';
    }
    return logok; //Retorna true or false según si se cumplió todo
}
//*****************************************************
// Función principal que llamará a mis otras funciones
//******************************************************
function AdministrarValidaciones() {
    var ok = true;
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtDNI") == false) //Verifico si se completó el DNI
     {
        var div = document.getElementById("dni");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("dni");
        div.style.display = 'none';
    }
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtApellido") == false) // Verifico si se completó el Apellido
     {
        var div = document.getElementById("apellido");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("apellido");
        div.style.display = 'none';
    }
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtNombre") == false) //Verifico si se completó el Nombre
     {
        var div = document.getElementById("nombre");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("nombre");
        div.style.display = 'none';
    }
    //Pasando el id como parámetro y el id que no tiene que tener
    if (ValidarCombo("cboSexo", "---") == true) //Valido el combo Sexo
     {
        var div = document.getElementById("cbosexo");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("cbosexo");
        div.style.display = 'none';
    }
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtLegajo") == false) //Valido a que se complete el campo Legajo
     {
        var div = document.getElementById("legajo");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("legajo");
        div.style.display = 'none';
    }
    //Pasando el id como parámetro
    if (ValidarCamposVacios("txtSueldo") == false) // Valido a que se complete el campo Sueldo
     {
        var div = document.getElementById("sueldo");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("sueldo");
        div.style.display = 'none';
    }
    //Valido el rango del DNI
    var DNI = parseInt(document.getElementById("txtDNI").value); //Transformo a INT
    if (ValidarRangoNumerico(DNI, 1000000, 55000000) == false) {
        var div = document.getElementById("dni");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("dni");
        div.style.display = 'none';
    }
    //El valor máximo se establece según el turno elegido
    var sueldo = parseInt(document.getElementById("txtSueldo").value);
    if (ValidarRangoNumerico(sueldo, 8000, ObtenerSueldoMaximo(ObtenerTurnoSeleccionado())) == false) {
        var div = document.getElementById("sueldo");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("sueldo");
        div.style.display = 'none';
    }
    //Lo de la foto
    //Pasando el id como parámetro
    if (ValidarCamposVacios("files") == false) {
        var div = document.getElementById("foto");
        div.style.display = 'block';
        ok = false;
    }
    else {
        var div = document.getElementById("foto");
        div.style.display = 'none';
    }
    return ok;
}
//********************************************** FUNCIONES ****************************************************//
//********************************************************************
//Funciones secundarias que realizan todas las validaciones necesarias
//********************************************************************
function ValidarCamposVacios(id) {
    var campo = document.getElementById(id).value; //Recuperando la información del id
    if (campo == null || campo == "") //Verifico
     {
        return false; //En el caso de que hay campos vacíos
    }
    return true; //Si todo está completo
}
//********************************************************************
//Valido el rango de los campos numéricos como: sueldo, dni, etc
//********************************************************************
function ValidarRangoNumerico(num, min, max) {
    if (num >= min && num <= max) {
        return true; // Está dentro del rango / todo es ok
    }
    return false;
}
function ValidarCombo(id, invalid_id) {
    var selected = document.getElementById(id).value; //Según el id verifico qué es lo que se seleccionó
    if (selected == invalid_id) {
        return true; //No coincide
    }
    return false; //Coincide
}
function ObtenerTurnoSeleccionado() {
    var M = document.getElementById("rdoMañana").checked; // Si está chequeado devuelve true
    var T = document.getElementById("rdoTarde").checked;
    var N = document.getElementById("rdoNoche").checked;
    if (M == true) {
        return "Mañana";
    }
    if (T == true) //Si está chequeado
     {
        return "Tarde";
    }
    if (N == true) {
        return "Noche";
    }
    return "No hay turno"; //Si no se seleccionó nada
}
function ObtenerSueldoMaximo(turno) {
    if (turno == "Mañana") {
        return 20000;
    }
    if (turno == "Tarde") {
        return 18500;
    }
    if (turno == "Noche") {
        return 25000;
    }
    return 0; // Si no hay turno
}
function AdministrarModificar(dni) {
    //En el archivo mostrar.php el botón Modificar invoca esta función con un DNI como parametro
    document.getElementById("inpHidden").setAttribute("value", dni.toString()); //Alli seteo el DNI
    document.getElementById("frmModificar").submit(); // Y ago el submit del formulario oculto hacia el index.php (ver el form de mostrar.php)
}
//Hecho
//# sourceMappingURL=validaciones.js.map