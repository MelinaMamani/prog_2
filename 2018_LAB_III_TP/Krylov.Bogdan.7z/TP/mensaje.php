<html>
	<head>
		<title>Mensajes</title>

		<meta charset="UTF-8">
		
		<link href="./img/login.png" rel="icon" type="image/png" />

		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="./css/estilo.css">

	</head>
	<body class="container-fluid">
		<h4><?php echo $mensaje; ?></h4>
		<div align="center">
			<a class="btn btn-primary"  href="index.php">Menú principal</a>
			<a class="btn btn-primary"  href="mostrar.php">Listado</a>
		</div>
		
	</body>
</html>
