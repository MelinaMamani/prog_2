<?php
session_start(); //No se porque si no pongo eso no destruye la sesion
session_unset();
session_destroy();
header("location: ../login.html"); //Elimino todas las sesiones y redirecciono al login
#Hecho
?>