<?php

if(!isset($_SESSION['DNIEmpleado'])) 
{
    header("location: ./login.html"); //Redirecciono si la sesion ya no existe
}
#Hecho
?>