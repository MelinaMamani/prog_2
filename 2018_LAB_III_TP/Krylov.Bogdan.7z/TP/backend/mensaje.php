<html>
	<head>
		<title>Mensajes</title>

		<meta charset="UTF-8">
		
		<link href="../img/login.png" rel="icon" type="image/png" />

		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/login.css">

	</head>
	<body class="container-fluid">
		<h4><?php echo $mensaje; ?></h4>
		<div align="center"><a class="btn btn-primary"  href="../login.html">Volver al login</a></div>
		
	</body>
</html>
