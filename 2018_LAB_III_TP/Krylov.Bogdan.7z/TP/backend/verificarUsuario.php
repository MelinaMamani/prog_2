<?php
session_start(); //Inicio la sesion (después la voy a setear si el user existe)
?>

<?php
#Recupero las variables para luego buscar al empleado y ver si existe o no
$logDNI = isset($_POST["txtDNI"]) ? TRUE : FALSE;
$logApellido = isset($_POST["txtApellido"]) ? TRUE : FALSE;


if($logDNI && $logApellido)
{
    if(file_exists('../archivos/empleados.txt')==true) //Chequeo si existe el archivo
    {
        $ar = fopen('../archivos/empleados.txt', "r");  // Abro el archivo

        $flag = 0;
        $exists = false;

        while(!feof($ar))
        {
            $linea = fgets($ar);
            if(empty($linea) && $flag==0) //En este caso valido a que si no hay nada en el archivo, corto y no sigo más
            {
                echo("<h2 align='center' style='color:red'>No hay empleados en la fábrica!</h2>");
                #Además me fijo por la bandera si entra, chequeo la bandera (busco al empleado más abajo)
                break;
            }
            
            $arrayEmp = explode (" - ", $linea); #Rompo mi cadena en bloques para manejar luego los datos
            $arrayEmp[0] = trim($arrayEmp[0]); #Elimino espacios en blanco y otra basura
            if(strlen($linea)>0 && $arrayEmp[0] !="")
            {
                $flag =1;
                //Si existe el empleado, seteo la sesion con su DNI
               if($arrayEmp[1] == ($_POST["txtApellido"]) && $arrayEmp[2] == ($_POST["txtDNI"]))
               {
                
                    $_SESSION['DNIEmpleado'] = $_POST["txtDNI"]; #ACÁ SETEO LA SESION CON EL DNI
                    header("location: ../mostrar.php"); #Y redirecciono al listado (grilla de empleados)
               }
            }
            
            
        }
        fclose($ar);
        if($exists == false && $flag ==1)
        {
            $mensaje = "Acceso denegado, el empleado NO EXISTE !";
            include("mensaje.php");
        }
    }
}
#Hecho
?>
