<?php
require_once("./clases/fabrica.php");

$baja = isset($_GET["Legajo"]); # Recupero la clave pasada por GET en mostrar.php (el boton Eliminar)

$encontrado = false;

if($baja)
{
    # Lo mismo que en mostrar.php cargo primero mi fabrica (el Array[])
    $fabrica = new Fabrica("Metalurgica NRT",7);
    $fabrica->TraerDeArchivo("./archivos/empleados.txt");
    $arrayEmpl = $fabrica->GetEmpleados();

    # Voy buscando datos que coincidan
    foreach($arrayEmpl as $e)
    {
        if($e->GetLegajo() == $baja)
        {
            if($fabrica->EliminarEmpleado($e)==true) # Si encontró, lo mando a eliminar
            {
                $x = trim($e->GetPathFoto()); //Saco espacios en blanco
                $x = str_replace("./","",$x);//Reemplaza caracteres de esta variable
                unlink($x); # Como también tengo que eliminar la foto, lo hago a travez de unlink()
                $fabrica->GuardarEnArchivo("./archivos/empleados.txt"); //Guardo todo el array en el archivo
                $mensaje = "Empleado eliminado!";
                include("mensaje.php");
            }
            else # Si no se pudo eliminar
            {
                $mensaje = "NO se pudo eliminar al empleado";
                include("mensaje.php");
            }
            $encontrado = true;
            break; //Corto la iteración si se encontró al empleado
        }
        
    }
    if($encontrado == false) # Puede que el empleado no exista (en el caso sio se modificó el archivo)
    {
        $mensaje = "El empleado NO existe";
	    include("mensaje.php");
    }

    
}# Hecho


?>