﻿<?php
include "./clases/empleado.php"; #importo al Empleado para crear objetos y manipular
include "./clases/fabrica.php"; #importo a Fabrica para guardar, eliminar, o modificar objetos en ella

$alta = isset($_POST["btnAlta"]) ? TRUE : FALSE; 
$encontrado = false; 
$modif = isset($_POST["hdnModificar"]);
$f = new Fabrica("Metalurgica NRT",7);



if($modif) 
{
    
    $f->TraerDeArchivo("./archivos/empleados.txt");
    foreach($f->GetEmpleados() as $e)
    {
        # Como la condición es siempre verdadera, me voy a fijar si el DNI seteado coincide con algún registro
        if($e->GetDNI() == $_POST["hdnModificar"]) 
        {
            if($f->EliminarEmpleado($e))
            {
                $x = trim($e->GetPathFoto()); //Saco espacios en blanco
                $x = str_replace("./","",$x);//Reemplaza caracteres de esta variable
                unlink($x); //Elimino al empleado para poder luego agregarlo como nuevo en Alta();
                $f->GuardarEnArchivo("./archivos/empleados.txt"); //Guardo todo el array en el archivo
                
            }
            else
            {
                $mensaje = "NO se pudo modificar al empleado";
                include("mensaje.php");
                exit;
            }
            $encontrado = true;
            break; //Corto la iteración si se encontró al empleado
        }
    }
    
}


if($alta)
{    # Me fijo si ya se alcanzó o no el límite máximo de empleados
    if(count($f->GetEmpleados())==7){$mensaje = "LÍMITE MÁXIMO DE EMPLEADOS ALCANZADO!";
        include("mensaje.php");exit;} 
    
    
    # Recupero el path de la foto y valido su tamaño y extensión
    $path = $_FILES["files"]["name"];
    $ext = pathinfo($path,PATHINFO_EXTENSION);
    
    if($ext =="jpg" || $ext =="bmp" || $ext =="gif" || $ext =="png")
    {
        if($_FILES["files"]["size"] > 100000) {
            # Si el tamaño es invalido
            $mensaje = "EL TAMAÑO DE LA IMÁGEN ES INVÁLIDO !";
            include("mensaje.php");
        }
        else 
        {
            if($_FILES["files"]["size"] <= 100000){
                
                
                
                $destino = "./fotos/".$_POST['txtDNI']."-".$_POST["txtApellido"].".".$ext;
                
                //Creo la fábrica
                $fab = new Fabrica("Metalurgica NRT",7);
                
                if(file_exists("./fotos/"))
                {
                    # Muevo la imágen hacia el destino
                    move_uploaded_file($_FILES["files"]["tmp_name"],$destino); 
                }
                else
                {
                    $mensaje = "Error, no existe la carpeta del destino ! No se puede subir la imágen !";
                    include("mensaje.php");
                }

            
                if(file_exists(pathinfo("fotos/",PATHINFO_FILENAME))==true) # Si se pudo subir la imágen empiezo a crear al Empleado
                {
                    # Creo al objeto Empleado
                    $emp = new Empleado($_POST["txtNombre"],$_POST["txtApellido"],$_POST["txtDNI"],$_POST["cboSexo"],$_POST["txtLegajo"],$_POST["txtSueldo"],$_POST["rdoTurno"]);
                    $emp->SetPathFoto($destino); # Seteo el path de la foto
                    
                    # Tengo que cargar mi fabrica con los datos del archivo ya que este se va a sobreescribirse siempre
                    # Una vez cargado el array desde el archivo empiezo a cargar a mi objeto Empleado
                    $fab->TraerDeArchivo("./archivos/empleados.txt");
    
                    # Guardo empleado en la fábrica (en el Array[])
                    if($fab->AgregarEmpleado($emp)==false) # Si no se pudo realizar la operación y además
                    {
                        if($encontrado) # es una modificación 
                        {
                            $mensaje = "NO se pudo modificar al empleado"; # muestro el mensaje
                            include("mensaje.php");
                        }
                        else # no es una moificación 
                        {
                            $mensaje = "Lamentablemente ocurrio un error y no se pudo agregar al empleado.";
                            include("mensaje.php");
                        }                        
                    }
                    else
                    {
                        //Guardo en el archivo
                        $fab->GuardarEnArchivo("./archivos/empleados.txt");
                        if($encontrado)//Si es una modificación
                        {
                            $mensaje = "Empleado modificado con éxito!";
                            include("mensaje.php");
                        }
                        else //sino
                        {
                            $mensaje = "Empleado guardado en fábrica y en archivo con éxito";
                            include("mensaje.php");
                        }                        
                    }
                }
                else
                {
                    # Si ocurrio un error
                    $mensaje = "Error con el directorio de imágenes !";
                    include("mensaje.php");
                }
                
            }
        }//Fin si tamaño válido

    }//Fin extención válida
    
    # Hecho
}

?>