<?php
include "persona.php"; //Importo mi archivo persona.php 

class Empleado extends Persona #Herencia
{
    protected $_legajo; //int
    protected $_pathFoto; //string
    protected $_sueldo; //double
    protected $_turno; //string

    public function __construct($nombre, $apellido, $dni, $sexo, $legajo, $sueldo, $turno)
    {
        parent::__construct($nombre,$apellido,$dni,$sexo); //Llamada a la clase base (Persona)
        $this->_legajo= $legajo;
        $this->_sueldo = $sueldo;
        $this->_turno = $turno;
    }

    public function GetLegajo(){return $this->_legajo;}
    public function GetPathFoto(){return $this->_pathFoto;} 
    public function GetSueldo(){return $this->_sueldo;}
    public function GetTurno(){return $this->_turno;}

    public function Hablar($idioma) //array de string con diferentes idiomas
    {
        $string = "El empleado habla ";
        foreach($idioma as $i)
        {
            $string.=$i.", "; //Español, Inglés, Francés
        }
        return $string;
    }
    public function SetPathFoto($value){$this->_pathFoto = $value;} #Un getter para setear el path de la foto del empleado

    public function ToString()
    {
        return parent::ToString()." - ".$this->_legajo." - ".$this->_sueldo." - ".$this->_turno." - ".$this->_pathFoto; //parent::ToString() para llamar método de la clase base. Polimorfismo
    }
} # Hecho
?>