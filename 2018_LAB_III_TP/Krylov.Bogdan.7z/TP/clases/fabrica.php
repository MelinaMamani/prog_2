<?php
include_once "empleado.php"; #Importo al empleado para crear objetosy guardar en Fabrica
include "./interface.php"; #Agrego la interface
class Fabrica implements IArchivo 
{
    private $_cantidadMaxima; //int
    private $_empleados; //Empleado[]
    private $_razonSocial; //string

    public function __construct($razonSocial,$cant_max) 
    {
        $this->_razonSocial = $razonSocial;
        $this->_cantidadMaxima = $cant_max; 
        $this->_empleados = array();
    }

    public function AgregarEmpleado($emp) #bool
    {
        if(count($this->_empleados) < $this->_cantidadMaxima)
        {
            array_push($this->_empleados, $emp); #Agrego al empleado al array y luego
            $this->EliminarEmpleadoRepetido();//Llamo a mi función para que elimine datos duplicados
		    return true;
        }
        return false;
    }

    public function CalcularSueldos() //double
    {
        $totalSueldos =0;
        foreach($this->_empleados as $i)
        {
            $totalSueldos += $i->GetSueldo(); //Calculo sueldos de cada empleado
        }
        return $totalSueldos;
    }

    public function EliminarEmpleado($emp)// Recibe un objeto de tipo empleado y lo elimina del array _empleados, usar unset()
    {            
        if(in_array($emp, $this->_empleados))
        {
            $i = array_search($emp, $this->_empleados);
            unset($this->_empleados[$i]); //Elimino al empleado del índice
            return true;
        }
        return false;              
    }

    private function EliminarEmpleadoRepetido()
    {
        $this->_empleados = array_unique($this->_empleados, SORT_REGULAR); //Esta funsión busca datos repetidos y deja sólo datos únicos
    }

    public function GetEmpleados(){return $this->_empleados;} //Empleado[] retorna el array de Empleados

    public function ToString() #Retorna los datos de cada empleado
    {
        $cadena = "Fabrica: $this->_razonSocial - Cantidad de empleados: ".count($this->_empleados);
        $cadena .= " - Total Sueldos: " . $this->CalcularSueldos();
        $cadena .= "<br>Lista de empleados: <br>";
        foreach ($this->_empleados as $key)
        {
            $cadena .= $key->ToString() . "<br>";
        }
        return $cadena;
    }

    //Implementando interface IArchivo

    public function GuardarEnArchivo($nombreArchivo) //void , en realidad debe de retornar un boolean, sino cómo sé si se guardó?
    {
        //ABRO EL ARCHIVO
		$ar = fopen($nombreArchivo, "w"); //Si no existe, se crea W - for write
    
        foreach($this->_empleados as $obj)
        {
            //ESCRIBO EN EL ARCHIVO
            if($obj !=NULL)
            {
                fwrite($ar, $obj->ToString().PHP_EOL); //PHP_EOL -- una nueva forma de dar \r\n 
            }
		    
        }
		
		//CIERRO EL ARCHIVO
		fclose($ar);
		
    }
    public function TraerDeArchivo($nombreArchivo)
    {
        if(file_exists($nombreArchivo)==true)
        {
            $ar = fopen($nombreArchivo, "r"); // Abro el archivo para leer r - for read   

            while(!feof($ar))
            {
                $linea = fgets($ar); //Leo cada línea
                
                $arrayEmp = explode (" - ", $linea); //Divido por bloques limitándome por el guion
                $arrayEmp[0] = trim($arrayEmp[0]);//Eliminates white spaces and other characters from beginning and end
                if(strlen($linea)>0 && $arrayEmp[0] !="")
                {
                    //Creo objetos de tipo Empleado
                    $empleado = new Empleado($arrayEmp[0],$arrayEmp[1],$arrayEmp[2],$arrayEmp[3],$arrayEmp[4],$arrayEmp[5],$arrayEmp[6]);
                    $empleado->SetPathFoto($arrayEmp[7]); //El ímdice 7 será el path de la foto
                    $this->AgregarEmpleado($empleado); //Vuelvo a cargar cada objeto a la lista o Array[]
                }
            }
            fclose($ar); //Cierro el archivo
        }        
    }
} # Hecho

?>