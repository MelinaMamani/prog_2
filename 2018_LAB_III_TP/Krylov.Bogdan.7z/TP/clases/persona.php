<?php
abstract class Persona #Es la clase base
{
    private $_apellido; //string
    private $_dni; //int
    private $_nombre; //string
    private $_sexo; //char

    public function __construct($nombre,$apellido,$dni,$sexo)
    {
        $this->_apellido = $apellido;
        $this->_nombre = $nombre;
        $this->_dni = $dni;
        $this->_sexo = $sexo; 
    }

    public function GetApellido(){return $this->_apellido;}
    public function GetDni(){return $this->_dni;}
    public function GetNombre(){return $this->_nombre;}
    public function GetSexo(){return $this->_sexo;}

    public abstract function Hablar($idioma); //string[] array con distintas idiomas

    public function ToString()
    {
        return $this->GetNombre()." - ".$this->GetApellido()." - ".$this->GetDni()." - ".$this->GetSexo(); 
    }
} # Hecho
?>
