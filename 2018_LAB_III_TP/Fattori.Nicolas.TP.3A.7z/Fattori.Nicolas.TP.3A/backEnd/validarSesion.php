<?php
if(!isset($_SESSION["DNIEmpleado"]))
{
    header('location: ../login.html');
}
?>

